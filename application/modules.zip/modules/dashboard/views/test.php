this is the test 2 of mvc module
<?php echo modules::run("search_bar/by_batch/index/"); ?>
<?php
//echo modules::run('admin/login/index');
//echo $this->session->userdata("test",'','error');
?>