<div id="genderbarchart_material" style="width: 100%; height: 350px;"></div>
<div class="clearfix"> </div>
 