<div id="piechart_3d_<?= $grade ?>_status" style="width: 100%; height: 250px;"></div>
<div class="clearfix"> </div>
 