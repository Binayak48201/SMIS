<?php
$this->load->view('common/ajax_header.php');
/*$this->load->view('common/sidebar.php');*/
$this->load->view($main_content);

$this->load->view('common/ajax_footer.php');
?>
