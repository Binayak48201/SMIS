<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-22 10:59:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-22 15:20:04 --> Query error: Duplicate entry 'Seven-2075-Chinese' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2075', 'Seven', 'Chinese', '50', '20', 'COMPULSORY')
ERROR - 2018-04-22 15:20:16 --> Query error: Duplicate entry 'Seven-2075-Chinese' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2075', 'Seven', 'Chinese', '50', '20', 'COMPULSORY')
ERROR - 2018-04-22 15:52:25 --> Query error: Duplicate entry 'Three-2075-Sanskrit' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2075', 'Three', 'Sanskrit', '50', '20', 'COMPULSORY')
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 59
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 91
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 95
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 97
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 101
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 103
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 107
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 109
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 113
ERROR - 2018-04-22 16:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 115
ERROR - 2018-04-22 16:05:05 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-22 16:05:12 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-22 16:05:12 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
