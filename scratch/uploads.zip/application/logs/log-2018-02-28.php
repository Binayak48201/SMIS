<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-28 10:34:22 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-28 10:43:34 --> 404 Page Not Found: /index
ERROR - 2018-02-28 10:49:31 --> 404 Page Not Found: /index
ERROR - 2018-02-28 10:49:31 --> 404 Page Not Found: /index
ERROR - 2018-02-28 10:57:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 10:57:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 10:57:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 10:57:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:13:06 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:13:06 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:13:06 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:13:06 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:13:06 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:13:06 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:13:06 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:35:23 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:21 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 11:52:22 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:03:53 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-02-28 13:04:04 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:04:04 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:04:04 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:04:04 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:04:04 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:04:04 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:04:04 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:04:13 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:33 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:41 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:48 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 13:05:55 --> 404 Page Not Found: /index
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 15:08:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:02:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-28 16:04:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
