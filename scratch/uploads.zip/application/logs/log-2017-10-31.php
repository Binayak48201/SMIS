<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-31 15:04:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Batch_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2017-10-31 15:05:18 --> Severity: Error --> Call to undefined method Student_model::get_houses() C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 45
ERROR - 2017-10-31 15:05:20 --> Severity: Error --> Call to undefined method Student_model::get_houses() C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 45
