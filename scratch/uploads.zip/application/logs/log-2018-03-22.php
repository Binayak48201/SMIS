<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-22 09:50:45 --> Severity: Notice --> Undefined variable: schools C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 53
ERROR - 2018-03-22 09:50:56 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-22 09:51:13 --> Severity: Notice --> Undefined variable: schools C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 53
ERROR - 2018-03-22 11:39:22 --> Severity: Notice --> Undefined variable: schools C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 53
ERROR - 2018-03-22 11:40:47 --> Query error: Unknown table 'smis.sc' - Invalid query: SELECT `s`.*, `u`.`USER_NAME`, `sc`.*
FROM `student` `s`
WHERE `s`.`district_id` = ''
AND `s`.`passed_out` != 1
ORDER BY `st_fname` ASC
ERROR - 2018-03-22 11:41:56 --> Query error: Unknown table 'smis.sc' - Invalid query: SELECT `s`.*, `u`.`USER_NAME`, `sc`.*
FROM `student` `s`
WHERE `s`.`district_id` = '63'
AND `s`.`passed_out` != 1
ORDER BY `st_fname` ASC
ERROR - 2018-03-22 11:42:21 --> Query error: Unknown column 'u.USER_NAME' in 'field list' - Invalid query: SELECT `s`.*, `u`.`USER_NAME`
FROM `student` `s`
WHERE `s`.`district_id` = '63'
AND `s`.`passed_out` != 1
ORDER BY `st_fname` ASC
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 97
ERROR - 2018-03-22 11:42:31 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 110
ERROR - 2018-03-22 11:42:31 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 11:42:31 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 11:42:32 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 11:42:32 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 11:42:33 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 11:42:33 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:09 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:10 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:11 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:43:12 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:07 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:54:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:24 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:25 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:55:56 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-22 11:56:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:18 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:19 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:20 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:22 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:23 --> 404 Page Not Found: /index
ERROR - 2018-03-22 11:56:50 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-22 14:43:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-22 14:44:58 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-22 14:45:08 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 90
ERROR - 2018-03-22 14:50:32 --> Query error: Unknown column 'o.occupation' in 'field list' - Invalid query: SELECT `s`.*, `u`.`USER_NAME`, `sc`.*, `o`.`occupation`
FROM `student` `s`
JOIN `occupation` `o` ON `o`.`occupation_id` = `s`.`guardian_occupation_id`
JOIN `section` `sc` ON `sc`.`section_id` = `s`.`class_id`
LEFT JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
WHERE `class_id` = '13'
ORDER BY `st_fname` ASC
ERROR - 2018-03-22 14:51:36 --> Query error: Unknown table 'smis.0' - Invalid query: SELECT `s`.*, `u`.`USER_NAME`, `sc`.*, `0`.*
FROM `student` `s`
JOIN `occupation` `o` ON `o`.`occupation_id` = `s`.`guardian_occupation_id`
JOIN `section` `sc` ON `sc`.`section_id` = `s`.`class_id`
LEFT JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
WHERE `class_id` = '13'
ORDER BY `st_fname` ASC
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 14:51:56 --> Severity: Notice --> Undefined property: stdClass::$occupation C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 151
ERROR - 2018-03-22 15:01:12 --> Severity: Notice --> Undefined variable: districts C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 53
ERROR - 2018-03-22 15:04:37 --> Severity: Notice --> Undefined variable: districts C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 53
ERROR - 2018-03-22 15:06:03 --> Query error: Unknown column 's.occupation_id' in 'where clause' - Invalid query: SELECT `s`.*, `o`.`occupation_name`
FROM `student` `s`
JOIN `occupation` `o` ON `o`.`occupation_id` = `s`.`guardian_occupation_id`
WHERE `s`.`occupation_id` = ''
AND `s`.`passed_out` != 1
ORDER BY `st_fname` ASC
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:29 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 97
ERROR - 2018-03-22 15:07:30 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 110
ERROR - 2018-03-22 15:07:30 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 15:07:31 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 15:07:31 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 15:07:31 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 15:07:32 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 15:07:32 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 15:07:32 --> 404 Page Not Found: ../modules/pages/controllers/reports/General_reports/%3Cdiv%20style=
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:08:34 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 116
ERROR - 2018-03-22 15:10:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 90
ERROR - 2018-03-22 15:11:08 --> 404 Page Not Found: /index
ERROR - 2018-03-22 15:11:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 90
ERROR - 2018-03-22 15:11:21 --> 404 Page Not Found: /index
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:15 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$Batch C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 114
ERROR - 2018-03-22 15:19:16 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:19:52 --> Severity: Notice --> Undefined property: stdClass::$garde C:\xampp\htdocs\smis\application\modules\pages\views\reports\occupation_guardian_list.php 115
ERROR - 2018-03-22 15:21:11 --> Query error: Unknown column 's.class_id' in 'on clause' - Invalid query: SELECT `s`.*, `sc`.*, `o`.`occupation_name`
FROM `occupation` `o`
JOIN `section` `sc` ON `sc`.`section_id` = `s`.`class_id`
JOIN `student` `s` ON `o`.`occupation_id` = `s`.`guardian_occupation_id`
WHERE `s`.`guardian_occupation_id` = ''
AND `s`.`passed_out` != 1
ORDER BY `st_fname` ASC
ERROR - 2018-03-22 15:50:41 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 352
ERROR - 2018-03-22 15:58:41 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-22 16:10:39 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
