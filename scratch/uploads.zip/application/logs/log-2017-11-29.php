<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 170
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 268
ERROR - 2017-11-29 10:45:51 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 284
ERROR - 2017-11-29 10:45:51 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 284
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 165
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 190
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 190
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 204
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 204
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 204
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 275
ERROR - 2017-11-29 10:53:10 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 291
ERROR - 2017-11-29 10:53:10 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 291
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 10:58:56 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 10:58:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> unserialize(): Error at offset 14 of 22 bytes C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 127
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 10:59:23 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 10:59:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 10:59:47 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 10:59:47 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:02:37 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:02:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:03:39 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:03:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:04:54 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:04:54 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:05:59 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:05:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:06:17 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:06:17 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:20:47 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:20:47 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:21:10 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:21:10 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:21:25 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:21:25 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:22:26 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:22:26 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-29 11:25:42 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:25:42 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 189
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 202
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 202
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 217
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 217
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 217
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 287
ERROR - 2017-11-29 11:44:50 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 303
ERROR - 2017-11-29 11:44:50 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 303
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 189
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 202
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 202
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 217
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 217
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 217
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 255
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 287
ERROR - 2017-11-29 11:45:03 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 303
ERROR - 2017-11-29 11:45:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 303
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 191
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 193
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 206
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 206
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 251
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 251
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 241
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 251
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 259
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 259
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 291
ERROR - 2017-11-29 11:47:40 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 307
ERROR - 2017-11-29 11:47:40 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 307
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 194
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 292
ERROR - 2017-11-29 12:21:49 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:21:49 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 194
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 292
ERROR - 2017-11-29 12:21:52 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:21:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 194
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 292
ERROR - 2017-11-29 12:22:20 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:22:20 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:23:27 --> Query error: Duplicate entry '1196-56-7' for key 'unique_row' - Invalid query: INSERT INTO `st_marks` (`student_id`, `subject_id`, `exam_id`, `obtain_mark`, `assessment_marks`, `total_marks`, `class_days_id`) VALUES ('1196', '56', '7', '1', 'a:2:{i:4;s:1:\"2\";i:5;s:1:\"3\";}', '11', '1295')
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 194
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 292
ERROR - 2017-11-29 12:24:55 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:24:55 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 194
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 292
ERROR - 2017-11-29 12:25:23 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:25:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 194
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 292
ERROR - 2017-11-29 12:26:13 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:26:13 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:26:18 --> Query error: Duplicate entry '1196-56-7' for key 'unique_row' - Invalid query: INSERT INTO `st_marks` (`student_id`, `subject_id`, `exam_id`, `obtain_mark`, `assessment_marks`, `total_marks`, `class_days_id`) VALUES ('1196', '56', '7', '0', 'a:2:{i:4;s:1:\"0\";i:5;s:1:\"0\";}', '0', '1295')
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 194
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 292
ERROR - 2017-11-29 12:27:33 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:27:33 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 194
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 221
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 252
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 292
ERROR - 2017-11-29 12:27:44 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:27:44 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 308
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 193
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 259
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 267
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 293
ERROR - 2017-11-29 12:28:57 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 309
ERROR - 2017-11-29 12:28:57 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 309
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 193
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 259
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 267
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 293
ERROR - 2017-11-29 12:29:35 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 309
ERROR - 2017-11-29 12:29:35 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 309
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 193
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 259
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 267
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 293
ERROR - 2017-11-29 12:29:49 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 309
ERROR - 2017-11-29 12:29:49 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 309
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 193
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 259
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 261
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 267
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 293
ERROR - 2017-11-29 12:30:27 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 309
ERROR - 2017-11-29 12:30:27 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 309
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 263
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 271
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 12:30:50 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 313
ERROR - 2017-11-29 12:30:50 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 313
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 263
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 271
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 12:31:45 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 313
ERROR - 2017-11-29 12:31:45 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 313
ERROR - 2017-11-29 12:31:54 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 132
ERROR - 2017-11-29 12:31:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 132
ERROR - 2017-11-29 12:31:54 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:31:54 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 132
ERROR - 2017-11-29 12:31:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 132
ERROR - 2017-11-29 12:31:54 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:31:54 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 132
ERROR - 2017-11-29 12:31:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 132
ERROR - 2017-11-29 12:31:54 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:31:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 247
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 253
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 257
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 263
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 271
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 297
ERROR - 2017-11-29 12:34:54 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 313
ERROR - 2017-11-29 12:34:54 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 313
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: assessment_module C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: assessment_module C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 171
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:35:35 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:35:35 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:36:22 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:36:22 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:36:57 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:36:57 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:37:45 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:37:45 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:39:18 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:39:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:39:23 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 184
ERROR - 2017-11-29 12:39:23 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:39:23 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:39:23 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:39:24 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:39:24 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 184
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:39:38 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:39:38 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:09 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:40:10 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:40:10 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 137
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:40:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:40:39 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:40:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:41:12 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:41:12 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:41:23 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:41:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:41:46 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:41:46 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:41:56 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:41:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:42:00 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:42:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 264
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 272
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 298
ERROR - 2017-11-29 12:42:06 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
ERROR - 2017-11-29 12:42:06 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 314
