<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-13 10:47:24 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-13 10:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-13 10:48:55 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-13 10:48:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-13 10:49:21 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-13 10:49:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-13 10:49:51 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-13 10:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-13 10:52:10 --> Severity: Error --> Class 'Mx_Controller' not found C:\xampp\htdocs\smis\application\modules\dashboard\controllers\user_log.php 4
