<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-05 13:15:05 --> Severity: Notice --> Undefined property: CI::$programlevel_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-12-05 13:15:05 --> Severity: Error --> Call to a member function get_programlevel() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 220
ERROR - 2017-12-05 13:31:17 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-05 13:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-05 15:10:42 --> Severity: Error --> Call to undefined method Ajax_model::get_class_exams() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 70
ERROR - 2017-12-05 15:12:24 --> Severity: Error --> Call to undefined method Ajax_model::get_class_exams() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 70
ERROR - 2017-12-05 15:12:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 136
ERROR - 2017-12-05 15:12:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 137
ERROR - 2017-12-05 15:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 136
ERROR - 2017-12-05 15:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 137
ERROR - 2017-12-05 15:13:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 136
ERROR - 2017-12-05 15:13:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 137
ERROR - 2017-12-05 15:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 136
ERROR - 2017-12-05 15:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 137
