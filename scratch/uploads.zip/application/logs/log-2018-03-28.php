<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-28 09:52:21 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-28 09:52:45 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 77
ERROR - 2018-03-28 10:01:31 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 98
ERROR - 2018-03-28 10:01:47 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 98
ERROR - 2018-03-28 10:05:58 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 98
ERROR - 2018-03-28 10:06:02 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 98
ERROR - 2018-03-28 10:14:49 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 98
ERROR - 2018-03-28 10:14:59 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 98
ERROR - 2018-03-28 10:19:05 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 288
ERROR - 2018-03-28 10:19:57 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 99
ERROR - 2018-03-28 10:24:24 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-28 10:25:53 --> Severity: Notice --> Undefined index: ssection C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 137
ERROR - 2018-03-28 10:25:53 --> Severity: Notice --> Undefined index: sbatch C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 137
ERROR - 2018-03-28 10:25:53 --> Severity: Notice --> Undefined index: sgrade C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 137
ERROR - 2018-03-28 10:25:53 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\dropped_student_list.php 53
ERROR - 2018-03-28 10:25:53 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\reports\dropped_student_list.php 71
ERROR - 2018-03-28 10:25:53 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\dropped_student_list.php 90
ERROR - 2018-03-28 10:28:18 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\dropped_student_list.php 53
ERROR - 2018-03-28 10:28:18 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\reports\dropped_student_list.php 71
ERROR - 2018-03-28 10:28:18 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\dropped_student_list.php 90
ERROR - 2018-03-28 10:39:12 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-28 10:39:17 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 10:40:38 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 10:41:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 10:45:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 10:46:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 10:46:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 10:48:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:10:05 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-28 11:10:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:15:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:16:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:18:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:19:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:20:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:22:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:23:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 11:28:27 --> Query error: Duplicate entry '13-126-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('13', 'First Term', '1', '126', '100', '45', '20', '30', 1)
ERROR - 2018-03-28 11:38:51 --> Query error: Duplicate entry '13-121-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('13', 'First Term', '1', '121', '100', '45', '20', '30', 1)
ERROR - 2018-03-28 11:39:24 --> Query error: Duplicate entry '13-123-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('13', 'First Term', '1', '123', '100', '45', '20', '30', 1)
ERROR - 2018-03-28 11:39:33 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-28 11:40:55 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-28 11:40:56 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-28 11:41:03 --> Query error: Unknown column 'se.section_id' in 'on clause' - Invalid query: SELECT *
FROM `subject_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `se`.`exam_id`
ERROR - 2018-03-28 11:41:13 --> Query error: Unknown column 'se.section_id' in 'on clause' - Invalid query: SELECT *
FROM `subject_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `se`.`exam_id`
ERROR - 2018-03-28 11:41:15 --> Query error: Unknown column 'se.section_id' in 'on clause' - Invalid query: SELECT *
FROM `subject_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `se`.`exam_id`
ERROR - 2018-03-28 11:41:40 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-28 11:48:03 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\smis\application\modules\pages\controllers\home.php 66
ERROR - 2018-03-28 11:58:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-28 11:58:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-28 11:59:01 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-28 12:00:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-28 12:00:59 --> Query error: Unknown column 'se.section_id' in 'on clause' - Invalid query: SELECT *
FROM `subject_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `se`.`exam_id`
ERROR - 2018-03-28 12:01:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:01:51 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:01:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:02:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:07:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-28 12:07:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:07:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 634
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 195
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 196
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 214
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 215
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-28 12:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-28 12:10:11 --> Severity: Parsing Error --> syntax error, unexpected '$results' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:10:18 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:10:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 634
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 195
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 196
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 214
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 215
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-28 12:10:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-28 12:11:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:11:49 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:15:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-28 12:21:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-03-28 12:22:45 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-03-28 12:34:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:35:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:35:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 12:47:31 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 13:11:38 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-28 14:11:38 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-03-28 14:20:00 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-03-28 14:22:50 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-28 14:29:37 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-03-28 14:29:37 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-03-28 14:44:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 15:01:12 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-28 15:05:28 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-28 15:05:42 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-28 15:05:54 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-28 15:06:35 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-28 15:13:09 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-28 15:13:51 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-03-28 15:13:59 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-03-28 15:26:18 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-28 15:26:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 15:27:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-28 15:28:01 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
