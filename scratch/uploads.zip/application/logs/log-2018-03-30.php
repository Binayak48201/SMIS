<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-30 08:55:26 --> Query error: Duplicate entry '15-140-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('15', 'First Term', '1', '140', '100', '45', '20', '70', 1)
ERROR - 2018-03-30 08:56:25 --> Query error: Duplicate entry '15-140-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('15', 'First Term', '1', '140', '100', '45', '20', '70', 1)
ERROR - 2018-03-30 10:29:10 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 10:29:58 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 10:32:48 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 10:32:53 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 10:33:53 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 10:34:10 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 10:34:54 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 10:35:34 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 14:04:30 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 14:34:44 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 14:35:15 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 14:35:38 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 14:37:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-30 14:38:07 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 14:38:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-30 14:39:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-30 14:40:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-30 14:40:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-30 14:40:58 --> Severity: Notice --> Undefined property: stdClass::$USER_NAME C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 157
ERROR - 2018-03-30 14:42:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-30 14:43:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 14:45:51 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 14:45:51 --> Severity: Notice --> Undefined variable: ci C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 269
ERROR - 2018-03-30 14:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 269
ERROR - 2018-03-30 14:45:51 --> Severity: Error --> Call to a member function userdata() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 269
ERROR - 2018-03-30 14:49:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 14:56:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 14:57:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 14:58:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 14:59:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 14:59:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:02:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:02:00 --> Severity: Notice --> Undefined variable: ci C:\xampp\htdocs\smis\application\helpers\General_Helper.php 278
ERROR - 2018-03-30 15:02:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\helpers\General_Helper.php 278
ERROR - 2018-03-30 15:02:00 --> Severity: Error --> Call to a member function select() on null C:\xampp\htdocs\smis\application\helpers\General_Helper.php 278
ERROR - 2018-03-30 15:02:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:03:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:05:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:05:03 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\smis\application\helpers\General_Helper.php 287
ERROR - 2018-03-30 15:05:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:06:21 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:08:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:10:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:11:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:16:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:16:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:18:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:19:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-30 15:23:17 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-30 15:26:57 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-30 15:30:58 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-30 15:31:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:33:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-30 15:38:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-03-30 15:38:52 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-03-30 15:51:03 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-03-30 15:51:03 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-03-30 15:51:04 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-03-30 15:51:04 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-03-30 16:10:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:10:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:10:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:10:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:10:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:12:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:12:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:12:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 6
ERROR - 2018-03-30 16:22:06 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-03-30 16:23:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Class_reports_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-03-30 16:24:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Class_reports_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-03-30 16:24:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Class_reports_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-03-30 16:37:22 --> Query error: Unknown column 's.employee_id' in 'on clause' - Invalid query: SELECT *
FROM `class_days` `cd`
JOIN `section` `s` ON `s`.`section_id` = `cd`.`section_id`
JOIN `employee` `e` ON `s`.`employee_id` = `cd`.`employee_id`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
WHERE `s`.`batch` = 2073
ERROR - 2018-03-30 16:54:11 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 69
ERROR - 2018-03-30 16:54:11 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 69
ERROR - 2018-03-30 16:55:21 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 16:55:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 64
ERROR - 2018-03-30 16:57:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 65
ERROR - 2018-03-30 16:57:19 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 16:57:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 16:57:52 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 16:57:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 16:59:05 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 16:59:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 17:01:49 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 17:01:49 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 17:01:56 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-30 17:04:44 --> Query error: Duplicate entry '125-13' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('02:01', '84', '125', '13', '2018-02-06', '2018-03-02', '11')
ERROR - 2018-03-30 17:04:55 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 17:04:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 17:05:55 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-03-30 17:05:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
