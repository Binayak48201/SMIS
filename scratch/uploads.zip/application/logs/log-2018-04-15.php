<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-15 09:17:30 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 90
ERROR - 2018-04-15 09:30:21 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:21 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:21 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:21 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:21 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:21 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:21 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:21 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:22 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:23 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:30:24 --> 404 Page Not Found: /index
ERROR - 2018-04-15 09:38:49 --> Severity: Notice --> Undefined variable: piesGradesGender C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 35
ERROR - 2018-04-15 09:38:49 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 35
ERROR - 2018-04-15 09:38:49 --> Severity: Notice --> Undefined variable: piesGradesGender C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 96
ERROR - 2018-04-15 09:38:49 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 96
ERROR - 2018-04-15 09:40:28 --> Severity: Notice --> Undefined variable: piesGradesGender C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 90
ERROR - 2018-04-15 09:40:28 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 90
ERROR - 2018-04-15 09:45:58 --> Severity: Notice --> Undefined variable: opr C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 25
ERROR - 2018-04-15 09:45:59 --> Severity: Notice --> Undefined variable: opr C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 25
ERROR - 2018-04-15 09:46:19 --> Severity: Notice --> Undefined variable: opr C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 25
ERROR - 2018-04-15 09:46:21 --> Severity: Notice --> Undefined variable: opr C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 25
ERROR - 2018-04-15 10:02:11 --> Severity: error --> Exception: Unable to locate the model you have specified: General_reports_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-04-15 10:04:48 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\smis\application\modules\pages\views\general_content\ajax_bus_student_list.php 35
ERROR - 2018-04-15 10:11:33 --> Severity: Notice --> Undefined property: stdClass::$section C:\xampp\htdocs\smis\application\modules\pages\views\general_content\ajax_bus_student_list.php 36
ERROR - 2018-04-15 10:26:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-15 10:26:37 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 10
ERROR - 2018-04-15 10:26:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 10
ERROR - 2018-04-15 10:26:37 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 49
ERROR - 2018-04-15 10:26:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 49
ERROR - 2018-04-15 10:26:37 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 64
ERROR - 2018-04-15 10:26:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 64
ERROR - 2018-04-15 10:26:37 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2018-04-15 10:26:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2018-04-15 10:26:37 --> 404 Page Not Found: ../modules/pages/controllers/reports/Class_reports/%3Cdiv%20style=
ERROR - 2018-04-15 10:26:56 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 10
ERROR - 2018-04-15 10:26:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 10
ERROR - 2018-04-15 10:26:56 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 49
ERROR - 2018-04-15 10:26:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 49
ERROR - 2018-04-15 10:26:56 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 64
ERROR - 2018-04-15 10:26:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 64
ERROR - 2018-04-15 10:26:56 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2018-04-15 10:26:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2018-04-15 10:26:56 --> 404 Page Not Found: ../modules/pages/controllers/reports/Class_reports/%3Cdiv%20style=
ERROR - 2018-04-15 10:27:13 --> 404 Page Not Found: ../modules/pages/controllers/reports/Class_reports/%3Cdiv%20style=
ERROR - 2018-04-15 13:17:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-15 13:17:26 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-15 13:37:00 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-15 13:37:13 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-04-15 15:41:38 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-15 15:41:46 --> 404 Page Not Found: /index
ERROR - 2018-04-15 15:41:46 --> 404 Page Not Found: /index
ERROR - 2018-04-15 15:46:52 --> Query error: Duplicate entry 'One-2074-Computer' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2074', 'One', 'Computer', '50', '20', 'OPTIONAL')
ERROR - 2018-04-15 16:05:42 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-15 16:05:42 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-15 16:07:32 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-15 16:07:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-15 16:09:10 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-15 16:09:10 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-15 16:09:40 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-15 16:09:40 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-15 16:11:53 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-15 16:11:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-15 16:12:13 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-15 16:12:13 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
