<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-26 09:47:43 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-26 09:47:48 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-26 09:56:25 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
