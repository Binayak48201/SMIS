<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-02 09:22:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Payments_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-03-02 09:24:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Payments_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-03-02 09:24:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Payments_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-03-02 09:26:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Payments_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-03-02 10:28:34 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-03-02 11:40:07 --> Query error: Duplicate entry '2073-Seven-7B' for key 'uniqueSection' - Invalid query: INSERT INTO `section` (`batch`, `grade`, `section_name`) VALUES ('2073', 'Seven', '7B')
ERROR - 2018-03-02 12:31:29 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-03-02 12:37:27 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-02 12:37:38 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:49 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 12:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:31:36 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:32:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:33:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:36:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-02 14:37:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-02 14:42:33 --> 404 Page Not Found: ../modules/pages/controllers/exam/Marks_entry/marks_entry
ERROR - 2018-03-02 15:19:14 --> 404 Page Not Found: ../modules/pages/controllers/exam/Marks_entry/marks_entry
ERROR - 2018-03-02 15:19:16 --> Severity: Warning --> Missing argument 1 for Marks_entry_model::get_exams(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php on line 388 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 18
ERROR - 2018-03-02 15:19:16 --> Severity: Notice --> Undefined variable: info C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 20
ERROR - 2018-03-02 15:19:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 20
ERROR - 2018-03-02 15:19:16 --> Severity: Notice --> Undefined variable: info C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 21
ERROR - 2018-03-02 15:19:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 21
ERROR - 2018-03-02 15:24:18 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:28 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:28 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:28 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:28 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:24:28 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:28:15 --> Severity: Warning --> Missing argument 1 for Marks_entry_model::get_exams(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php on line 387 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 18
ERROR - 2018-03-02 15:28:15 --> Severity: Notice --> Undefined variable: info C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 20
ERROR - 2018-03-02 15:28:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 20
ERROR - 2018-03-02 15:28:15 --> Severity: Notice --> Undefined variable: info C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 21
ERROR - 2018-03-02 15:28:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 21
ERROR - 2018-03-02 15:28:28 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 15:28:33 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/get_exam_overall
ERROR - 2018-03-02 15:28:50 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 15:28:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\exam\ajax_exams.php 2
ERROR - 2018-03-02 15:28:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\exam\ajax_exams.php 2
ERROR - 2018-03-02 15:30:45 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 15:32:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-02 15:32:57 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:10 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:33:11 --> 404 Page Not Found: /index
ERROR - 2018-03-02 15:36:08 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 15:43:36 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 15:45:32 --> Query error: Unknown column 's.batch_id' in 'where clause' - Invalid query: SELECT `e`.*
FROM `exam` `e`
JOIN `section` `s` ON `s`.`section_id` = `e`.`section_id`
WHERE `s`.`batch_id` = '2073'
GROUP BY `e`.`numeric_value`
ERROR - 2018-03-02 15:45:44 --> Query error: Unknown column 's.batch_id' in 'where clause' - Invalid query: SELECT `e`.*
FROM `exam` `e`
JOIN `section` `s` ON `s`.`section_id` = `e`.`section_id`
WHERE `s`.`batch_id` = '2073'
GROUP BY `e`.`numeric_value`
ERROR - 2018-03-02 15:48:46 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 15:48:51 --> Severity: Notice --> Undefined index: batch_id C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 394
ERROR - 2018-03-02 15:50:41 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 15:52:49 --> Severity: Warning --> Missing argument 1 for Subject_manager_model::get_subject_opt(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php on line 396 and defined C:\xampp\htdocs\smis\application\modules\pages\models\classes\Subject_manager_model.php 21
ERROR - 2018-03-02 15:52:49 --> Severity: Warning --> Missing argument 2 for Subject_manager_model::get_subject_opt(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php on line 396 and defined C:\xampp\htdocs\smis\application\modules\pages\models\classes\Subject_manager_model.php 21
ERROR - 2018-03-02 15:52:49 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\models\classes\Subject_manager_model.php 24
ERROR - 2018-03-02 15:52:49 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\models\classes\Subject_manager_model.php 25
ERROR - 2018-03-02 15:59:13 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 46
ERROR - 2018-03-02 16:00:30 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 47
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:37 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:00:55 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 47
ERROR - 2018-03-02 16:00:56 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 47
ERROR - 2018-03-02 16:01:01 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 25
ERROR - 2018-03-02 16:01:02 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 25
ERROR - 2018-03-02 16:01:12 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 47
ERROR - 2018-03-02 16:01:14 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 47
ERROR - 2018-03-02 16:01:18 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 47
ERROR - 2018-03-02 16:14:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:26 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:41 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:17:42 --> 404 Page Not Found: /index
ERROR - 2018-03-02 16:25:25 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 37
ERROR - 2018-03-02 16:25:25 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 146
ERROR - 2018-03-02 16:25:25 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `s`
WHERE `tr`.`st_id` IS NULL
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` IS NULL
ERROR - 2018-03-02 16:25:47 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 37
ERROR - 2018-03-02 16:25:47 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 146
ERROR - 2018-03-02 16:25:47 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `s`
WHERE `tr`.`st_id` IS NULL
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` IS NULL
ERROR - 2018-03-02 16:26:22 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 146
ERROR - 2018-03-02 16:26:22 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `s`
WHERE `tr`.`st_id` IS NULL
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:27:30 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 146
ERROR - 2018-03-02 16:27:30 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `s`
WHERE `tr`.`st_id` IS NULL
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:28:17 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 146
ERROR - 2018-03-02 16:28:17 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `s`
WHERE `tr`.`st_id` IS NULL
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:28:59 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 146
ERROR - 2018-03-02 16:28:59 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`st_id` IS NULL
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:29:16 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`st_id` = '1218'
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:29:17 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`st_id` = '1218'
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:30:17 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`st_id` = '1218'
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:30:30 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`st_id` = '1218'
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:30:31 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`st_id` = '1218'
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:30:53 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`st_id` = '1218'
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:30:55 --> Query error: Unknown column 'tr.st_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`st_id` = '1218'
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:31:46 --> Query error: Unknown column 'tr.exam_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`student_id` = '1218'
AND `tr`.`subject_id` = '125'
AND `tr`.`exam_id` = '1'
ERROR - 2018-03-02 16:34:39 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 127
ERROR - 2018-03-02 16:34:39 --> Query error: Unknown column 'stm.st_id' in 'where clause' - Invalid query: SELECT *
FROM `st_marks` `stm`
JOIN `exam` `e` ON `e`.`exam_id` = `stm`.`exam_id`
WHERE `stm`.`st_id` IS NULL
AND `stm`.`subject_id` = '125'
AND `e`.`numeric_value` = '1'
ERROR - 2018-03-02 16:36:03 --> Query error: Unknown column 'stm.st_id' in 'where clause' - Invalid query: SELECT *
FROM `st_marks` `stm`
JOIN `exam` `e` ON `e`.`exam_id` = `stm`.`exam_id`
WHERE `stm`.`st_id` = '1218'
AND `stm`.`subject_id` = '125'
AND `e`.`numeric_value` = '1'
ERROR - 2018-03-02 16:36:05 --> Query error: Unknown column 'stm.st_id' in 'where clause' - Invalid query: SELECT *
FROM `st_marks` `stm`
JOIN `exam` `e` ON `e`.`exam_id` = `stm`.`exam_id`
WHERE `stm`.`st_id` = '1218'
AND `stm`.`subject_id` = '125'
AND `e`.`numeric_value` = '1'
ERROR - 2018-03-02 16:36:15 --> Query error: Unknown column 'stm.st_id' in 'where clause' - Invalid query: SELECT *
FROM `st_marks` `stm`
JOIN `exam` `e` ON `e`.`exam_id` = `stm`.`exam_id`
WHERE `stm`.`st_id` = '1218'
AND `stm`.`subject_id` = '125'
AND `e`.`numeric_value` = '1'
ERROR - 2018-03-02 16:36:17 --> Query error: Unknown column 'stm.st_id' in 'where clause' - Invalid query: SELECT *
FROM `st_marks` `stm`
JOIN `exam` `e` ON `e`.`exam_id` = `stm`.`exam_id`
WHERE `stm`.`st_id` = '1218'
AND `stm`.`subject_id` = '125'
AND `e`.`numeric_value` = '1'
ERROR - 2018-03-02 16:36:19 --> Query error: Unknown column 'stm.st_id' in 'where clause' - Invalid query: SELECT *
FROM `st_marks` `stm`
JOIN `exam` `e` ON `e`.`exam_id` = `stm`.`exam_id`
WHERE `stm`.`st_id` = '1218'
AND `stm`.`subject_id` = '125'
AND `e`.`numeric_value` = '1'
ERROR - 2018-03-02 16:36:20 --> Query error: Unknown column 'stm.st_id' in 'where clause' - Invalid query: SELECT *
FROM `st_marks` `stm`
JOIN `exam` `e` ON `e`.`exam_id` = `stm`.`exam_id`
WHERE `stm`.`st_id` = '1218'
AND `stm`.`subject_id` = '125'
AND `e`.`numeric_value` = '1'
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:09 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:42:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 42
ERROR - 2018-03-02 16:50:48 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-02 16:53:55 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
