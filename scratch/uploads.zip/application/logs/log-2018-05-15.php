<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-15 13:48:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\demo\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-05-15 13:52:57 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\demo\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-05-15 13:52:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\demo\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-05-15 13:55:00 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\demo\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-05-15 13:55:16 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\demo\application\modules\pages\views\reports\class_rank.php 87
