<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-29 09:29:05 --> 404 Page Not Found: /index
ERROR - 2018-01-29 09:29:09 --> 404 Page Not Found: /index
ERROR - 2018-01-29 09:56:28 --> Severity: Error --> Call to undefined method Ajax_model::get_class_routine() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 145
ERROR - 2018-01-29 09:56:31 --> Severity: Error --> Call to undefined method Ajax_model::get_class_routine() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 145
ERROR - 2018-01-29 10:40:48 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-29 10:40:54 --> 404 Page Not Found: /index
ERROR - 2018-01-29 10:40:54 --> 404 Page Not Found: /index
ERROR - 2018-01-29 10:40:54 --> 404 Page Not Found: /index
ERROR - 2018-01-29 10:40:54 --> 404 Page Not Found: /index
ERROR - 2018-01-29 10:43:50 --> Severity: Notice --> Undefined variable: site_url C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 342
ERROR - 2018-01-29 10:43:50 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 342
ERROR - 2018-01-29 10:44:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Evaluation_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-01-29 10:44:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Evaluation_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-01-29 10:45:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Evaluation_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-01-29 10:45:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Evaluation_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-01-29 10:46:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Evaluation_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-01-29 11:04:13 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-29 11:05:58 --> Severity: Notice --> Undefined property: CI::$employee_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-01-29 11:05:58 --> Severity: Error --> Call to a member function get_departments() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Attendance.php 36
ERROR - 2018-01-29 11:08:20 --> Severity: Notice --> Undefined variable: class_day C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Attendance.php 36
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Undefined index: ssection C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Attendance.php 40
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 59
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:17:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 117
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Undefined index: ssection C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Attendance.php 40
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 112
ERROR - 2018-01-29 11:20:59 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-29 11:26:47 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 114
ERROR - 2018-01-29 11:26:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 114
ERROR - 2018-01-29 11:26:47 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 114
ERROR - 2018-01-29 11:26:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 114
ERROR - 2018-01-29 11:28:23 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 58
ERROR - 2018-01-29 11:28:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 58
ERROR - 2018-01-29 11:28:23 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 58
ERROR - 2018-01-29 11:28:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 58
ERROR - 2018-01-29 11:28:23 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:28:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:28:23 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:28:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:29:54 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:29:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:29:54 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:29:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:32:50 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:32:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:32:50 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:32:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 137
ERROR - 2018-01-29 11:34:48 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:34:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:34:48 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:34:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:15 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:15 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:30 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:30 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 142
ERROR - 2018-01-29 11:35:46 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:35:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:35:46 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:35:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:35:59 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:35:59 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:36:05 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:36:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:36:05 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:36:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:36:13 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:36:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:36:13 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-29 11:36:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
