<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-04 10:31:25 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:31:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:35:46 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 10:35:50 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 10:36:13 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 10:39:32 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:39:41 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:42:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 10:47:27 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:04:45 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 11:05:30 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 11:22:52 --> 404 Page Not Found: /index
ERROR - 2018-02-04 13:28:02 --> Severity: Error --> Class 'Appraisal_manager_model' not found C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 228
ERROR - 2018-02-04 13:51:21 --> 404 Page Not Found: ../modules/pages/controllers/classes/Appraisal_manager/i
ERROR - 2018-02-04 14:05:20 --> Severity: Error --> Call to undefined method Appraisal_manager_model::get_head_titles() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 78
ERROR - 2018-02-04 14:25:14 --> 404 Page Not Found: ../modules/pages/controllers/classes/Appraisal_manager/add_title
ERROR - 2018-02-04 14:27:35 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 14:27:43 --> 404 Page Not Found: /index
ERROR - 2018-02-04 14:28:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 14:28:20 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 14:28:31 --> 404 Page Not Found: /index
ERROR - 2018-02-04 14:41:48 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-04 14:41:52 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-04 14:42:00 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-04 14:56:02 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 88
ERROR - 2018-02-04 15:05:05 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-04 15:05:12 --> 404 Page Not Found: /index
ERROR - 2018-02-04 15:05:19 --> 404 Page Not Found: /index
ERROR - 2018-02-04 15:05:26 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-04 15:05:33 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-04 15:07:06 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-04 15:33:56 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 129
ERROR - 2018-02-04 15:34:53 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 128
ERROR - 2018-02-04 15:34:56 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 128
ERROR - 2018-02-04 15:36:19 --> Query error: Unknown column 'head_name' in 'field list' - Invalid query: INSERT INTO `appraisal_fields` (`head_name`) VALUES ('ECA')
ERROR - 2018-02-04 15:36:54 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 128
ERROR - 2018-02-04 15:56:20 --> Severity: Error --> Class 'Evaluation_criteria_manager_model' not found C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 228
ERROR - 2018-02-04 15:59:57 --> Severity: Error --> Call to undefined method Evaluation_criteria_manager_model::add_head() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 59
ERROR - 2018-02-04 16:06:19 --> Severity: Notice --> Undefined variable: head_id C:\xampp\htdocs\smis\application\modules\pages\models\classes\evaluation_criteria_manager_model.php 49
ERROR - 2018-02-04 16:07:01 --> Severity: Error --> Call to undefined method Evaluation_criteria_manager_model::add_title() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 151
