<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-28 18:09:17 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
