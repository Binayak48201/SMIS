<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-29 10:00:56 --> Query error: Duplicate entry '15-138-100' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('15', 'First Term', '100', '138', '100', '45', '20', '', 1)
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:09:54 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:12:06 --> Query error: Duplicate entry '13-121-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('13', 'First Term', '1', '121', '100', '45', '20', '70', 1)
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:15:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-29 10:16:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-29 10:46:21 --> Query error: Duplicate entry '15-139-100' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('15', 'First Term', '100', '139', '100', '45', '20', '', 1)
ERROR - 2018-03-29 11:40:46 --> Query error: Duplicate entry '16-149-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('16', 'First Term', '1', '149', '100', '45', '20', '70', 1)
ERROR - 2018-03-29 11:42:29 --> Query error: Duplicate entry '16-151-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('16', 'First Term', '1', '151', '100', '45', '20', '70', 1)
ERROR - 2018-03-29 14:46:52 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-29 14:47:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 14:48:37 --> Query error: Unknown column 'se.section_id' in 'on clause' - Invalid query: SELECT *
FROM `subject_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `se`.`exam_id`
ERROR - 2018-03-29 14:48:53 --> Query error: Unknown column 'se.section_id' in 'on clause' - Invalid query: SELECT *
FROM `subject_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `se`.`exam_id`
ERROR - 2018-03-29 14:50:07 --> Query error: Unknown column 'e.section_id' in 'on clause' - Invalid query: SELECT *
FROM `subject_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `e`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `se`.`exam_id`
ERROR - 2018-03-29 14:53:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 14:56:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 14:59:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 14:59:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:00:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:01:56 --> Severity: Parsing Error --> syntax error, unexpected ':' C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 323
ERROR - 2018-03-29 15:02:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:03:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:03:46 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:04:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:20:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:20:03 --> Severity: Notice --> Undefined property: stdClass::$subject_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 309
ERROR - 2018-03-29 15:21:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 667
ERROR - 2018-03-29 15:21:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:21:07 --> Severity: Notice --> Undefined property: stdClass::$subject_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 309
ERROR - 2018-03-29 15:21:38 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:22:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:23:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-29 15:41:12 --> Severity: Notice --> Undefined variable: main_content C:\xampp\htdocs\smis\application\modules\pages\views\template.php 4
ERROR - 2018-03-29 15:41:12 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 347
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 45
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 52
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 52
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 52
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 52
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 52
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 52
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 97
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 97
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 100
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 100
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 158
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 158
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 162
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 162
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 164
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 164
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 168
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 168
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 170
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 170
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 175
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 175
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 177
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 177
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 181
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 181
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 181
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 181
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 183
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 183
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 187
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 187
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 187
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 187
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 189
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 189
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 193
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 193
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 195
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 195
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 199
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 199
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 201
ERROR - 2018-03-29 15:42:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 201
ERROR - 2018-03-29 15:42:58 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-03-29 15:44:53 --> Severity: Notice --> Undefined property: CI::$student_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-29 15:44:53 --> Severity: Error --> Call to a member function get_st_details() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\home.php 73
ERROR - 2018-03-29 15:45:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:45:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:46:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:48:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:50:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:50:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:51:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:52:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:52:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:52:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:52:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:53:31 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:54:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 15:55:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-03-29 16:03:32 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-29 16:05:56 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-29 16:10:00 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-29 16:10:56 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-29 16:15:19 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-29 16:15:24 --> 404 Page Not Found: ../modules/pages/controllers/exam/Exam_setting/view_terminal_total
ERROR - 2018-03-29 16:15:34 --> 404 Page Not Found: ../modules/pages/controllers/exam/Exam_setting/view_terminal_total
ERROR - 2018-03-29 16:16:08 --> 404 Page Not Found: ../modules/pages/controllers/exam/Exam_setting/view_terminal_total
ERROR - 2018-03-29 16:16:09 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-29 16:17:04 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-29 16:18:42 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-03-29 16:25:59 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
