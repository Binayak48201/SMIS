<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-09 09:42:55 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 09:55:06 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 09:55:30 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 10:06:19 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 10:07:33 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-09 10:15:23 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 10:21:04 --> Severity: Warning --> base64_encode() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Academic_report.php 116
ERROR - 2018-03-09 10:25:00 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/print_all
ERROR - 2018-03-09 10:30:10 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/print_all
ERROR - 2018-03-09 10:30:11 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/print_all
ERROR - 2018-03-09 10:30:21 --> Severity: Notice --> Undefined index: theme_option C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Academic_report.php 144
ERROR - 2018-03-09 10:30:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Academic_report.php 144
ERROR - 2018-03-09 10:30:21 --> Severity: Notice --> Undefined index: theme_option C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Academic_report.php 148
ERROR - 2018-03-09 10:30:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Academic_report.php 148
ERROR - 2018-03-09 10:49:12 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 10:51:17 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-09 11:23:15 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 11:27:25 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 11:31:34 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-09 13:19:02 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 13:19:13 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-09 13:39:56 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-09 13:43:18 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 13:51:47 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:43 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:45 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:47 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:47 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:47 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 14:17:57 --> 404 Page Not Found: ../modules/pages/controllers/reports//index
ERROR - 2018-03-09 15:01:17 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 15:04:19 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-09 15:07:45 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 15:15:32 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 15:19:53 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 15:30:01 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 15:37:14 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 15:45:26 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-09 15:49:40 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/assets
ERROR - 2018-03-09 15:57:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-09 15:57:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-09 15:57:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-09 16:37:40 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
