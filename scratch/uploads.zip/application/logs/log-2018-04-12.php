<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-12 15:46:41 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-12 15:57:16 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-12 15:58:05 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-12 15:59:50 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
