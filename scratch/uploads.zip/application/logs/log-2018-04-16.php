<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-16 08:59:44 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 08:59:44 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 08:59:44 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 09:00:08 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 09:00:08 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 09:00:08 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 09:01:54 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 09:01:54 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 09:01:54 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2018-04-16 11:50:14 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-16 11:50:18 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-16 11:50:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-16 11:51:03 --> Severity: Warning --> Missing argument 2 for Lession_plan::activity() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 675
ERROR - 2018-04-16 11:51:03 --> Severity: Notice --> Undefined variable: file C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 677
ERROR - 2018-04-16 11:51:03 --> Severity: Notice --> Undefined index: extension C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 680
ERROR - 2018-04-16 12:43:18 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-16 12:43:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-16 13:04:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:04:35 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:05:44 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-04-16 13:06:35 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-16 13:16:06 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-16 13:16:14 --> 404 Page Not Found: /index
ERROR - 2018-04-16 13:16:14 --> 404 Page Not Found: /index
