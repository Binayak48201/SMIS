<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-09 11:12:22 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-09 11:12:26 --> 404 Page Not Found: /index
ERROR - 2018-04-09 11:12:30 --> 404 Page Not Found: /index
ERROR - 2018-04-09 11:12:33 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-04-09 11:13:13 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-09 11:13:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-09 11:31:01 --> 404 Page Not Found: /index
ERROR - 2018-04-09 11:31:11 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-09 11:31:38 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-09 11:34:35 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-09 11:37:19 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-09 12:00:39 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-09 12:04:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 75
ERROR - 2018-04-09 12:15:16 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-04-09 12:16:41 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-09 12:16:54 --> Severity: Notice --> Undefined property: stdClass::$guardian_relation C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 487
ERROR - 2018-04-09 12:18:39 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-09 12:18:47 --> 404 Page Not Found: /index
ERROR - 2018-04-09 12:18:47 --> 404 Page Not Found: /index
ERROR - 2018-04-09 12:19:02 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-04-09 12:20:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-09 12:49:18 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-09 12:49:18 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-09 12:50:40 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-09 12:50:40 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-09 12:52:46 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-09 12:52:46 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-09 12:53:14 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-09 12:53:14 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-09 12:59:07 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-09 12:59:07 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-09 13:00:42 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-09 13:00:42 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-09 13:01:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-09 13:01:28 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-09 13:02:29 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-09 13:02:29 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-09 13:13:52 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-09 13:13:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-09 13:15:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-09 14:08:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-09 14:57:07 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-09 14:58:32 --> Query error: Duplicate entry 'One-2073-Computer' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2073', 'One', 'Computer', '50', '30', 'COMPULSORY')
