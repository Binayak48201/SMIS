<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-21 10:35:01 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-02-21 10:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-02-21 10:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-02-21 10:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-02-21 10:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-02-21 10:35:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-02-21 14:08:07 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-02-21 14:08:51 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-02-21 14:09:32 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:26:59 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 167
ERROR - 2018-02-21 16:29:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 170
ERROR - 2018-02-21 16:29:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-21 16:35:23 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
