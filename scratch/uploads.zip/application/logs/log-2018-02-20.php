<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-20 10:22:13 --> Query error: Unknown column 's.subject_name' in 'field list' - Invalid query: SELECT `cd`.*, `sc`.`section_name`, `sc`.`section_id`, `s`.`subject_name`, `sc`.`grade`, `sc`.`class_teacher_id`
FROM `section` `sc`
JOIN `class_days` `cd` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `sc`.`class_teacher_id` = '11'
AND `cd`.`start_date` <= '2018-02-20'
AND `cd`.`end_date` >= '2018-02-20'
ERROR - 2018-02-20 10:26:06 --> 404 Page Not Found: ../modules/pages/controllers/profile//index
ERROR - 2018-02-20 10:39:38 --> 404 Page Not Found: ../modules/pages/controllers/profile//index
ERROR - 2018-02-20 10:40:18 --> 404 Page Not Found: ../modules/pages/controllers/profile//index
ERROR - 2018-02-20 10:40:33 --> 404 Page Not Found: ../modules/pages/controllers/profile//index
ERROR - 2018-02-20 10:40:36 --> 404 Page Not Found: ../modules/pages/controllers/profile//index
ERROR - 2018-02-20 10:41:03 --> Severity: Notice --> Undefined property: CI::$appeaisal_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-02-20 10:41:03 --> Severity: Error --> Call to a member function get_appraisals() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 157
ERROR - 2018-02-20 10:41:11 --> Severity: Notice --> Undefined property: CI::$appeaisal_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-02-20 10:41:11 --> Severity: Error --> Call to a member function get_appraisals() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 157
ERROR - 2018-02-20 10:41:19 --> Severity: Notice --> Undefined property: CI::$appeaisal_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-02-20 10:41:19 --> Severity: Error --> Call to a member function get_appraisals() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 157
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:42:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:11 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 28
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Undefined variable: option C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 10:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 29
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:30 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 33
ERROR - 2018-02-20 11:06:31 --> Severity: Notice --> Undefined property: stdClass::$grade_name C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 34
ERROR - 2018-02-20 11:37:46 --> Query error: Unknown column 'student_id' in 'where clause' - Invalid query: SELECT *
FROM `appraisal_fields`
WHERE `student_id` = '1199'
AND `section_id` = '8'
AND `exam_id` = '11'
AND `field_id` = '1'
ERROR - 2018-02-20 11:38:17 --> Query error: Unknown column 'student_id' in 'where clause' - Invalid query: SELECT *
FROM `appraisal_fields`
WHERE `student_id` = ''
AND `section_id` = '8'
AND `exam_id` = ''
AND `field_id` = '1'
ERROR - 2018-02-20 11:39:38 --> Query error: Unknown column 'student_id' in 'where clause' - Invalid query: SELECT *
FROM `appraisal_fields`
WHERE `student_id` = ''
AND `section_id` = '8'
AND `exam_id` = ''
AND `field_id` = '1'
ERROR - 2018-02-20 11:41:24 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:41:30 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:44:05 --> Query error: Unknown column 'student_id' in 'where clause' - Invalid query: SELECT *
FROM `appraisal_fields`
WHERE `student_id` = '1204'
AND `section_id` = '8'
AND `exam_id` = ''
AND `field_id` = '1'
ERROR - 2018-02-20 11:44:07 --> Query error: Unknown column 'student_id' in 'where clause' - Invalid query: SELECT *
FROM `appraisal_fields`
WHERE `student_id` = '1204'
AND `section_id` = '8'
AND `exam_id` = '11'
AND `field_id` = '1'
ERROR - 2018-02-20 11:47:10 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: UPDATE `appraisal` SET `user_id` = '11', `evaluation_id` = '', `grade` = 'A+'
WHERE `student_id` = '1199'
AND `section_id` = '8'
AND `exam_id` = '11'
AND `field_id` = '1'
ERROR - 2018-02-20 11:47:11 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: UPDATE `appraisal` SET `user_id` = '11', `evaluation_id` = '', `grade` = 'A+'
WHERE `student_id` = '1199'
AND `section_id` = '8'
AND `exam_id` = '11'
AND `field_id` = '1'
ERROR - 2018-02-20 11:48:45 --> Severity: Notice --> Undefined variable: ap_fields C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:48:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:48:45 --> Severity: Notice --> Undefined variable: ap_fields C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:48:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:48:45 --> Severity: Notice --> Undefined variable: ap_fields C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:48:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:49:51 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-20 11:49:58 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-20 11:50:02 --> 404 Page Not Found: /index
ERROR - 2018-02-20 11:50:51 --> Severity: Warning --> Missing argument 1 for Appraisal_manager::get_head_field() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 162
ERROR - 2018-02-20 11:50:51 --> Severity: Notice --> Undefined variable: head_id C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 164
ERROR - 2018-02-20 11:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:50:52 --> Severity: Warning --> Missing argument 1 for Appraisal_manager::get_head_field() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 162
ERROR - 2018-02-20 11:50:52 --> Severity: Notice --> Undefined variable: head_id C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 164
ERROR - 2018-02-20 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:50:52 --> Severity: Warning --> Missing argument 1 for Appraisal_manager::get_head_field() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 162
ERROR - 2018-02-20 11:50:52 --> Severity: Notice --> Undefined variable: head_id C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 164
ERROR - 2018-02-20 11:50:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:04 --> Module controller failed to run: pages/appraisal_manager/get_head_field/test
ERROR - 2018-02-20 11:51:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:05 --> Module controller failed to run: pages/appraisal_manager/get_head_field/test
ERROR - 2018-02-20 11:51:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:05 --> Module controller failed to run: pages/appraisal_manager/get_head_field/test
ERROR - 2018-02-20 11:51:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:07 --> Module controller failed to run: pages/appraisal_manager/get_head_field/test
ERROR - 2018-02-20 11:51:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:07 --> Module controller failed to run: pages/appraisal_manager/get_head_field/test
ERROR - 2018-02-20 11:51:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:07 --> Module controller failed to run: pages/appraisal_manager/get_head_field/test
ERROR - 2018-02-20 11:51:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:16 --> Module controller failed to run: pages/appraisal_manager/get_head_field/
ERROR - 2018-02-20 11:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:16 --> Module controller failed to run: pages/appraisal_manager/get_head_field/
ERROR - 2018-02-20 11:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:16 --> Module controller failed to run: pages/appraisal_manager/get_head_field/
ERROR - 2018-02-20 11:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:29 --> Module controller failed to run: pages/appraisal_manager/get_head_field/
ERROR - 2018-02-20 11:51:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:29 --> Module controller failed to run: pages/appraisal_manager/get_head_field/
ERROR - 2018-02-20 11:51:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:51:29 --> Module controller failed to run: pages/appraisal_manager/get_head_field/
ERROR - 2018-02-20 11:51:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\appraisal_evaluation.php 23
ERROR - 2018-02-20 11:52:39 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: UPDATE `appraisal` SET `user_id` = '11', `evaluation_id` = '', `grade` = 'B'
WHERE `student_id` = '1199'
AND `section_id` = '8'
AND `exam_id` = '11'
AND `field_id` = '1'
ERROR - 2018-02-20 11:59:19 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: UPDATE `appraisal` SET `user_id` = '11', `evaluation_id` = '', `grade` = 'B'
WHERE `student_id` = '1205'
AND `section_id` = '8'
AND `exam_id` = '11'
AND `field_id` = '1'
ERROR - 2018-02-20 11:59:57 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`, `user_id`, `field_id`, `grade`) VALUES ('1199', '8', '11', '11', '1', 'A+')
ERROR - 2018-02-20 12:00:07 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`, `user_id`, `field_id`, `grade`) VALUES ('1199', '8', '11', '11', '1', 'A+')
ERROR - 2018-02-20 12:01:21 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`, `user_id`, `grade`) VALUES ('1199', '8', '11', '11', 'A+')
ERROR - 2018-02-20 12:02:06 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `exam_id`, `user_id`, `field_id`, `grade`) VALUES ('1199', '11', '11', '1', 'A+')
ERROR - 2018-02-20 12:02:43 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`appraisal`, CONSTRAINT `FK_appraisal` FOREIGN KEY (`field_id`) REFERENCES `appraisal_fields` (`field_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`) VALUES ('1199', '8', '11')
ERROR - 2018-02-20 12:02:50 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`appraisal`, CONSTRAINT `FK_appraisal` FOREIGN KEY (`field_id`) REFERENCES `appraisal_fields` (`field_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`) VALUES ('1199', '8', '11')
ERROR - 2018-02-20 12:02:53 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`appraisal`, CONSTRAINT `FK_appraisal` FOREIGN KEY (`field_id`) REFERENCES `appraisal_fields` (`field_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`) VALUES ('1199', '8', '11')
ERROR - 2018-02-20 12:02:58 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`appraisal`, CONSTRAINT `FK_appraisal` FOREIGN KEY (`field_id`) REFERENCES `appraisal_fields` (`field_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`) VALUES ('1199', '8', '11')
ERROR - 2018-02-20 12:03:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`appraisal`, CONSTRAINT `FK_appraisal` FOREIGN KEY (`field_id`) REFERENCES `appraisal_fields` (`field_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`) VALUES ('1199', '8', '11')
ERROR - 2018-02-20 12:03:24 --> Severity: Notice --> Undefined variable: q C:\xampp\htdocs\smis\application\modules\pages\models\classes\Appraisal_manager_model.php 100
ERROR - 2018-02-20 12:03:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\models\classes\Appraisal_manager_model.php 99
ERROR - 2018-02-20 12:04:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`appraisal`, CONSTRAINT `FK_appraisal` FOREIGN KEY (`field_id`) REFERENCES `appraisal_fields` (`field_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `appraisal` (`student_id`) VALUES ('1199')
ERROR - 2018-02-20 12:04:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`appraisal`, CONSTRAINT `FK_appraisal` FOREIGN KEY (`field_id`) REFERENCES `appraisal_fields` (`field_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `appraisal` (`student_id`) VALUES ('1199')
ERROR - 2018-02-20 12:04:49 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`appraisal`, CONSTRAINT `FK_appraisal` FOREIGN KEY (`field_id`) REFERENCES `appraisal_fields` (`field_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `appraisal` (`student_id`) VALUES ('1199')
ERROR - 2018-02-20 12:07:28 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`, `user_id`, `field_id`, `grade`) VALUES ('1199', '8', '11', '11', '1', 'A')
ERROR - 2018-02-20 12:07:40 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`, `user_id`, `field_id`, `grade`) VALUES ('1199', '8', '11', '11', 1, 'A')
ERROR - 2018-02-20 12:09:56 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`, `user_id`, `field_id`, `grade`) VALUES ('1199', '8', '11', '11', 1, 'A')
ERROR - 2018-02-20 12:11:39 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`, `user_id`, `field_id`, `grade`) VALUES ('1199', '8', '11', '11', 1, 'A')
ERROR - 2018-02-20 12:11:45 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `appraisal` (`student_id`, `section_id`, `exam_id`, `user_id`, `field_id`, `grade`) VALUES ('1199', '8', '11', '11', '1', 'A')
ERROR - 2018-02-20 13:55:36 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 13:55:41 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:16 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:56:21 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:05 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
ERROR - 2018-02-20 15:58:11 --> 404 Page Not Found: /index
