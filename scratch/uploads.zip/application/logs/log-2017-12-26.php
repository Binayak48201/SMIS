<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-26 10:19:24 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-26 10:22:17 --> Query error: Unknown column 'section_id' in 'where clause' - Invalid query: SELECT *
FROM `student`
WHERE `section_id` = '8'
ERROR - 2017-12-26 10:24:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-26 10:24:53 --> Severity: Notice --> Undefined index: sgarde C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 240
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 132
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 142
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 132
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 142
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 132
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 142
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 132
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 142
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 132
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 142
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 132
ERROR - 2017-12-26 10:25:35 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 142
ERROR - 2017-12-26 10:25:35 --> 404 Page Not Found: ../modules/pages/controllers/profile/Student/%3Cdiv%20style=
ERROR - 2017-12-26 10:31:14 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:14 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:14 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:14 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:14 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:14 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:14 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:14 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:14 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:14 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:14 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:14 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:34 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:34 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:34 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:34 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:34 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:34 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:34 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:34 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:34 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:34 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:34 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:34 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:47 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:47 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:47 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:47 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:47 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:47 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 130
ERROR - 2017-12-26 10:31:47 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:47 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:47 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:47 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:47 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:31:47 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:12 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:12 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:12 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:12 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:12 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:12 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:53 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:53 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:53 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:53 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:53 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:32:53 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:42:24 --> 404 Page Not Found: ../modules/pages/controllers/profile/Student/edit
ERROR - 2017-12-26 10:42:58 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-26 10:43:15 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:43:15 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:43:15 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:43:15 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:43:15 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:43:15 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:44:16 --> 404 Page Not Found: ../modules/pages/controllers/profile/Student/edit
ERROR - 2017-12-26 10:49:22 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-26 10:49:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-26 10:49:57 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:49:57 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:49:57 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:49:57 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:49:57 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:49:57 --> 404 Page Not Found: /index
ERROR - 2017-12-26 10:59:51 --> Query error: Table 'smis.students' doesn't exist - Invalid query: SELECT *
FROM `students`
WHERE `student_id` = '1202'
ERROR - 2017-12-26 11:04:54 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-26 11:06:39 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-26 11:06:44 --> 404 Page Not Found: /index
ERROR - 2017-12-26 11:06:44 --> 404 Page Not Found: /index
ERROR - 2017-12-26 11:06:44 --> 404 Page Not Found: /index
ERROR - 2017-12-26 11:06:44 --> 404 Page Not Found: /index
ERROR - 2017-12-26 11:06:44 --> 404 Page Not Found: /index
ERROR - 2017-12-26 11:06:44 --> 404 Page Not Found: /index
