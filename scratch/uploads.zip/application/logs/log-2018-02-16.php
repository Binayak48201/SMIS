<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-16 11:56:40 --> Severity: Notice --> Undefined property: CI::$marks_entry_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-02-16 11:56:40 --> Severity: Error --> Call to a member function get_section_exams() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Section_manager.php 211
ERROR - 2018-02-16 12:36:50 --> 404 Page Not Found: ../modules/pages/controllers/profile/Evaluation/add_evaluation
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:14:38 --> Severity: Notice --> Use of undefined constant data - assumed 'data' C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 16
ERROR - 2018-02-16 13:14:39 --> Severity: Notice --> Use of undefined constant data - assumed 'data' C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 16
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 27
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_class_evalution.php 41
ERROR - 2018-02-16 13:16:40 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 23
ERROR - 2018-02-16 13:38:54 --> Query error: Unknown column 'section_id' in 'where clause' - Invalid query: SELECT *
FROM `parent_evaluation`
WHERE `section_id` = '8'
AND `exam_id` = '11'
AND `student_id` = '1199'
AND `evaluation_type_id` = '1'
ERROR - 2018-02-16 13:39:33 --> Query error: Unknown column 'section_id' in 'where clause' - Invalid query: SELECT *
FROM `parent_evaluation`
WHERE `section_id` = '8'
AND `exam_id` = '11'
AND `student_id` = '1199'
AND `evaluation_type_id` = '1'
ERROR - 2018-02-16 13:40:36 --> Query error: Unknown column 'section_id' in 'where clause' - Invalid query: SELECT *
FROM `parent_evaluation`
WHERE `section_id` = '8'
AND `exam_id` = ''
AND `student_id` = ''
AND `evaluation_type_id` = '1'
ERROR - 2018-02-16 14:33:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 208
ERROR - 2018-02-16 14:34:51 --> Severity: Notice --> Undefined variable: Value C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 182
ERROR - 2018-02-16 14:34:51 --> Severity: Notice --> Undefined variable: Value C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 183
ERROR - 2018-02-16 14:34:51 --> Severity: Notice --> Undefined variable: Value C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 184
ERROR - 2018-02-16 14:40:06 --> 404 Page Not Found: ../modules/pages/controllers/profile/Evaluation/ternimal_comment
ERROR - 2018-02-16 14:40:46 --> Query error: Unknown column 'terminal_id' in 'field list' - Invalid query: INSERT INTO `parent_evaluation` (`student_id`, `section_id`, `terminal_id`, `user_id`, `comment`) VALUES ('1199', '8', '11', '11', 'test')
ERROR - 2018-02-16 14:41:27 --> Query error: Unknown column 'terminal_id' in 'field list' - Invalid query: INSERT INTO `parent_evaluation` (`student_id`, `section_id`, `terminal_id`, `user_id`, `comment`) VALUES ('1199', '8', '11', '11', 'hgfgh')
ERROR - 2018-02-16 14:43:30 --> Query error: Unknown column 'terminal_id' in 'field list' - Invalid query: INSERT INTO `parent_evaluation` (`student_id`, `section_id`, `terminal_id`, `user_id`, `comment`) VALUES ('1199', '8', '11', '11', 'sdasd')
ERROR - 2018-02-16 14:45:17 --> Query error: Unknown column 'terminal_id' in 'field list' - Invalid query: INSERT INTO `parent_evaluation` (`student_id`, `section_id`, `terminal_id`, `user_id`, `comment`) VALUES ('1199', '8', '11', '11', 'sdasdasd')
ERROR - 2018-02-16 14:45:39 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `terminal_comment` (`student_id`, `section_id`, `terminal_id`, `user_id`, `comment`) VALUES ('1199', '8', '11', '11', 'sdasdasd')
ERROR - 2018-02-16 14:46:25 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `terminal_comment` (`student_id`, `section_id`, `terminal_id`, `user_id`, `comment`) VALUES ('1199', '8', '11', '11', 'sdasdasd')
ERROR - 2018-02-16 14:47:14 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `terminal_comment` (`student_id`, `user_id`, `comment`) VALUES ('1199', '11', 'gsdfgsdfg')
ERROR - 2018-02-16 15:45:55 --> 404 Page Not Found: ../modules/pages/controllers/profile//index
