<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-06 09:58:14 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-06 09:58:21 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 09:59:44 --> 404 Page Not Found: /index
ERROR - 2018-04-06 10:00:00 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-06 10:00:08 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 10:17:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 10:19:02 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 10:19:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 10:20:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 12:19:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:37:22 --> Severity: Notice --> Undefined property: stdClass::$exam_id C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 13:40:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Class_report_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-04-06 13:41:47 --> Severity: Notice --> Undefined property: CI::$class_report_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-04-06 13:41:47 --> Severity: Error --> Call to a member function grade_progress_status() on null C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 69
ERROR - 2018-04-06 13:48:41 --> Query error: Column 'status' in group statement is ambiguous - Invalid query: SELECT COUNT(student_id) as num
FROM `terminal_result` `tr`
JOIN `exam` `e` ON `e`.`exam_id` = `tr`.`terminal_id`
WHERE `tr`.`grade` = 'One'
AND `e`.`numeric_value` = '3'
GROUP BY `status`
ERROR - 2018-04-06 13:58:30 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-06 13:58:40 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-06 13:59:07 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-06 13:59:35 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-06 14:04:58 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-06 14:05:47 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-06 14:07:41 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 100
ERROR - 2018-04-06 14:38:43 --> Severity: Notice --> Undefined variable: notification C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 29
ERROR - 2018-04-06 14:43:59 --> Severity: Notice --> Undefined variable: notification C:\xampp\htdocs\smis\application\modules\pages\controllers\home.php 17
ERROR - 2018-04-06 14:59:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Manage_menu_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:00:47 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:00:47 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:00:47 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:00:47 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:00:47 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:00:47 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:00:47 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:01:18 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\notification.php 68
ERROR - 2018-04-06 15:03:12 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:12 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:12 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:12 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:12 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:12 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:12 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:39 --> Severity: Notice --> Undefined property: stdClass::$ROLE_ID C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 70
ERROR - 2018-04-06 15:03:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:03:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 73
ERROR - 2018-04-06 15:04:13 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\manage_notification.php 75
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:04:39 --> Severity: Notice --> Undefined property: stdClass::$usertype C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 63
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$ROLE_ID C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$ROLE_ID C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$ROLE_ID C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$ROLE_ID C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$ROLE_ID C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$ROLE_ID C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$ROLE_ID C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, boolean given C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:05:15 --> Severity: Notice --> Undefined property: stdClass::$usertype_id C:\xampp\htdocs\smis\application\modules\pages\views\edit_notification.php 53
ERROR - 2018-04-06 15:11:30 --> Query error: Column 'added_by' cannot be null - Invalid query: INSERT INTO `notification` (`usertype_id`, `notification_title`, `msg`, `added_by`, `by_user_type`) VALUES ('a:1:{i:0;s:1:\"3\";}', 'test Notification', 'this ti to notify that notification module workd', NULL, NULL)
ERROR - 2018-04-06 15:13:00 --> Query error: Column 'added_by' cannot be null - Invalid query: INSERT INTO `notification` (`usertype_id`, `notification_title`, `msg`, `added_by`, `by_user_type`) VALUES ('a:1:{i:0;s:1:\"3\";}', 'test Notification', 'this ti to notify that notification module workd', NULL, NULL)
ERROR - 2018-04-06 15:15:05 --> Query error: Column 'added_by' cannot be null - Invalid query: INSERT INTO `notification` (`usertype_id`, `notification_title`, `msg`, `added_by`, `by_user_type`) VALUES ('a:1:{i:0;s:1:\"3\";}', 'test Notification', 'this ti to notify that notification module workd', NULL, NULL)
ERROR - 2018-04-06 15:30:13 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 53
ERROR - 2018-04-06 15:30:13 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-06 15:30:13 --> Severity: Notice --> Undefined property: stdClass::$email_add C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 103
ERROR - 2018-04-06 15:30:13 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 109
ERROR - 2018-04-06 15:30:13 --> Severity: Notice --> Undefined property: stdClass::$department C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 119
ERROR - 2018-04-06 15:30:13 --> Severity: Notice --> Undefined property: stdClass::$program_name C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 121
ERROR - 2018-04-06 15:30:13 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-06 15:31:25 --> Severity: Notice --> Undefined property: stdClass::$email_add C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 90
ERROR - 2018-04-06 15:31:25 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 96
ERROR - 2018-04-06 15:31:25 --> Severity: Notice --> Undefined property: stdClass::$department C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 106
ERROR - 2018-04-06 15:31:25 --> Severity: Notice --> Undefined property: stdClass::$program_name C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 108
ERROR - 2018-04-06 15:32:08 --> Severity: Notice --> Undefined property: stdClass::$email_add C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 91
ERROR - 2018-04-06 15:32:08 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 97
ERROR - 2018-04-06 15:32:08 --> Severity: Notice --> Undefined property: stdClass::$department C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 107
ERROR - 2018-04-06 15:32:08 --> Severity: Notice --> Undefined property: stdClass::$program_name C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 109
ERROR - 2018-04-06 16:16:54 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-06 16:17:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 16:17:36 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 16:18:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:21:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:23:26 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-06 16:25:24 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-06 16:25:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:25:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:25:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:25:50 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:26:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:26:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:26:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-06 16:27:11 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-06 16:31:37 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-06 16:36:49 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-06 16:37:08 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 16:37:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-06 16:39:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 75
