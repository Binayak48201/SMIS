<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-15 16:01:04 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
ERROR - 2018-02-15 16:01:09 --> 404 Page Not Found: /index
