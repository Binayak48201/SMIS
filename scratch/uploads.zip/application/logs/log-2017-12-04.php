<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-04 15:01:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Programlevel_model C:\xampp\htdocs\smis\system\core\Loader.php 344
