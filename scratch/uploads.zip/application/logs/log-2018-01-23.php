<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 40
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 46
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 52
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 58
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 64
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 70
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 76
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 82
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 90
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 91
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 92
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 104
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 104
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 112
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 118
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 126
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 127
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 134
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 142
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 143
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 144
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 151
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 157
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 163
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 180
ERROR - 2018-01-23 15:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 180
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 40
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 46
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 52
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 58
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 64
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 70
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 76
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 82
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 90
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 91
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 92
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 104
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 104
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 112
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 118
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 126
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 127
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 134
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 142
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 143
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 144
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 151
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 157
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 163
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 180
ERROR - 2018-01-23 15:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_employee.php 180
ERROR - 2018-01-23 15:09:45 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 58
ERROR - 2018-01-23 15:10:02 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 58
ERROR - 2018-01-23 16:45:15 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 58
ERROR - 2018-01-23 16:45:19 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 58
ERROR - 2018-01-23 16:45:42 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 58
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 2
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 2
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 2
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 5
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 5
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 9
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 9
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 9
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 12
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 15
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 18
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 21
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 24
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 27
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 30
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 33
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 36
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 39
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 42
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 45
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 48
ERROR - 2018-01-23 16:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\employee_profile.php 51
ERROR - 2018-01-23 16:46:16 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/%3Cdiv%20style=
