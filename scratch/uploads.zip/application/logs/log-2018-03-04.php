<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-04 08:36:07 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 08:36:17 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:20:38 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:21:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:22:17 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:23:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:23:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 10:23:07 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 10:34:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:37:50 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:41:54 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 10:49:22 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:43 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:44 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:50:44 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:36 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 10:53:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:53:59 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:12 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:14 --> 404 Page Not Found: /index
ERROR - 2018-03-04 10:54:18 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 11:01:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 11:19:11 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:19:31 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:20:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:23:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:24:06 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:00 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:41:09 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:13 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:45:24 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:47:37 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:05 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 11:49:16 --> 404 Page Not Found: /index
ERROR - 2018-03-04 13:42:48 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 285
ERROR - 2018-03-04 13:43:23 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 15:43:40 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 15:43:54 --> Query error: Unknown column 'tr.subject_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`student_id` = '1214'
AND `tr`.`subject_id` = '125'
AND `tr`.`terminal_id` = '1'
ERROR - 2018-03-04 15:44:31 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 15:44:37 --> Query error: Unknown column 'tr.subject_id' in 'where clause' - Invalid query: SELECT *
FROM `terminal_result` `tr`
WHERE `tr`.`student_id` = '1214'
AND `tr`.`subject_id` = '125'
AND `tr`.`terminal_id` = '1'
ERROR - 2018-03-04 16:06:08 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 16:09:06 --> Query error: Unknown column 's.student_id' in 'field list' - Invalid query: SELECT `s`.`student_id`
FROM `terminal_result` `tr`
WHERE `tr`.`student_id` = '1214'
AND `tr`.`grade` = 'One'
AND `tr`.`terminal_id` = '1'
ERROR - 2018-03-04 16:10:16 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 16:10:37 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:14:40 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:16:30 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:21:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 16:24:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-04 16:28:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-04 16:35:35 --> Query error: Unknown column 's.student_id' in 'on clause' - Invalid query: SELECT *, `fr`.`final_mark` as `total_marks`
FROM `final_result` `fr`
JOIN `subject` `s` ON `s`.`student_id` = `fr`.`student_id`
WHERE `fr`.`student_id` = '1214'
AND `fr`.`subject_id` = '125'
ERROR - 2018-03-04 16:35:49 --> Query error: Unknown column 's.student_id' in 'on clause' - Invalid query: SELECT *, `fr`.`final_mark` as `total_marks`
FROM `final_result` `fr`
JOIN `subject` `s` ON `s`.`student_id` = `fr`.`student_id`
WHERE `fr`.`student_id` = '1214'
AND `fr`.`subject_id` = '125'
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 53
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$full_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:36:36 --> Severity: Notice --> Undefined property: stdClass::$pass_mark C:\xampp\htdocs\smis\application\modules\pages\views\exam\view_terminal_total.php 55
ERROR - 2018-03-04 16:38:32 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-04 16:53:25 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-04 16:55:05 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-04 16:59:49 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-04 17:01:22 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-04 17:02:51 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:02:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
ERROR - 2018-03-04 17:03:31 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-04 17:03:59 --> Severity: Parsing Error --> syntax error, unexpected ''%'' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_terminal_total.php 90
