<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-23 11:36:50 --> 404 Page Not Found: ../modules/theme_option/controllers/User_account/index.html
ERROR - 2018-03-23 11:38:39 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-23 16:14:04 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:28 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:29 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:30 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:14:31 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:04 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:04 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:04 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:04 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:04 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:05 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:06 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:07 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:18:09 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:21:46 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-23 16:24:19 --> Query error: Unknown column 'o.occupation_name' in 'field list' - Invalid query: SELECT `s`.*, `u`.`USER_NAME`, `sc`.*, `o`.`occupation_name`
FROM `student` `s`
JOIN `section` `sc` ON `sc`.`section_id` = `s`.`class_id`
LEFT JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
WHERE DATE_FORMAT(FROM_UNIXTIME(st_dob),'%m-%d') = DATE_FORMAT(NOW(),'%m-%d')
ORDER BY `st_fname` ASC
ERROR - 2018-03-23 16:24:26 --> Severity: Notice --> Undefined variable: districts C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 53
ERROR - 2018-03-23 16:24:36 --> Severity: Notice --> Undefined variable: districts C:\xampp\htdocs\smis\application\modules\pages\views\reports\birthday_students.php 53
ERROR - 2018-03-23 16:29:17 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:29:17 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:29:17 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:30:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:30:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:30:08 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:30:22 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:30:22 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:30:22 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:31:16 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:31:16 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:31:16 --> 404 Page Not Found: /index
ERROR - 2018-03-23 16:31:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:33:22 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-23 16:40:19 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-23 16:41:18 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-23 16:42:02 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-23 16:42:19 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-23 16:48:41 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-23 16:52:02 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:52:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:52:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:52:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:52:46 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:53:29 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:55:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:55:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:55:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:55:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:55:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:56:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:57:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:57:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:57:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 16:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 16:57:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 28
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 31
ERROR - 2018-03-23 17:04:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 70
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 25
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 25
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 25
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 28
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 31
ERROR - 2018-03-23 17:04:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 70
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 28
ERROR - 2018-03-23 17:04:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 31
ERROR - 2018-03-23 17:04:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 70
ERROR - 2018-03-23 17:04:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:04:49 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:04:51 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:04:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:04:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 28
ERROR - 2018-03-23 17:04:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 31
ERROR - 2018-03-23 17:04:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 70
ERROR - 2018-03-23 17:04:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 25
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 25
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 25
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 28
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 31
ERROR - 2018-03-23 17:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 70
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 28
ERROR - 2018-03-23 17:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 31
ERROR - 2018-03-23 17:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 70
ERROR - 2018-03-23 17:06:11 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:07:04 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-23 17:07:09 --> Severity: Warning --> Missing argument 1 for Ajax::get_exam_info() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 163
ERROR - 2018-03-23 17:07:09 --> Severity: Warning --> Missing argument 2 for Ajax::get_exam_info() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 163
ERROR - 2018-03-23 17:07:09 --> Severity: Warning --> Missing argument 3 for Ajax::get_exam_info() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 163
ERROR - 2018-03-23 17:07:09 --> Severity: Warning --> Missing argument 4 for Ajax::get_exam_info() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 163
ERROR - 2018-03-23 17:07:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 166
ERROR - 2018-03-23 17:07:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 166
ERROR - 2018-03-23 17:07:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 166
ERROR - 2018-03-23 17:07:09 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 166
ERROR - 2018-03-23 17:10:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:11:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:12:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:12:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:12:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:12:38 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:12:49 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:14:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-23 17:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-23 17:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-23 17:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 69
ERROR - 2018-03-23 17:17:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:18:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:19:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:20:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:22:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:22:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:23:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:26:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:27:49 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:28:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:30:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:31:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:33:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:34:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:35:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:36:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:37:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:39:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:40:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:40:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:40:50 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:41:17 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:41:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:43:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:43:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 600
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 600
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:44:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:44:50 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:44:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:45:31 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 607
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:46:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 608
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 608
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:46:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:46:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:47:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:47:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:47:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:47:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:47:51 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:47:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:48:11 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:48:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:49:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 608
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 608
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 608
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 608
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 608
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 608
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-23 17:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-23 17:51:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:52:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:53:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:53:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:53:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:55:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:56:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:56:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:56:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-23 17:57:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
