<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-02 12:01:36 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-02-02 12:01:58 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-02-02 12:02:34 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-02-02 12:06:00 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-02 12:06:08 --> 404 Page Not Found: /index
ERROR - 2018-02-02 12:06:08 --> 404 Page Not Found: /index
ERROR - 2018-02-02 12:06:08 --> 404 Page Not Found: /index
ERROR - 2018-02-02 12:06:08 --> 404 Page Not Found: /index
ERROR - 2018-02-02 12:06:08 --> 404 Page Not Found: /index
ERROR - 2018-02-02 12:06:08 --> 404 Page Not Found: /index
ERROR - 2018-02-02 12:06:08 --> 404 Page Not Found: /index
