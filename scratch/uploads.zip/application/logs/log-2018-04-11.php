<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-11 10:33:28 --> Query error: Duplicate entry 'One-2074-Computer' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2074', 'One', 'Computer', '50', '20', 'OPTIONAL')
ERROR - 2018-04-11 10:33:39 --> Query error: Duplicate entry 'One-2074-Computer' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2074', 'One', 'Computer', '50', '20', 'OPTIONAL')
ERROR - 2018-04-11 10:34:36 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-11 10:34:51 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:34:51 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:35:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-04-11 10:36:39 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:36:55 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:36:55 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:48:55 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:49:13 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:49:13 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:49:39 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:49:48 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:49:59 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:50:25 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:50:50 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:51:09 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:51:20 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:51:31 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:51:40 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:51:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:51:57 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:51:57 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:52:10 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-11 10:52:37 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-11 10:52:45 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:52:45 --> 404 Page Not Found: /index
ERROR - 2018-04-11 10:53:08 --> Severity: Notice --> Undefined property: stdClass::$guardian_relation C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 487
ERROR - 2018-04-11 12:59:06 --> Query error: Duplicate entry 'One-2074-English' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2074', 'One', 'English', '100', '40', 'COMPULSORY')
ERROR - 2018-04-11 13:04:34 --> Query error: Duplicate entry 'One-2073-English' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2073', 'One', 'English', '100', '40', 'COMPULSORY')
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-11 13:06:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-11 14:23:16 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-11 14:23:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-11 14:23:27 --> Severity: Notice --> Undefined variable: lession_activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 77
ERROR - 2018-04-11 14:23:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 77
ERROR - 2018-04-11 14:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 35
ERROR - 2018-04-11 14:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 36
ERROR - 2018-04-11 14:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 37
ERROR - 2018-04-11 14:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 38
ERROR - 2018-04-11 14:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 39
ERROR - 2018-04-11 14:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Undefined variable: activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 35
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 35
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Undefined variable: activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 36
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 36
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Undefined variable: activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 37
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 37
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Undefined variable: activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 38
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 38
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Undefined variable: activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 39
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 39
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Undefined variable: activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Undefined variable: activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Undefined variable: activity C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 40
ERROR - 2018-04-11 14:49:42 --> Severity: Notice --> Undefined variable: Activities C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 7
ERROR - 2018-04-11 14:49:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 7
ERROR - 2018-04-11 14:49:42 --> Severity: Notice --> Undefined variable: Activities C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 12
ERROR - 2018-04-11 14:49:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 12
ERROR - 2018-04-11 14:49:42 --> Severity: Notice --> Undefined variable: Activities C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 18
ERROR - 2018-04-11 14:49:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 18
ERROR - 2018-04-11 14:49:42 --> Severity: Notice --> Undefined variable: Activities C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 24
ERROR - 2018-04-11 14:49:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 24
ERROR - 2018-04-11 14:49:42 --> Severity: Notice --> Undefined variable: Activities C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 29
ERROR - 2018-04-11 14:49:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 29
ERROR - 2018-04-11 14:49:42 --> Severity: Notice --> Undefined variable: Activities C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 34
ERROR - 2018-04-11 14:49:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 34
ERROR - 2018-04-11 14:49:42 --> Severity: Notice --> Undefined variable: Activities C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 39
ERROR - 2018-04-11 14:49:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_detail.php 39
