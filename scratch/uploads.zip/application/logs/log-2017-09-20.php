<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-20 09:42:17 --> Severity: Error --> Class 'Mx_Controller' not found C:\xampp\htdocs\smis\application\modules\dashboard\controllers\user_log.php 4
ERROR - 2017-09-20 09:45:10 --> Severity: Notice --> Undefined property: CI::$occupation_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-09-20 09:45:10 --> Severity: Error --> Call to a member function get_occupation() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\general_content\Transportation.php 37
ERROR - 2017-09-20 09:46:05 --> Severity: Error --> Class 'Transportation_model' not found C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 228
ERROR - 2017-09-20 09:46:15 --> Severity: Error --> Class 'Transportation_model' not found C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 228
ERROR - 2017-09-20 09:46:57 --> Severity: Notice --> Undefined property: CI::$occupation_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-09-20 09:46:57 --> Severity: Error --> Call to a member function get_occupation() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\general_content\Transportation.php 38
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:50:20 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 77
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 79
ERROR - 2017-09-20 09:55:38 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\occupation.php 80
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:55:58 --> Severity: Notice --> Undefined property: stdClass::$occupation_id C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 88
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:56:15 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 09:57:34 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\Transportation.php 87
ERROR - 2017-09-20 11:02:17 --> 404 Page Not Found: ../modules/pages/controllers/general_content/Transportation/add
ERROR - 2017-09-20 12:27:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 19
ERROR - 2017-09-20 12:28:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 19
ERROR - 2017-09-20 12:28:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 19
ERROR - 2017-09-20 13:42:02 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 32
ERROR - 2017-09-20 13:42:13 --> Severity: Notice --> Undefined index: bus_name C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 32
ERROR - 2017-09-20 13:52:24 --> Severity: Error --> Call to undefined function dump() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 32
ERROR - 2017-09-20 13:52:34 --> Severity: Error --> Call to undefined function dump() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 32
ERROR - 2017-09-20 13:52:39 --> Severity: Error --> Call to undefined function dump() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 32
ERROR - 2017-09-20 13:55:30 --> Severity: Notice --> Undefined index: bus_name C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 31
ERROR - 2017-09-20 14:20:57 --> Severity: Notice --> Undefined property: stdClass::$drop_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\ajax_bus_stop.php 20
ERROR - 2017-09-20 14:20:57 --> Severity: Notice --> Undefined property: stdClass::$drop_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\ajax_bus_stop.php 20
ERROR - 2017-09-20 14:20:57 --> Severity: Notice --> Undefined property: stdClass::$drop_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\ajax_bus_stop.php 20
ERROR - 2017-09-20 14:20:57 --> Severity: Notice --> Undefined property: stdClass::$drop_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\ajax_bus_stop.php 20
ERROR - 2017-09-20 14:20:57 --> Severity: Notice --> Undefined property: stdClass::$drop_name C:\xampp\htdocs\smis\application\modules\pages\views\general_content\ajax_bus_stop.php 20
ERROR - 2017-09-20 15:00:57 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/delete_bus_stopss
ERROR - 2017-09-20 15:06:37 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/delete_bus_stopss
ERROR - 2017-09-20 15:06:57 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/delete_bus_stopss
ERROR - 2017-09-20 15:08:07 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/delete_bus_stopss
ERROR - 2017-09-20 15:09:12 --> Severity: Warning --> Missing argument 1 for Ajax::delete_bus_stops() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 23
