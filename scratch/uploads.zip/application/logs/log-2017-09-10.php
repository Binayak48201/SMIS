<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-10 10:04:14 --> Query error: Table 'smis.theme_option' doesn't exist - Invalid query: SELECT *
FROM `theme_option`
