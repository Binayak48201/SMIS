<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:12:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:13:01 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:14:35 --> Query error: Duplicate entry '19-142-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('19', 'First Term', '1', '142', '100', '45', '20', '', 1)
ERROR - 2018-04-01 09:21:19 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 09:21:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 09:21:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 09:21:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 09:21:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 09:23:19 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 09:23:19 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:24:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-01 09:40:12 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-01 09:44:07 --> Query error: Duplicate entry '147-21' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '80', '147', '21', '2018-04-01', '2018-04-30', '5')
ERROR - 2018-04-01 09:44:31 --> Query error: Duplicate entry '147-21' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '80', '147', '21', '2018-04-01', '2018-04-30', '5')
ERROR - 2018-04-01 09:45:33 --> Query error: Duplicate entry '149-21' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '73', '149', '21', '2018-04-01', '2018-04-30', '80')
ERROR - 2018-04-01 09:45:53 --> Query error: Duplicate entry '149-21' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '73', '149', '21', '2018-04-01', '2018-04-30', '80')
ERROR - 2018-04-01 09:46:07 --> Query error: Duplicate entry '149-21' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '83', '149', '21', '2018-04-01', '2018-04-30', '5')
ERROR - 2018-04-01 09:54:51 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\guardian_list_class.php 90
ERROR - 2018-04-01 09:56:44 --> Query error: Duplicate entry '21-149-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('21', 'First Term', '1', '149', '100', '45', '20', '80', 1)
ERROR - 2018-04-01 09:57:36 --> Query error: Duplicate entry '21-151-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('21', 'First Term', '1', '151', '100', '45', '20', '80', 1)
ERROR - 2018-04-01 10:03:45 --> Query error: Duplicate entry '153-22' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('10:00', '82', '153', '22', '2017-02-07', '2018-02-02', '67')
ERROR - 2018-04-01 10:07:55 --> Query error: Duplicate entry '156-22' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('13:30', '11', '156', '22', '2017-02-07', '2018-02-02', '84')
ERROR - 2018-04-01 10:08:56 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-01 10:09:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 10:18:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-01 10:18:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 10:25:16 --> Query error: Duplicate entry '22-158-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('22', 'First Term', '1', '158', '100', '45', '20', '', 1)
ERROR - 2018-04-01 10:27:25 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-01 10:27:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-04-01 10:46:20 --> Query error: Duplicate entry '126-13' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '82', '126', '13', '2018-04-01', '2018-04-30', '73')
ERROR - 2018-04-01 10:52:41 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-04-01 10:52:47 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 10:52:47 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 10:52:57 --> Query error: Duplicate entry '146-16' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '80', '146', '16', '2018-04-01', '2018-04-30', '73')
ERROR - 2018-04-01 10:53:46 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 10:53:46 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 10:53:54 --> Query error: Duplicate entry '146-16' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '77', '146', '16', '2018-04-01', '2018-04-30', '73')
ERROR - 2018-04-01 10:54:09 --> Query error: Duplicate entry '161-24' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:00', '77', '161', '24', '2018-04-01', '2018-04-30', '73')
ERROR - 2018-04-01 10:56:11 --> Query error: Duplicate entry '163-24' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('08:00', '73', '163', '24', '2018-04-01', '2018-04-30', '5')
ERROR - 2018-04-01 11:12:41 --> Query error: Duplicate entry '24-162-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('24', 'First Term', '1', '162', '100', '45', '20', '80', 1)
ERROR - 2018-04-01 11:14:50 --> Query error: Duplicate entry '24-164-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('24', 'First Term', '1', '164', '100', '45', '20', '80', 1)
ERROR - 2018-04-01 11:15:42 --> Query error: Duplicate entry '24-167-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('24', 'First Term', '1', '167', '100', '45', '20', '80', 1)
ERROR - 2018-04-01 11:16:31 --> Query error: Duplicate entry '24-168-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('24', 'First Term', '1', '168', '100', '45', '20', '80', 1)
ERROR - 2018-04-01 11:17:37 --> Query error: Duplicate entry '25-162-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('25', 'First Term', '1', '162', '100', '45', '20', '80', 1)
ERROR - 2018-04-01 11:18:34 --> Query error: Duplicate entry '25-164-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`, `convert_to`, `status`) VALUES ('25', 'First Term', '1', '164', '100', '45', '20', '80', 1)
ERROR - 2018-04-01 11:23:38 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-01 11:24:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 146
ERROR - 2018-04-01 11:56:08 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-01 11:56:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:14:11 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:14:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:14:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:14:51 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:22:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 13:22:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 13:24:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 146
ERROR - 2018-04-01 13:24:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 146
ERROR - 2018-04-01 13:24:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 146
ERROR - 2018-04-01 13:24:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 146
ERROR - 2018-04-01 13:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 146
ERROR - 2018-04-01 13:25:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 146
ERROR - 2018-04-01 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:29:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 13:29:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 146
ERROR - 2018-04-01 13:30:36 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 150
ERROR - 2018-04-01 13:30:37 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 150
ERROR - 2018-04-01 13:30:52 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 150
ERROR - 2018-04-01 13:30:54 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 150
ERROR - 2018-04-01 13:31:21 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 150
ERROR - 2018-04-01 13:31:23 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 150
ERROR - 2018-04-01 13:31:24 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 150
ERROR - 2018-04-01 13:33:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 13:33:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:34:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-01 13:37:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:37:17 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-01 13:37:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:37:21 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-01 13:37:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:40:31 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-01 13:40:36 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-01 13:40:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 13:52:14 --> Query error: Unknown column 'sp.section_id' in 'on clause' - Invalid query: SELECT `sp`.*, `s`.`section_name`
FROM `student` `sp`
JOIN `section` `s` ON `s`.`section_id` = `sp`.`section_id`
JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
WHERE `st_fname` LIKE '%Aaradhya%' ESCAPE '!'
ORDER BY `sp`.`student_id` DESC
ERROR - 2018-04-01 13:52:59 --> Query error: Unknown column 's.student_id' in 'on clause' - Invalid query: SELECT `sp`.*, `s`.`section_name`
FROM `student` `sp`
JOIN `section` `s` ON `s`.`section_id` = `sp`.`class_id`
JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
WHERE `st_fname` LIKE '%Aaradhya%' ESCAPE '!'
ORDER BY `sp`.`student_id` DESC
ERROR - 2018-04-01 13:53:10 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 99
ERROR - 2018-04-01 13:53:10 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 106
ERROR - 2018-04-01 13:53:10 --> 404 Page Not Found: ../modules/pages/controllers/profile/Student/%3Cdiv%20style=
ERROR - 2018-04-01 13:53:59 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 106
ERROR - 2018-04-01 13:54:10 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 106
ERROR - 2018-04-01 13:57:20 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 106
ERROR - 2018-04-01 13:58:02 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 107
ERROR - 2018-04-01 13:58:53 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 108
ERROR - 2018-04-01 13:59:14 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 108
ERROR - 2018-04-01 13:59:53 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 108
ERROR - 2018-04-01 14:00:30 --> Severity: Notice --> Undefined property: stdClass::$USERNAME C:\xampp\htdocs\smis\application\modules\pages\views\profile\find_student.php 108
ERROR - 2018-04-01 14:05:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:07:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 14:09:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 14:09:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 14:11:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:12:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:15:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:15:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:16:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 14:18:02 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:20:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:21:52 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 14:21:52 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 14:21:57 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-01 14:22:12 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-01 14:24:40 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_marksheet.php 51
ERROR - 2018-04-01 14:28:37 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_marksheet.php 51
ERROR - 2018-04-01 14:28:37 --> Severity: Notice --> Undefined property: stdClass::$Terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_marksheet.php 92
ERROR - 2018-04-01 14:28:37 --> Severity: Notice --> Undefined property: stdClass::$Terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_marksheet.php 92
ERROR - 2018-04-01 14:28:37 --> Severity: Notice --> Undefined property: stdClass::$Terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_marksheet.php 92
ERROR - 2018-04-01 14:28:37 --> Severity: Notice --> Undefined property: stdClass::$Terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_marksheet.php 92
ERROR - 2018-04-01 14:28:48 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_marksheet.php 51
ERROR - 2018-04-01 14:33:10 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_marksheet.php 51
ERROR - 2018-04-01 14:44:55 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Academic_report.php 409
ERROR - 2018-04-01 14:46:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:49:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:50:54 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 14:51:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 14:51:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 14:51:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 14:51:22 --> 404 Page Not Found: ../modules/pages/controllers/reports/Academic_report/view_marksheet1214
ERROR - 2018-04-01 14:54:16 --> Severity: Notice --> Undefined variable: ci C:\xampp\htdocs\smis\application\helpers\General_Helper.php 278
ERROR - 2018-04-01 14:54:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\helpers\General_Helper.php 278
ERROR - 2018-04-01 14:54:16 --> Severity: Error --> Call to a member function userdata() on null C:\xampp\htdocs\smis\application\helpers\General_Helper.php 278
ERROR - 2018-04-01 14:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-04-01 14:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-04-01 14:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-04-01 14:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-04-01 15:02:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-04-01 15:02:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 22
ERROR - 2018-04-01 15:02:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 28
ERROR - 2018-04-01 15:02:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 31
ERROR - 2018-04-01 15:06:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 15:14:53 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-01 15:15:09 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-01 15:15:28 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-01 15:25:31 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-01 15:39:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 274
ERROR - 2018-04-01 15:39:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 274
ERROR - 2018-04-01 15:39:08 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 304
ERROR - 2018-04-01 15:40:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 278
ERROR - 2018-04-01 15:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 278
ERROR - 2018-04-01 15:40:12 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 308
ERROR - 2018-04-01 15:40:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 278
ERROR - 2018-04-01 15:40:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 278
ERROR - 2018-04-01 15:40:54 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 308
ERROR - 2018-04-01 15:46:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 15:53:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 291
ERROR - 2018-04-01 15:53:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 291
ERROR - 2018-04-01 15:53:10 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 321
ERROR - 2018-04-01 15:53:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 292
ERROR - 2018-04-01 15:53:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 292
ERROR - 2018-04-01 15:53:30 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 322
ERROR - 2018-04-01 15:54:17 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-01 15:54:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 292
ERROR - 2018-04-01 15:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 292
ERROR - 2018-04-01 15:54:32 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 322
ERROR - 2018-04-01 15:54:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-01 15:56:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-04-01 15:57:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-04-01 15:57:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 292
ERROR - 2018-04-01 15:57:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 292
ERROR - 2018-04-01 15:57:45 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 322
ERROR - 2018-04-01 15:57:57 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_sex C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 302
ERROR - 2018-04-01 15:58:02 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 322
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined property: stdClass::$st_gender C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 297
ERROR - 2018-04-01 15:58:41 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 312
ERROR - 2018-04-01 15:59:13 --> Severity: Notice --> Undefined variable: arr C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 312
ERROR - 2018-04-01 16:05:58 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 16:05:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-01 16:14:17 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-04-01 16:17:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 16:17:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 16:17:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 16:18:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 16:18:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 16:20:55 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-01 16:22:03 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-01 16:23:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-01 16:24:29 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 75
ERROR - 2018-04-01 16:25:25 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 75
ERROR - 2018-04-01 16:28:44 --> Severity: Error --> Call to undefined function start() C:\xampp\htdocs\smis\application\helpers\General_Helper.php 279
ERROR - 2018-04-01 16:33:44 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:35:08 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:36:07 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-01 16:37:07 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:39:41 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' C:\xampp\htdocs\smis\application\modules\pages\models\reports\general_reports_model.php 94
ERROR - 2018-04-01 16:40:22 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 399
ERROR - 2018-04-01 16:41:14 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' C:\xampp\htdocs\smis\application\modules\pages\models\reports\general_reports_model.php 94
ERROR - 2018-04-01 16:41:31 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:41:44 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:41:47 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:42:15 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:42:32 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:42:59 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:43:05 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:43:15 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\current_student_overall.php 77
ERROR - 2018-04-01 16:44:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-01 16:45:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-01 16:56:06 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-01 16:59:18 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-01 16:59:44 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-01 17:01:19 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-01 17:02:16 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-01 17:02:17 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-01 17:05:08 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-01 17:06:02 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
