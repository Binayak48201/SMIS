<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-03 12:12:50 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:12:50 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:13:11 --> 404 Page Not Found: /index
ERROR - 2017-09-03 12:15:32 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:15:32 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:19:27 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:19:27 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:20:31 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:20:31 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:20:32 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:20:32 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:20:33 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:20:33 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:20:33 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:20:33 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:20:33 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:20:33 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:20:35 --> Severity: Notice --> Undefined property: CI::$theme_model C:\xampp\htdocs\application\third_party\MX\Controller.php 59
ERROR - 2017-09-03 12:20:35 --> Severity: Error --> Call to a member function get_theme_data() on null C:\xampp\htdocs\application\modules\login\controllers\Login.php 18
ERROR - 2017-09-03 12:21:48 --> Query error: Table 'smis.theme_option' doesn't exist - Invalid query: SELECT *
FROM `theme_option`
ERROR - 2017-09-03 12:22:10 --> Severity: Error --> Call to undefined method MY_Loader::_ci_object_to_array() C:\xampp\htdocs\application\third_party\MX\Loader.php 300
ERROR - 2017-09-03 12:22:12 --> Severity: Error --> Call to undefined method MY_Loader::_ci_object_to_array() C:\xampp\htdocs\application\third_party\MX\Loader.php 300
ERROR - 2017-09-03 12:25:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Theme_model C:\xampp\htdocs\system\core\Loader.php 344
ERROR - 2017-09-03 12:27:02 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:27:02 --> Query error: Table 'smis.bill_no' doesn't exist - Invalid query: SELECT SUM(CASE WHEN bn.BILL_CANCELLED != 1 THEN bn.GROSS_VALUE ELSE 0 END) as total_income, COUNT(CASE WHEN bn.BILL_CANCELLED = 1 THEN 1 ELSE NULL END ) as cancelled, COUNT(CASE WHEN bn.BILL_CANCELLED != 1 THEN 1 ELSE NULL END ) as total_bill
FROM `bill_no` `bn`
WHERE `bn`.`ACC_CAT_ID` = 1
AND `bn`.`BILL_DATE` = '2017-09-03'
ERROR - 2017-09-03 12:28:14 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:29:14 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:29:15 --> 404 Page Not Found: /index
ERROR - 2017-09-03 12:31:32 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 208 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 212 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 242 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 239 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 240 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 241 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 222 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 223 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 198 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:31:32 --> Severity: Notice --> Undefined offset: 243 C:\xampp\htdocs\application\modules\menu\views\menu.php 22
ERROR - 2017-09-03 12:34:49 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:34:52 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:35:23 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:36:04 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:36:04 --> Query error: Table 'smis.heading' doesn't exist - Invalid query: SELECT *, `h`.`status` as `status`
FROM `heading` `h`
JOIN `heading_type` `ht` ON `ht`.`heading_type_id` = `h`.`HEADING_TYPE`
WHERE `h`.`HEADING_TYPE` = 1
AND `h`.`status` = 1
ERROR - 2017-09-03 12:36:08 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:36:12 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:36:12 --> Query error: Table 'smis.heading' doesn't exist - Invalid query: SELECT *, `h`.`status` as `status`
FROM `heading` `h`
JOIN `heading_type` `ht` ON `ht`.`heading_type_id` = `h`.`HEADING_TYPE`
WHERE `h`.`HEADING_TYPE` = 1
AND `h`.`status` = 1
ERROR - 2017-09-03 12:37:01 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:37:01 --> Severity: Notice --> Undefined variable: headings C:\xampp\htdocs\application\modules\pages\views\site_info.php 131
ERROR - 2017-09-03 12:37:01 --> Severity: Notice --> Undefined variable: headings C:\xampp\htdocs\application\modules\pages\views\site_info.php 146
ERROR - 2017-09-03 12:37:34 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:37:51 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:38:26 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:48:14 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:48:14 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\modules\theme_option\models\theme_model.php 39
ERROR - 2017-09-03 12:48:14 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\application\modules\theme_option\models\theme_model.php 40
ERROR - 2017-09-03 12:48:14 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:50:22 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:50:25 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:50:25 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:51:23 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:51:26 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:51:26 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:51:30 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:51:30 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:51:52 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:51:52 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:52:19 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:52:20 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:58:11 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:58:21 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:58:21 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:58:49 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:58:49 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\application\helpers\General_Helper.php 210
ERROR - 2017-09-03 12:59:41 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:59:50 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 12:59:50 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:00:06 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:00:07 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:00:21 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:00:21 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:01:13 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:01:42 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:01:42 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:01:48 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:01:48 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:01:51 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:01:51 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:02:45 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:04:19 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 13:04:30 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:04:57 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:07:28 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:07:35 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:07:45 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:08:19 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:08:19 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:08:22 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:09:07 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:09:57 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:10:06 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 13:10:26 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:12:20 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:12:23 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:12:23 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:12:26 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:12:26 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:12:29 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:12:29 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:13:05 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:18:50 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 13:18:59 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:19:05 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 13:31:27 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:31:29 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:31:31 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:31:39 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:31:41 --> 404 Page Not Found: ../modules/theme_option/controllers//index
ERROR - 2017-09-03 13:32:42 --> 404 Page Not Found: /index
ERROR - 2017-09-03 13:35:17 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 13:37:41 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:37:52 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:38:19 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:38:19 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:38:28 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:38:44 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:38:50 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:38:55 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:38:56 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:41:50 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:41:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Payments_model C:\xampp\htdocs\system\core\Loader.php 344
ERROR - 2017-09-03 13:42:50 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:42:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Bug_model C:\xampp\htdocs\system\core\Loader.php 344
ERROR - 2017-09-03 13:43:06 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:43:27 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:43:38 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:43:40 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:43:42 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:43:48 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:43:48 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `roles` (`ROLE_NAME`) VALUES ('test_role')
ERROR - 2017-09-03 13:44:13 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:14 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:25 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:25 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:32 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:43 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:44 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:51 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:57 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:44:57 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:01 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:03 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:04 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:20 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:21 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:35 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:36 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:37 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:45:45 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:46:01 --> 404 Page Not Found: ../modules/theme_option/controllers//index
ERROR - 2017-09-03 13:52:20 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 13:52:22 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 13:52:33 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:52:38 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:52:44 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:52:51 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:52:55 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:52:58 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:53:06 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:53:09 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:53:13 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:53:20 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:53:20 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:54:17 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:54:22 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:54:22 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:57:10 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:58:22 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:58:26 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:58:29 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:58:30 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:58:33 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:58:38 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:58:38 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 13:59:33 --> Severity: error --> Exception: Unable to locate the model you have specified: User_account_model C:\xampp\htdocs\system\core\Loader.php 344
ERROR - 2017-09-03 14:00:56 --> Severity: error --> Exception: Unable to locate the model you have specified: User_account_model C:\xampp\htdocs\system\core\Loader.php 344
ERROR - 2017-09-03 14:02:22 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 14:30:45 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 14:30:46 --> 404 Page Not Found: /index
ERROR - 2017-09-03 14:30:58 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 14:31:02 --> 404 Page Not Found: ../modules/theme_option/controllers//index
ERROR - 2017-09-03 15:34:15 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 15:34:27 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 15:34:28 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 15:34:29 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 15:34:32 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 15:34:35 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 15:34:39 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-09-03 15:34:41 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 16:02:35 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-03 16:02:37 --> Module controller failed to run: dashboard/user_log/log
