<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-21 10:19:23 --> 404 Page Not Found: ../modules/pages/controllers/classes/Subject_manager/migraste
ERROR - 2017-12-21 11:44:32 --> Query error: Unknown column 'section_id' in 'field list' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`, `section_id`) VALUES ('2072', 'One', 'English', '100', '45', 'COMPULSORY', '')
ERROR - 2017-12-21 11:45:34 --> Query error: Duplicate entry 'One-2072-English' for key 'unique_records' - Invalid query: INSERT INTO `subject` (`added_batch`, `grade`, `subject_name`, `full_marks`, `pass_marks`, `subject_type`) VALUES ('2072', 'One', 'English', '100', '45', 'COMPULSORY')
ERROR - 2017-12-21 12:07:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-21 12:07:15 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-21 12:08:20 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-21 12:09:18 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-21 12:09:40 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-21 12:09:50 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-21 12:10:30 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2017-12-21 12:51:42 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
