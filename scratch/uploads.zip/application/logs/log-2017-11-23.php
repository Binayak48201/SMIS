<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-23 12:45:06 --> 404 Page Not Found: ../modules/pages/controllers/exam//index
ERROR - 2017-11-23 12:45:30 --> 404 Page Not Found: ../modules/pages/controllers/exam/Assessment_setting/index
ERROR - 2017-11-23 12:46:49 --> Severity: Error --> Class 'Assessment_setting_model' not found C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 228
ERROR - 2017-11-23 12:47:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 179
ERROR - 2017-11-23 12:47:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 179
ERROR - 2017-11-23 12:47:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 179
ERROR - 2017-11-23 12:48:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 179
ERROR - 2017-11-23 12:48:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 179
ERROR - 2017-11-23 12:48:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 179
ERROR - 2017-11-23 12:54:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 167
ERROR - 2017-11-23 12:54:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 167
ERROR - 2017-11-23 12:54:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\assessment_setting.php 167
ERROR - 2017-11-23 13:18:52 --> 404 Page Not Found: ../modules/pages/controllers/exam/Assessment_setting/add_exam
ERROR - 2017-11-23 13:18:57 --> Severity: Error --> Call to undefined method Assessment_setting_model::get_exams() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\assessment_setting.php 129
ERROR - 2017-11-23 13:18:59 --> Severity: Error --> Call to undefined method Assessment_setting_model::get_exams() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\assessment_setting.php 129
ERROR - 2017-11-23 13:19:18 --> Severity: Error --> Call to undefined method Assessment_setting_model::get_exams() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\assessment_setting.php 129
