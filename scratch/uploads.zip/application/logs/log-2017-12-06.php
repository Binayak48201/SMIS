<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-06 13:36:14 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 140
ERROR - 2017-12-06 13:36:14 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\xampp\htdocs\smis\application\modules\pages\models\classes\lession_plan_model.php 8
ERROR - 2017-12-06 13:36:14 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 140
ERROR - 2017-12-06 13:36:14 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 140
ERROR - 2017-12-06 13:36:14 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 140
ERROR - 2017-12-06 13:36:14 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 140
ERROR - 2017-12-06 13:36:14 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 140
ERROR - 2017-12-06 13:36:14 --> Severity: Notice --> Undefined variable: res C:\xampp\htdocs\smis\application\modules\pages\models\classes\lession_plan_model.php 28
ERROR - 2017-12-06 13:36:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2017-12-06 13:37:48 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 142
ERROR - 2017-12-06 13:37:48 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\xampp\htdocs\smis\application\modules\pages\models\classes\lession_plan_model.php 8
ERROR - 2017-12-06 13:37:48 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 142
ERROR - 2017-12-06 13:37:48 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 142
ERROR - 2017-12-06 13:37:48 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 142
ERROR - 2017-12-06 13:37:48 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 142
ERROR - 2017-12-06 13:37:48 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\helpers\General_Helper.php 142
ERROR - 2017-12-06 13:37:48 --> Severity: Notice --> Undefined variable: res C:\xampp\htdocs\smis\application\modules\pages\models\classes\lession_plan_model.php 28
ERROR - 2017-12-06 13:37:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2017-12-06 13:38:17 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-12-06 14:05:38 --> 404 Page Not Found: /index
ERROR - 2017-12-06 14:05:53 --> 404 Page Not Found: /index
ERROR - 2017-12-06 14:16:52 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-12-06 14:17:51 --> Severity: Notice --> Undefined property: stdClass::$obkective C:\xampp\htdocs\smis\application\modules\pages\models\classes\lession_plan_model.php 111
ERROR - 2017-12-06 14:17:51 --> Query error: Unknown column 'obkective' in 'field list' - Invalid query: INSERT INTO `lession_plan` (`ch_id`, `main_topic`, `sub_topic`, `obkective`, `section_id`, `class_days_id`) VALUES ('1', 'introduction', 'intro topic', NULL, '1', '1296')
