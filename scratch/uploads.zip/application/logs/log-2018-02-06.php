<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-06 10:55:02 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-06 10:55:43 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:34:57 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:35:03 --> 404 Page Not Found: /index
ERROR - 2018-02-06 13:41:14 --> Severity: Notice --> Undefined variable: opt_id C:\xampp\htdocs\smis\application\modules\pages\models\classes\Evaluation_criteria_manager_model.php 9
ERROR - 2018-02-06 13:41:14 --> Severity: Notice --> Undefined variable: opt_id C:\xampp\htdocs\smis\application\modules\pages\models\classes\Evaluation_criteria_manager_model.php 12
ERROR - 2018-02-06 13:41:14 --> Severity: Notice --> Undefined variable: opt_id C:\xampp\htdocs\smis\application\modules\pages\models\classes\Evaluation_criteria_manager_model.php 15
ERROR - 2018-02-06 13:41:14 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\classes\Evaluation_criteria_manager_model.php 18
ERROR - 2018-02-06 13:41:14 --> Severity: Error --> Call to a member function num_rows() on null C:\xampp\htdocs\smis\application\modules\pages\models\classes\Evaluation_criteria_manager_model.php 18
ERROR - 2018-02-06 13:51:16 --> Severity: Warning --> Missing argument 2 for Evaluation_criteria_manager_model::delete_type(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php on line 84 and defined C:\xampp\htdocs\smis\application\modules\pages\models\classes\Evaluation_criteria_manager_model.php 45
ERROR - 2018-02-06 13:51:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\classes\Evaluation_criteria_manager_model.php 56
ERROR - 2018-02-06 14:41:32 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 161
ERROR - 2018-02-06 14:42:55 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 161
ERROR - 2018-02-06 14:43:00 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 161
ERROR - 2018-02-06 14:43:22 --> Severity: Notice --> Undefined variable: 1 C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 161
ERROR - 2018-02-06 14:43:55 --> Severity: Notice --> Undefined variable: 1 C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 161
ERROR - 2018-02-06 14:44:02 --> Severity: Notice --> Undefined variable: 1 C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 161
ERROR - 2018-02-06 14:44:38 --> Severity: Notice --> Undefined variable: 1 C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Evaluation_criteria_manager.php 160
ERROR - 2018-02-06 15:06:39 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:39 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:06:39 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:39 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:06:39 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:39 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:06:39 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:39 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:06:41 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:41 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:06:41 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:41 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:06:41 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:41 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:06:41 --> Severity: Notice --> Undefined variable: exam C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 141
ERROR - 2018-02-06 15:06:41 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:07:32 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:07:32 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:07:32 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:07:32 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:07 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 124
ERROR - 2018-02-06 15:09:07 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 124
ERROR - 2018-02-06 15:09:07 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 124
ERROR - 2018-02-06 15:09:07 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 124
ERROR - 2018-02-06 15:09:30 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 125
ERROR - 2018-02-06 15:09:30 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 125
ERROR - 2018-02-06 15:09:30 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 125
ERROR - 2018-02-06 15:09:30 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 125
ERROR - 2018-02-06 15:09:44 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:44 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:44 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:09:44 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:10:45 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:10:45 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:10:45 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:10:45 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:11:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 49
ERROR - 2018-02-06 15:11:45 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:11:45 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:11:45 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:11:45 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:11:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 49
ERROR - 2018-02-06 15:11:53 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:11:53 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:11:53 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:11:53 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:12:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 49
ERROR - 2018-02-06 15:12:08 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:12:08 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:12:08 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:12:08 --> Module controller failed to run: pages/evaluation/list_student/get_evaluation_option
ERROR - 2018-02-06 15:12:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 49
ERROR - 2018-02-06 15:12:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 49
ERROR - 2018-02-06 15:17:38 --> Severity: Error --> Call to undefined function serealize() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 153
ERROR - 2018-02-06 15:18:43 --> Severity: Warning --> unserialize() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 153
ERROR - 2018-02-06 15:32:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 49
ERROR - 2018-02-06 15:33:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 49
ERROR - 2018-02-06 15:33:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 49
