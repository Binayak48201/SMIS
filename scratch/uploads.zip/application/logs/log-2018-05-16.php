<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-16 12:27:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'smis_scratch' C:\xampp\htdocs\smis\scratch\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-16 12:27:22 --> Unable to connect to the database
ERROR - 2018-05-16 12:28:58 --> Query error: Table 'smis_scratch.theme_option' doesn't exist - Invalid query: SELECT *
FROM `theme_option`
ERROR - 2018-05-16 12:29:01 --> Query error: Table 'smis_scratch.theme_option' doesn't exist - Invalid query: SELECT *
FROM `theme_option`
ERROR - 2018-05-16 12:29:05 --> Query error: Table 'smis_scratch.theme_option' doesn't exist - Invalid query: SELECT *
FROM `theme_option`
ERROR - 2018-05-16 12:44:13 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\scratch\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:22 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:23 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:23 --> 404 Page Not Found: /index
ERROR - 2018-05-16 12:44:23 --> 404 Page Not Found: /index
