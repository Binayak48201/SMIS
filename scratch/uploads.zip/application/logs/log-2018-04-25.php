<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-25 10:44:38 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 10:45:19 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 10:45:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:08:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:10:31 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 11:11:34 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 11:11:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:13:16 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 11:13:19 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 11:17:58 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 11:18:01 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 11:18:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:18:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:18:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:20:24 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 11:20:49 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:28:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:31:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:41:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:44:29 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:51:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:53:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:57:45 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 11:57:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 11:58:51 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-25 12:03:01 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-25 12:04:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 75
ERROR - 2018-04-25 12:27:55 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-25 12:33:01 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 59
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 91
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 95
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 97
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 101
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 103
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 107
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 109
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 113
ERROR - 2018-04-25 12:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 115
ERROR - 2018-04-25 12:33:46 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-25 12:50:48 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 12:52:25 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 13:49:04 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 13:49:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 13:49:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 13:51:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 59
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 91
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 95
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 97
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 101
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 103
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 107
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 109
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 113
ERROR - 2018-04-25 13:55:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 115
ERROR - 2018-04-25 13:55:27 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 51
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 56
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 59
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 89
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 91
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 95
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 97
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 101
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 103
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 107
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 109
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 113
ERROR - 2018-04-25 14:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\teacher_home.php 115
ERROR - 2018-04-25 14:08:05 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-25 14:09:29 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-25 14:33:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 14:43:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-25 14:43:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-25 14:46:47 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-25 16:38:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-25 16:44:29 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-04-25 16:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-04-25 16:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-04-25 16:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-04-25 16:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-04-25 16:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-04-25 16:46:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 75
