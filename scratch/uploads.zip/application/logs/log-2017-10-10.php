<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-10 13:44:19 --> Severity: Error --> Class 'Mx_Controller' not found C:\xampp\htdocs\smis\application\modules\dashboard\controllers\user_log.php 4
ERROR - 2017-10-10 13:49:55 --> Severity: Notice --> Undefined variable: results1 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 113
ERROR - 2017-10-10 13:49:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 113
ERROR - 2017-10-10 13:49:55 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 155
ERROR - 2017-10-10 13:49:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 155
ERROR - 2017-10-10 13:58:57 --> Severity: Notice --> Undefined variable: results1 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 84
ERROR - 2017-10-10 13:58:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 84
ERROR - 2017-10-10 13:58:57 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 122
ERROR - 2017-10-10 13:58:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 122
ERROR - 2017-10-10 13:59:49 --> Severity: Notice --> Undefined variable: results1 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 84
ERROR - 2017-10-10 13:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 84
ERROR - 2017-10-10 13:59:49 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 122
ERROR - 2017-10-10 13:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 122
ERROR - 2017-10-10 14:04:59 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:07:20 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:07:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:07:34 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:07:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:09:25 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:09:38 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:10:14 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:10:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:10:45 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:10:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:11:27 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:11:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:43:40 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:43:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:44:00 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:44:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:44:03 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:44:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:44:43 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:44:59 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:44:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:45:02 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:45:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:45:07 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:49:18 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:50:24 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:50:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:50:51 --> The upload path does not appear to be valid.
ERROR - 2017-10-10 14:50:52 --> Query error: Table 'smis.student_profile' doesn't exist - Invalid query: SELECT `b`.*, concat(e.first_name, " ", `e`.`middle_name`, " ", e.last_name) as emp_fullname, concat(sp.st_fname, " ", `sp`.`st_mname`, " ", sp.st_lname) as st_fullname
FROM `bug` `b`
LEFT JOIN `employee` `e` ON `e`.`employee_id` = `b`.`report_id`
LEFT JOIN `student_profile` `sp` ON `sp`.`st_id` = `b`.`report_id`
ORDER BY `id` DESC
ERROR - 2017-10-10 14:51:05 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:51:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:52:24 --> The upload path does not appear to be valid.
ERROR - 2017-10-10 14:52:25 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:53:02 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:53:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:53:05 --> The upload path does not appear to be valid.
ERROR - 2017-10-10 14:53:05 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
ERROR - 2017-10-10 14:53:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 101
