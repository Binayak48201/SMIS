<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-27 10:59:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-02-27 10:59:31 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 89
ERROR - 2018-02-27 10:59:38 --> 404 Page Not Found: /index
ERROR - 2018-02-27 10:59:38 --> 404 Page Not Found: /index
ERROR - 2018-02-27 10:59:38 --> 404 Page Not Found: /index
ERROR - 2018-02-27 10:59:38 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:01:59 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:01:59 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:01:59 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:01:59 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:02:27 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 89
ERROR - 2018-02-27 11:02:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 89
ERROR - 2018-02-27 11:17:56 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:17:56 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:17:56 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:17:56 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:25 --> Query error: Table 'smis.student_profile' doesn't exist - Invalid query: UPDATE `student_profile` SET `joined_batch` = '2072', `last_grade_id` = 'One', `class_id` = '8'
WHERE `student_id` = '1198'
ERROR - 2018-02-27 11:28:41 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 89
ERROR - 2018-02-27 11:28:51 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:51 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:51 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:51 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:51 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:51 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:51 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:51 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:52 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:52 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:28:52 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:07 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 89
ERROR - 2018-02-27 11:31:15 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:15 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:15 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:15 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:15 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:15 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:15 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:15 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:16 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:16 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:16 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:31:56 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:33:03 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-02-27 11:33:13 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:39:08 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-02-27 11:49:05 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-02-27 11:49:16 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-02-27 11:49:20 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:49:20 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:49:20 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:49:20 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:49:20 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:49:21 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:49:21 --> 404 Page Not Found: /index
ERROR - 2018-02-27 11:52:06 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-02-27 11:52:54 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_photo.php 51
ERROR - 2018-02-27 12:01:53 --> 404 Page Not Found: /index
ERROR - 2018-02-27 12:01:53 --> 404 Page Not Found: /index
ERROR - 2018-02-27 12:01:53 --> 404 Page Not Found: /index
ERROR - 2018-02-27 12:01:53 --> 404 Page Not Found: /index
ERROR - 2018-02-27 12:01:53 --> 404 Page Not Found: /index
ERROR - 2018-02-27 12:01:53 --> 404 Page Not Found: /index
ERROR - 2018-02-27 12:01:53 --> 404 Page Not Found: /index
