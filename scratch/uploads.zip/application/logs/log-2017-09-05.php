<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-05 15:52:33 --> Module controller failed to run: dashboard/user_log/log
ERROR - 2017-09-05 15:52:36 --> Module controller failed to run: dashboard/user_log/log
