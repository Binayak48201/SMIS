<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-10 10:12:46 --> 404 Page Not Found: ../modules/pages/controllers/classes/Lession_plan/add_activities
ERROR - 2017-12-10 10:12:56 --> Severity: Notice --> Undefined property: CI::$programlevel_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-12-10 10:12:56 --> Severity: Error --> Call to a member function get_programlevel() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 632
ERROR - 2017-12-10 10:13:00 --> 404 Page Not Found: ../modules/pages/controllers/classes/Lession_plan/add_activities
ERROR - 2017-12-10 10:13:13 --> Severity: Notice --> Undefined property: CI::$programlevel_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-12-10 10:13:13 --> Severity: Error --> Call to a member function get_programlevel() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 632
ERROR - 2017-12-10 10:18:15 --> Severity: Notice --> Undefined variable: programlevels C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_activity.php 64
ERROR - 2017-12-10 10:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_activity.php 64
ERROR - 2017-12-10 11:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 7
ERROR - 2017-12-10 11:06:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 7
ERROR - 2017-12-10 11:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 7
ERROR - 2017-12-10 11:06:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 7
ERROR - 2017-12-10 11:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 7
ERROR - 2017-12-10 11:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 7
ERROR - 2017-12-10 11:09:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 7
ERROR - 2017-12-10 11:09:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 7
ERROR - 2017-12-10 11:10:17 --> Severity: Notice --> Undefined property: stdClass::$mail_topic C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 9
ERROR - 2017-12-10 11:10:17 --> Severity: Notice --> Undefined property: stdClass::$mail_topic C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_lessons.php 9
ERROR - 2017-12-10 11:31:23 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-10 11:32:02 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-10 11:32:52 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-10 11:32:53 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-10 11:33:21 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-10 11:34:04 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-10 11:34:12 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
