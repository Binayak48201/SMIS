<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-02 09:44:44 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-02 10:52:39 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 399
ERROR - 2018-04-02 12:21:13 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 145
ERROR - 2018-04-02 12:21:15 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 145
ERROR - 2018-04-02 12:21:16 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 145
ERROR - 2018-04-02 12:21:19 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 145
ERROR - 2018-04-02 12:21:20 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 145
ERROR - 2018-04-02 12:21:22 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 145
ERROR - 2018-04-02 12:21:24 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 145
ERROR - 2018-04-02 12:21:45 --> Severity: Notice --> Use of undefined constant id - assumed 'id' C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Appraisal_manager.php 145
ERROR - 2018-04-02 12:30:57 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 399
ERROR - 2018-04-02 12:31:03 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 399
ERROR - 2018-04-02 12:34:21 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-02 12:35:05 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 399
ERROR - 2018-04-02 12:35:15 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 399
ERROR - 2018-04-02 12:35:33 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-02 12:39:55 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-02 12:39:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-02 12:41:29 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-02 12:41:36 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-02 12:44:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-02 13:14:20 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncptopic`, CONSTRAINT `FK_ncptopic` FOREIGN KEY (`courseId`) REFERENCES `subject` (`subject_id`)) - Invalid query: DELETE FROM `subject`
WHERE `subject_id` = '56'
ERROR - 2018-04-02 13:21:07 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncptopic`, CONSTRAINT `FK_ncptopic` FOREIGN KEY (`courseId`) REFERENCES `subject` (`subject_id`)) - Invalid query: DELETE FROM `subject`
WHERE `subject_id` = '1'
ERROR - 2018-04-02 13:23:16 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncptopic`, CONSTRAINT `FK_ncptopic` FOREIGN KEY (`courseId`) REFERENCES `subject` (`subject_id`)) - Invalid query: DELETE FROM `subject`
WHERE `subject_id` = '93'
ERROR - 2018-04-02 13:26:20 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-02 13:26:25 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:27:36 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-02 13:31:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:31:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:32:30 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:32:30 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:34:04 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:34:04 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:35:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:36:07 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:22 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 13:37:27 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:09:20 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-02 14:16:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:16:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:46:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:47:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:48:14 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:11 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:12 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:12 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:12 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:12 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:12 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:12 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:57:32 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:58:43 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 14:59:39 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:20 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:36 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:52 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:00:53 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:06:28 --> 404 Page Not Found: /index
ERROR - 2018-04-02 15:11:39 --> Severity: Notice --> Undefined variable: main_content C:\xampp\htdocs\smis\application\modules\pages\views\template.php 4
ERROR - 2018-04-02 15:11:39 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 347
ERROR - 2018-04-02 15:22:02 --> Severity: Notice --> Undefined property: CI::$general_reports_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-04-02 15:22:02 --> Severity: Error --> Call to a member function current_student_overall() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\home.php 87
ERROR - 2018-04-02 15:31:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Program_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-04-02 15:31:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Student_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-04-02 15:32:29 --> Severity: Notice --> Undefined variable: piesProgram C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 55
ERROR - 2018-04-02 15:32:29 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 56
ERROR - 2018-04-02 15:33:05 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 56
ERROR - 2018-04-02 15:35:04 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 56
ERROR - 2018-04-02 15:51:15 --> Query error: Unknown column 'sc.grade_id' in 'on clause' - Invalid query: SELECT `sc`.*, count(case when s.passed_out != "1"  then s.passed_out end) studying, count(case when s.passed_out = "1"  then s.passed_out end) passed, count(s.student_id) as total
FROM `student` `s`
LEFT JOIN `section` `sc` ON `sc`.`section_id` = `s`.`class_id`
LEFT JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
LEFT JOIN `district` `d` ON `d`.`district_id` = `s`.`district_id`
LEFT JOIN `grade` `g` ON `g`.`grade_id` = `sc`.`grade_id`
WHERE `joined_batch` = 2073
GROUP BY `sc`.`grade`
ORDER BY `sc`.`grade_order` ASC
ERROR - 2018-04-02 15:51:29 --> Query error: Unknown column 'sc.grade_id' in 'on clause' - Invalid query: SELECT `sc`.*, count(case when s.passed_out != "1"  then s.passed_out end) studying, count(case when s.passed_out = "1"  then s.passed_out end) passed, count(s.student_id) as total
FROM `student` `s`
LEFT JOIN `section` `sc` ON `sc`.`section_id` = `s`.`class_id`
LEFT JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
LEFT JOIN `district` `d` ON `d`.`district_id` = `s`.`district_id`
LEFT JOIN `grade` `g` ON `g`.`grade_id` = `sc`.`grade_id`
WHERE `joined_batch` = 2073
GROUP BY `sc`.`grade`
ORDER BY `g`.`grade_order` ASC
ERROR - 2018-04-02 15:52:13 --> Query error: Unknown column 'sc.grade_id' in 'on clause' - Invalid query: SELECT `sc`.*, count(case when s.passed_out != "1"  then s.passed_out end) studying, count(case when s.passed_out = "1"  then s.passed_out end) passed, count(s.student_id) as total
FROM `student` `s`
LEFT JOIN `section` `sc` ON `sc`.`section_id` = `s`.`class_id`
LEFT JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
LEFT JOIN `district` `d` ON `d`.`district_id` = `s`.`district_id`
LEFT JOIN `grade` `g` ON `g`.`grade_id` = `sc`.`grade_id`
WHERE `joined_batch` = 2073
GROUP BY `sc`.`grade`
ORDER BY `g`.`grade_order` ASC
ERROR - 2018-04-02 15:52:29 --> Query error: Unknown column 'g.grade' in 'on clause' - Invalid query: SELECT `sc`.*, count(case when s.passed_out != "1"  then s.passed_out end) studying, count(case when s.passed_out = "1"  then s.passed_out end) passed, count(s.student_id) as total
FROM `student` `s`
LEFT JOIN `section` `sc` ON `sc`.`section_id` = `s`.`class_id`
LEFT JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
LEFT JOIN `district` `d` ON `d`.`district_id` = `s`.`district_id`
LEFT JOIN `grade` `g` ON `g`.`grade` = `sc`.`grade`
WHERE `joined_batch` = 2073
GROUP BY `sc`.`grade`
ORDER BY `g`.`grade_order` ASC
ERROR - 2018-04-02 15:55:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\dashboard\controllers\board.php 20
ERROR - 2018-04-02 15:59:21 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-02 15:59:29 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-02 15:59:33 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-02 16:03:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-02 16:05:12 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-02 16:08:42 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
ERROR - 2018-04-02 16:15:05 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-02 16:15:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-02 16:16:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-02 16:20:37 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-02 16:23:58 --> Severity: Notice --> Undefined property: stdClass::$guardian_relation C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 487
ERROR - 2018-04-02 16:24:14 --> Severity: Notice --> Undefined property: stdClass::$guardian_relation C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 487
ERROR - 2018-04-02 16:24:25 --> Severity: Notice --> Undefined property: stdClass::$guardian_relation C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 487
ERROR - 2018-04-02 16:31:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-02 16:31:36 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-02 16:31:59 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:31:59 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:31:59 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:31:59 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:00 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:02 --> 404 Page Not Found: /index
ERROR - 2018-04-02 16:32:35 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-02 16:34:17 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-02 16:34:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-02 16:38:14 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-02 16:41:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
