<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-07 15:36:09 --> Severity: error --> Exception: Unable to locate the model you have specified: House_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 80
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 82
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 82
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 83
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 80
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 82
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 82
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 83
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 80
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 82
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 82
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 83
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 80
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 82
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 82
ERROR - 2017-11-07 15:37:28 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\house_manager.php 83
