<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-12 11:07:22 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:12:36 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:12:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:12:56 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:12:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:13:15 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:13:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:13:51 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:13:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:14:01 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:14:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:22:51 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:22:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:22:54 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:22:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-12 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$d_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 104
ERROR - 2017-10-12 11:30:17 --> Severity: Notice --> Undefined property: stdClass::$d_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 104
ERROR - 2017-10-12 11:54:46 --> Severity: Error --> Class 'Mx_Controller' not found C:\xampp\htdocs\smis\application\modules\dashboard\controllers\user_log.php 4
ERROR - 2017-10-12 11:54:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 53
ERROR - 2017-10-12 11:55:38 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:55:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:55:38 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:55:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:55:38 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 11:55:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 11:56:08 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:56:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:56:08 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:56:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:56:08 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 11:56:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 11:56:22 --> Severity: Notice --> Undefined property: stdClass::$empliyee_id C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:56:22 --> Severity: Notice --> Undefined property: stdClass::$occupation_name C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:56:22 --> Severity: Notice --> Undefined property: stdClass::$empliyee_id C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 11:56:31 --> Severity: Notice --> Undefined property: stdClass::$empliyee_id C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 62
ERROR - 2017-10-12 11:56:31 --> Severity: Notice --> Undefined property: stdClass::$empliyee_id C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:01:40 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 158
ERROR - 2017-10-12 12:01:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 158
ERROR - 2017-10-12 12:02:30 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 183
ERROR - 2017-10-12 12:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 183
ERROR - 2017-10-12 12:03:45 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 167
ERROR - 2017-10-12 12:03:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 167
ERROR - 2017-10-12 12:04:02 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:04:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:10:07 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:10:07 --> Severity: Notice --> Undefined property: stdClass::$biodata C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:10:07 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:10:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:11:06 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:11:06 --> Severity: Notice --> Undefined property: stdClass::$biodata C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:11:06 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:12:10 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:12:10 --> Severity: Notice --> Undefined property: stdClass::$biodata C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:12:10 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:12:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:12:36 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:12:36 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:12:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:12:43 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:12:43 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:13:46 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:13:46 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:13:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:14:12 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:14:12 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:16:07 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:16:07 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:16:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined property: stdClass::$join_date C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 63
ERROR - 2017-10-12 12:17:00 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:18:28 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:18:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:24:03 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:24:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:31:43 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:31:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:32:46 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:32:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:33:04 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:33:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:33:26 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:33:36 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:33:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:33:47 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:33:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:34:17 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 12:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 13:28:41 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 13:28:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 166
ERROR - 2017-10-12 13:29:37 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:29:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:29:52 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:29:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:34:14 --> Query error: Table 'smis.student_profile' doesn't exist - Invalid query: SELECT `b`.*, concat(e.first_name, " ", `e`.`middle_name`, " ", e.last_name) as emp_fullname, concat(sp.st_fname, " ", `sp`.`st_mname`, " ", sp.st_lname) as st_fullname
FROM `bug` `b`
LEFT JOIN `employee` `e` ON `e`.`employee_id` = `b`.`report_id`
LEFT JOIN `student_profile` `sp` ON `sp`.`st_id` = `b`.`report_id`
ORDER BY `id` DESC
ERROR - 2017-10-12 13:41:48 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:41:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:42:46 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:43:11 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:43:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 13:51:57 --> Severity: Warning --> unlink(employee_photo/0ee8482869b4cd4068590f3196eb7683.sql): No such file or directory C:\xampp\htdocs\smis\application\modules\pages\controllers\control\Employee_control.php 46
ERROR - 2017-10-12 13:52:22 --> Severity: Warning --> unlink(employee_photo/0ee8482869b4cd4068590f3196eb7683.sql): No such file or directory C:\xampp\htdocs\smis\application\modules\pages\controllers\control\Employee_control.php 46
ERROR - 2017-10-12 14:00:58 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:00:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:01:04 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:01:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:01:07 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:01:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:01:55 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:01:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:02:32 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:02:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:03:03 --> Severity: Notice --> Undefined variable: Value C:\xampp\htdocs\smis\application\modules\pages\models\profile\employee_model.php 72
ERROR - 2017-10-12 14:03:03 --> Query error: Unknown column 'emp_id' in 'where clause' - Invalid query: UPDATE `employee` SET `first_name` = 'aaad', `middle_name` = 'lalq', `last_name` = 'maharjan', `phone_no` = '2318545', `email` = 'fsd@adsf.adsf', `address` = 'test', `birth_date` = '', `qualification` = '', `agreement_type` = 'Full Time', `dept` = '', `basic_salary` = '0.00', `joined_date` = '', `employee_type` = '', `additionals` = '0.00', `status` = '', `designation` = '', `code` = '', `user_id` = '', `biodata_path` = '', `picture_path` = 'employee_photo/b378ab6f6083667929502cea5672d86b.jpg'
WHERE `emp_id` IS NULL
ERROR - 2017-10-12 14:03:37 --> Query error: Unknown column 'emp_id' in 'where clause' - Invalid query: UPDATE `employee` SET `first_name` = 'aaad', `middle_name` = 'lalq', `last_name` = 'maharjan', `phone_no` = '2318545', `email` = 'fsd@adsf.adsf', `address` = 'test', `birth_date` = '', `qualification` = '', `agreement_type` = 'Full Time', `dept` = '', `basic_salary` = '0.00', `joined_date` = '', `employee_type` = '', `additionals` = '0.00', `status` = '', `designation` = '', `code` = '', `user_id` = '', `biodata_path` = '', `picture_path` = 'employee_photo/b378ab6f6083667929502cea5672d86b.jpg'
WHERE `emp_id` = '62'
ERROR - 2017-10-12 14:04:01 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:04:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:04:44 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:04:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:05:00 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:05:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:05:14 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:05:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:05:37 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:05:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:06:19 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:06:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 159
ERROR - 2017-10-12 14:10:25 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 61
ERROR - 2017-10-12 14:11:03 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 176
ERROR - 2017-10-12 14:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 176
ERROR - 2017-10-12 14:12:43 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:12:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:13:07 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:13:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:13:24 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:13:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:13:43 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:13:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:14:12 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:15:00 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 170
ERROR - 2017-10-12 14:16:33 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:16:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:16:47 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:16:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:17:03 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:17:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:17:12 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:17:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:17:28 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:17:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 179
ERROR - 2017-10-12 14:17:44 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 181
ERROR - 2017-10-12 14:17:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 181
ERROR - 2017-10-12 14:18:05 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:17 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:25 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:32 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:45 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:18:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 182
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 84
ERROR - 2017-10-12 14:19:23 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 185
ERROR - 2017-10-12 14:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 185
ERROR - 2017-10-12 14:19:34 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 185
ERROR - 2017-10-12 14:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 185
ERROR - 2017-10-12 14:20:17 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 191
ERROR - 2017-10-12 14:20:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 191
ERROR - 2017-10-12 14:21:15 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 191
ERROR - 2017-10-12 14:21:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 191
ERROR - 2017-10-12 14:22:19 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:22:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:22:29 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:22:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:22:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:23:28 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:23:40 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:23:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:23:58 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:23:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 194
ERROR - 2017-10-12 14:24:46 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 195
ERROR - 2017-10-12 14:24:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 195
ERROR - 2017-10-12 14:25:02 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 195
ERROR - 2017-10-12 14:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 195
ERROR - 2017-10-12 14:27:02 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:27:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:27:35 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:27:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:27:40 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:27:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:28:01 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:28:18 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:28:36 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:28:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:33:05 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:33:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:33:09 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:33:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:36:08 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:36:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:38:07 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:38:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:39:29 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:40:01 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:40:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:40:30 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:43:19 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:43:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:46:06 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:46:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:46:43 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:46:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:46:55 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:47:15 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:47:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:48:19 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 14:48:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-10-12 15:55:16 --> Severity: Error --> Class 'Mx_Controller' not found C:\xampp\htdocs\smis\application\modules\dashboard\controllers\user_log.php 4
