<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-26 13:27:12 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-02-26 13:27:21 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 89
ERROR - 2018-02-26 13:30:54 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 89
ERROR - 2018-02-26 13:31:00 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:00 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:00 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:00 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:38 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:38 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:38 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:38 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:38 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:38 --> 404 Page Not Found: /index
ERROR - 2018-02-26 13:31:38 --> 404 Page Not Found: /index
