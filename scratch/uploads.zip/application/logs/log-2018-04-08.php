<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-08 09:24:24 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-08 09:24:24 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-08 09:24:30 --> 404 Page Not Found: /index
ERROR - 2018-04-08 09:24:37 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-04-08 09:26:29 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-08 09:26:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-08 09:28:08 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 71
ERROR - 2018-04-08 09:28:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 71
ERROR - 2018-04-08 09:28:22 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-08 09:28:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 62
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 71
ERROR - 2018-04-08 09:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 71
ERROR - 2018-04-08 09:36:31 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 71
ERROR - 2018-04-08 09:36:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 71
ERROR - 2018-04-08 09:38:13 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 75
ERROR - 2018-04-08 09:38:13 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 75
ERROR - 2018-04-08 09:40:06 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 77
ERROR - 2018-04-08 09:40:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 77
ERROR - 2018-04-08 09:40:37 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 75
ERROR - 2018-04-08 09:40:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 75
ERROR - 2018-04-08 09:41:05 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 75
ERROR - 2018-04-08 09:41:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\attendance_overall.php 75
ERROR - 2018-04-08 11:29:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-08 14:55:14 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-08 14:56:48 --> 404 Page Not Found: /index
ERROR - 2018-04-08 14:56:56 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-08 14:57:35 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-08 14:58:12 --> 404 Page Not Found: /index
ERROR - 2018-04-08 14:58:22 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-04-08 14:58:39 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-08 14:58:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-08 15:02:13 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-04-08 15:02:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 90
