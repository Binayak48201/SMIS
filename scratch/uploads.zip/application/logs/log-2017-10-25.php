<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-25 09:23:01 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-10-25 09:24:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Batch_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2017-10-25 09:32:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Section_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2017-10-25 09:33:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\classes\section.php 73
ERROR - 2017-10-25 09:36:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\classes\section.php 85
ERROR - 2017-10-25 09:40:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\classes\section.php 103
ERROR - 2017-10-25 09:41:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\classes\section.php 111
ERROR - 2017-10-25 09:44:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Section_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2017-10-25 09:45:06 --> 404 Page Not Found: ../modules/pages/controllers/classes/Section/index
ERROR - 2017-10-25 09:45:09 --> 404 Page Not Found: ../modules/pages/controllers/classes/Section/index
ERROR - 2017-10-25 09:52:42 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\section.php 120
ERROR - 2017-10-25 09:52:42 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\section.php 122
ERROR - 2017-10-25 09:52:42 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\section.php 122
ERROR - 2017-10-25 09:52:42 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\section.php 123
ERROR - 2017-10-25 10:04:49 --> Query error: Duplicate entry '2071-One-section A' for key 'uniqueSection' - Invalid query: UPDATE `section` SET `batch` = '2071', `grade` = 'One', `section_name` = 'section A'
WHERE `section_id` = '7'
ERROR - 2017-10-25 10:05:10 --> Query error: Duplicate entry '2071-One-section a' for key 'uniqueSection' - Invalid query: UPDATE `section` SET `batch` = '2071', `grade` = 'One', `section_name` = 'section a'
WHERE `section_id` = '7'
ERROR - 2017-10-25 10:05:18 --> Severity: Notice --> Undefined property: CI::$batch_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-10-25 10:05:18 --> Severity: Error --> Call to a member function delete() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Section.php 98
ERROR - 2017-10-25 10:05:37 --> Severity: Error --> Call to undefined method Section_model::delete() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Section.php 98
ERROR - 2017-10-25 10:16:49 --> 404 Page Not Found: ../modules/pages/controllers/classes/Subject_manager/index
ERROR - 2017-10-25 10:17:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Section_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2017-10-25 11:15:52 --> 404 Page Not Found: ../modules/pages/controllers/general_content//index
