<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-28 09:58:11 --> 404 Page Not Found: /index
ERROR - 2017-11-28 10:11:30 --> Severity: Error --> Call to undefined method Marks_entry_model::get_assessments() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 95
ERROR - 2017-11-28 10:12:54 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 23
ERROR - 2017-11-28 10:12:54 --> Severity: Notice --> Undefined variable: subject_id C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 24
ERROR - 2017-11-28 10:13:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 23
ERROR - 2017-11-28 10:13:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 24
ERROR - 2017-11-28 10:15:53 --> Severity: Error --> Call to undefined method Marks_entry_model::get_exmas() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 92
ERROR - 2017-11-28 10:23:50 --> Severity: Notice --> Undefined variable: q1 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 191
ERROR - 2017-11-28 10:23:50 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 10:23:50 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 10:23:50 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 10:23:56 --> Severity: Notice --> Undefined variable: q1 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 191
ERROR - 2017-11-28 10:23:56 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 10:23:56 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 10:23:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 10:24:21 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 68
ERROR - 2017-11-28 10:24:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 68
ERROR - 2017-11-28 10:24:21 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 85
ERROR - 2017-11-28 10:24:21 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 95
ERROR - 2017-11-28 10:24:21 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 96
ERROR - 2017-11-28 10:24:21 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 97
ERROR - 2017-11-28 10:24:21 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 110
ERROR - 2017-11-28 10:24:21 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 110
ERROR - 2017-11-28 10:24:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 10:24:22 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 10:24:22 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 163
ERROR - 2017-11-28 10:24:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 163
ERROR - 2017-11-28 10:24:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-28 10:24:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 169
ERROR - 2017-11-28 10:24:22 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 10:24:22 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 10:24:22 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 71
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 81
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 82
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 83
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 96
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 96
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 149
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 149
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 150
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 155
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 10:24:31 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 10:24:31 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 65
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 75
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 76
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 77
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 90
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 90
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 140
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 141
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 143
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 143
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 144
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 149
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2017-11-28 10:25:50 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 191
ERROR - 2017-11-28 10:25:50 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 191
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 65
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 75
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 76
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 77
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 90
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 90
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 140
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 141
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 143
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 143
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 144
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 149
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2017-11-28 10:27:00 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 191
ERROR - 2017-11-28 10:27:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 191
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 71
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 81
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 82
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 83
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 96
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 96
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 149
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 149
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 150
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 155
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 10:28:41 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 10:28:41 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 10:32:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 20
ERROR - 2017-11-28 10:32:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 21
ERROR - 2017-11-28 10:32:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 35
ERROR - 2017-11-28 10:32:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 36
ERROR - 2017-11-28 10:32:21 --> Severity: Notice --> Undefined variable: q1 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 10:32:21 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 10:32:21 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 10:32:21 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 71
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 81
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 83
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 96
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 96
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 149
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 149
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 150
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 155
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 10:34:27 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 10:34:27 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 71
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 73
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 71
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 73
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 99
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 111
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 124
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 124
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 209
ERROR - 2017-11-28 10:41:02 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-28 10:41:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-28 10:41:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 99
ERROR - 2017-11-28 10:41:44 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 10:41:44 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 111
ERROR - 2017-11-28 10:41:44 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 124
ERROR - 2017-11-28 10:41:44 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 124
ERROR - 2017-11-28 10:41:44 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2017-11-28 10:41:44 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2017-11-28 10:41:45 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 10:41:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 10:41:45 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 10:41:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 10:41:45 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 209
ERROR - 2017-11-28 10:41:45 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-28 10:41:45 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 225
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 100
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 110
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 112
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 125
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 125
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 176
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 179
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 10:43:35 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 10:43:35 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 100
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 110
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 112
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 125
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 125
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 176
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 179
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 10:44:03 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 10:44:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 100
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 110
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 112
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 125
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 125
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 175
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 176
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 179
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 10:44:06 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 10:44:06 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 104
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 114
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 129
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 129
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 179
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 180
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 182
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 10:44:24 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 10:44:24 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 108
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 118
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 120
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 186
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 186
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 10:45:29 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 10:45:29 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 119
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 121
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 134
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 134
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 185
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 193
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 219
ERROR - 2017-11-28 10:46:04 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-28 10:46:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 119
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 121
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 134
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 134
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 185
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 188
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 193
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 219
ERROR - 2017-11-28 10:46:18 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-28 10:46:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 108
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 118
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 120
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 186
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 186
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 10:46:37 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 10:46:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 108
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 118
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 120
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 186
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 186
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 15:15:23 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 15:15:23 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 15:18:25 --> Query error: Table 'smis.student_profile' doesn't exist - Invalid query: SELECT *
FROM `student_profile`
WHERE `section_id` = '1'
ERROR - 2017-11-28 15:19:11 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 108
ERROR - 2017-11-28 15:19:11 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 118
ERROR - 2017-11-28 15:19:11 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 120
ERROR - 2017-11-28 15:19:11 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 15:19:11 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 15:19:11 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 15:19:11 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 184
ERROR - 2017-11-28 15:19:11 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 186
ERROR - 2017-11-28 15:19:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 186
ERROR - 2017-11-28 15:19:12 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 187
ERROR - 2017-11-28 15:19:12 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 192
ERROR - 2017-11-28 15:19:12 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 15:19:12 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 15:19:12 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 122
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 132
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 134
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 201
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 206
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:21:00 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-28 15:21:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 122
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 132
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 134
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 201
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 206
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:21:11 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-28 15:21:11 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 248
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 109
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 123
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 135
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 201
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 201
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 202
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 233
ERROR - 2017-11-28 15:21:40 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-28 15:21:40 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 123
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 135
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 201
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 201
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 202
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 233
ERROR - 2017-11-28 15:21:58 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-28 15:21:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 249
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 132
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 142
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 144
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 157
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 157
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-28 15:26:10 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:26:10 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 132
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 142
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 144
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 157
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 157
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-28 15:26:39 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:26:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 132
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 142
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 144
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 157
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 157
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-28 15:27:26 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:27:26 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 132
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 142
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 144
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 157
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 157
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 208
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-28 15:27:35 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:27:35 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 133
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 143
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 209
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 211
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 217
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 243
ERROR - 2017-11-28 15:28:58 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 259
ERROR - 2017-11-28 15:28:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 259
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 134
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 144
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 159
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 159
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 210
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 213
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 244
ERROR - 2017-11-28 15:29:18 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-28 15:29:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 260
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:29:49 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:29:49 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:31:33 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:31:33 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:32:44 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:32:44 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:33:07 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:33:07 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:33:36 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:33:36 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:34:45 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:34:45 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:36:05 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:36:05 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:38:48 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:38:48 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:39:19 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:39:19 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 136
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 146
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 161
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 212
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 214
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 215
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 246
ERROR - 2017-11-28 15:40:26 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:40:26 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 135
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 135
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 144
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 154
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 156
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 169
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 169
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 223
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 254
ERROR - 2017-11-28 15:42:29 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 270
ERROR - 2017-11-28 15:42:29 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 270
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:43:26 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:43:26 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:43:54 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:43:54 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:45:46 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:45:46 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:46:55 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:46:55 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:46:58 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:46:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:47:34 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:47:34 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:47:47 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:47:47 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 148
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 173
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 227
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 258
ERROR - 2017-11-28 15:48:08 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:48:08 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 274
ERROR - 2017-11-28 15:58:15 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 67
ERROR - 2017-11-28 15:58:15 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark//5
ERROR - 2017-11-28 15:58:15 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 67
ERROR - 2017-11-28 15:58:15 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark//7
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 152
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 162
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:58:15 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 278
ERROR - 2017-11-28 15:58:15 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 278
ERROR - 2017-11-28 15:59:37 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 15:59:37 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/7
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 152
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 162
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 15:59:37 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 278
ERROR - 2017-11-28 15:59:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 278
ERROR - 2017-11-28 15:59:56 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:00:09 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:00:16 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:00:18 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:00:24 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:01:17 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:02:09 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:02:11 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:02:11 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:02:27 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/5
ERROR - 2017-11-28 16:02:27 --> Module controller failed to run: pages/exam/marks_entry/students_with_mark/1/56/7
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 153
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 163
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 165
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 178
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 229
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 237
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 263
ERROR - 2017-11-28 16:02:27 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 279
ERROR - 2017-11-28 16:02:27 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 279
ERROR - 2017-11-28 16:04:54 --> Severity: Warning --> Missing argument 1 for Marks_entry::students_with_mark() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 152
ERROR - 2017-11-28 16:04:54 --> Severity: Warning --> Missing argument 2 for Marks_entry::students_with_mark() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 152
ERROR - 2017-11-28 16:04:54 --> Severity: Warning --> Missing argument 3 for Marks_entry::students_with_mark() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 152
ERROR - 2017-11-28 16:05:29 --> Severity: Notice --> Undefined variable: info C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 68
ERROR - 2017-11-28 16:05:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 68
ERROR - 2017-11-28 16:05:29 --> Severity: Notice --> Undefined variable: info C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 69
ERROR - 2017-11-28 16:05:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 69
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 152
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 162
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 16:10:45 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 278
ERROR - 2017-11-28 16:10:45 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 278
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 152
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 162
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 164
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 177
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 262
ERROR - 2017-11-28 16:12:52 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 278
ERROR - 2017-11-28 16:12:52 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 278
ERROR - 2017-11-28 16:22:03 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 156
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 155
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 165
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 167
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 180
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 180
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 233
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 233
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 239
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-28 16:23:11 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-28 16:23:11 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 155
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 165
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 167
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 180
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 180
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 233
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 233
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 239
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 265
ERROR - 2017-11-28 16:23:25 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-28 16:23:25 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 281
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined property: stdClass::$current_roll C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 118
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined property: stdClass::$st_fname C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 119
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined property: stdClass::$st_mname C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 119
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined property: stdClass::$st_lname C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 119
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 156
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 166
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 240
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-28 16:23:48 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:23:48 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 156
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 166
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 240
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-28 16:24:27 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:24:27 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 156
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 166
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 231
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 235
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 240
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-28 16:24:49 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:24:49 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 156
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 166
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 240
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-28 16:25:07 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:25:07 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 156
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 166
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 240
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-28 16:25:29 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:25:29 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 156
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 166
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 181
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 195
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 196
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 203
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 216
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 222
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 232
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 240
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 266
ERROR - 2017-11-28 16:25:39 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:25:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 282
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 73
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 170
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 172
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 185
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 185
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 238
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 238
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 244
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 270
ERROR - 2017-11-28 16:28:22 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 286
ERROR - 2017-11-28 16:28:22 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 286
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 73
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 170
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 172
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 185
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 185
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 199
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 200
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 207
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 220
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 226
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 230
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 238
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 238
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 244
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 270
ERROR - 2017-11-28 16:28:38 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 286
ERROR - 2017-11-28 16:28:38 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 286
ERROR - 2017-11-28 16:30:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 116
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 170
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 268
ERROR - 2017-11-28 16:31:02 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 284
ERROR - 2017-11-28 16:31:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 284
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 168
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 170
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 183
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 197
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$pu_regno C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 198
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 205
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 218
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 224
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined property: stdClass::$st_roll_no C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 228
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 234
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: course_info C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 236
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: update C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 242
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: q2 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 268
ERROR - 2017-11-28 16:31:37 --> Severity: Notice --> Undefined variable: q6 C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 284
ERROR - 2017-11-28 16:31:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 284
