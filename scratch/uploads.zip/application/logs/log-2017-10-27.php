<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-27 10:12:19 --> Query error: Table 'smis.courses' doesn't exist - Invalid query: SELECT *
FROM `courses`
ORDER BY `added_batch` DESC, `grade` DESC
ERROR - 2017-10-27 10:12:39 --> Query error: Table 'smis.course' doesn't exist - Invalid query: SELECT *
FROM `course`
ORDER BY `added_batch` DESC, `grade` DESC
ERROR - 2017-10-27 10:14:07 --> Query error: Unknown column 'added_batch' in 'order clause' - Invalid query: SELECT *
FROM `class_days`
ORDER BY `added_batch` DESC, `grade` DESC
ERROR - 2017-10-27 11:14:35 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:14:35 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:14:35 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:14:35 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:15:30 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:15:30 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:15:30 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:15:30 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:17:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:17:33 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:17:33 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:17:33 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:17:59 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:17:59 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:17:59 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:17:59 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:17:59 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 193
ERROR - 2017-10-27 11:17:59 --> Severity: Notice --> Undefined property: stdClass::$emp_fullname C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 194
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$added_batch C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 190
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 191
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$subject_type C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 195
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$added_batch C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$subject_type C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$full_marks C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$pass_marks C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$added_batch C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 190
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 191
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$subject_type C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 195
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$added_batch C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$subject_type C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$full_marks C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$pass_marks C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$added_batch C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 190
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 191
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$subject_type C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 195
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$added_batch C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$subject_type C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$full_marks C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:21:38 --> Severity: Notice --> Undefined property: stdClass::$pass_marks C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:43:47 --> Severity: Notice --> Undefined property: stdClass::$calss_days_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:43:47 --> Severity: Notice --> Undefined property: stdClass::$calss_days_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 198
ERROR - 2017-10-27 11:43:47 --> Severity: Notice --> Undefined property: stdClass::$calss_days_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:43:47 --> Severity: Notice --> Undefined property: stdClass::$calss_days_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 198
ERROR - 2017-10-27 11:43:47 --> Severity: Notice --> Undefined property: stdClass::$calss_days_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:43:47 --> Severity: Notice --> Undefined property: stdClass::$calss_days_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 198
ERROR - 2017-10-27 11:43:47 --> Severity: Notice --> Undefined property: stdClass::$calss_days_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 197
ERROR - 2017-10-27 11:43:47 --> Severity: Notice --> Undefined property: stdClass::$calss_days_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_manager.php 198
ERROR - 2017-10-27 12:35:52 --> Severity: Error --> Call to undefined method Course_manager_model::get_courses_by_id() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 136
ERROR - 2017-10-27 12:35:59 --> Severity: Error --> Call to undefined method Course_manager_model::get_courses_by_id() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 136
ERROR - 2017-10-27 12:36:01 --> Severity: Error --> Call to undefined method Course_manager_model::get_courses_by_id() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 136
ERROR - 2017-10-27 12:36:16 --> Severity: Error --> Call to undefined method Course_manager_model::get_courses_by_id() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 136
ERROR - 2017-10-27 12:48:10 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:10 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:10 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:48:16 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:16 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:16 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:48:23 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:23 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:23 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:48:26 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:26 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:26 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:48:28 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:28 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:28 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:48:36 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:36 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:48:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:48:37 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:49:27 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:49:27 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:49:27 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:50:29 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:50:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:50:29 --> Severity: Notice --> Undefined index: sections C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:50:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:50:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:50:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:50:29 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:50:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:50:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:50:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:50:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:50:55 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` IS NULL
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:51:05 --> Severity: Notice --> Undefined property: stdClass::$batch C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:51:05 --> Severity: Notice --> Undefined property: stdClass::$batch C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:51:05 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:51:12 --> Severity: Notice --> Undefined property: stdClass::$batch C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-10-27 12:51:12 --> Severity: Notice --> Undefined property: stdClass::$batch C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 140
ERROR - 2017-10-27 12:51:12 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` IS NULL
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:51:56 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:52:00 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:52:05 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:53:12 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2065'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:54:22 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:55:05 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:55:08 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:55:08 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:55:09 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 12:55:09 --> Query error: Unknown column 'section_name' in 'order clause' - Invalid query: SELECT *
FROM `subject`
WHERE `added_batch` = '2071'
AND `grade` = 'One'
ORDER BY `section_name` DESC
ERROR - 2017-10-27 13:10:31 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 51
ERROR - 2017-10-27 13:10:31 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 71
ERROR - 2017-10-27 13:10:31 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 164
ERROR - 2017-10-27 13:10:31 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 184
ERROR - 2017-10-27 13:10:52 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 107
ERROR - 2017-10-27 13:10:52 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 127
ERROR - 2017-10-27 13:14:24 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 108
ERROR - 2017-10-27 13:14:24 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 128
ERROR - 2017-10-27 13:14:38 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 109
ERROR - 2017-10-27 13:14:38 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 129
ERROR - 2017-10-27 13:15:06 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 110
ERROR - 2017-10-27 13:15:06 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 130
ERROR - 2017-10-27 13:15:39 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 110
ERROR - 2017-10-27 13:15:39 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 130
ERROR - 2017-10-27 13:21:53 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 158
ERROR - 2017-10-27 13:22:18 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 158
ERROR - 2017-10-27 13:22:38 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 158
ERROR - 2017-10-27 13:23:18 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 161
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:24:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 166
ERROR - 2017-10-27 13:34:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\class_manager.php 178
ERROR - 2017-10-27 13:38:37 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-10-27 13:39:34 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-10-27 13:40:14 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-10-27 13:40:35 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
