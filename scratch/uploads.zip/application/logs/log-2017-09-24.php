<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-24 10:40:45 --> Severity: Error --> Class 'Mx_Controller' not found C:\xampp\htdocs\smis\application\modules\dashboard\controllers\user_log.php 4
ERROR - 2017-09-24 10:42:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Grade_manager_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2017-09-24 10:43:21 --> Query error: Table 'smis.garde' doesn't exist - Invalid query: SELECT *
FROM `garde`
ERROR - 2017-09-24 10:43:47 --> Severity: Notice --> Undefined variable: q C:\xampp\htdocs\smis\application\modules\pages\models\classes\grade_manager_model.php 11
ERROR - 2017-09-24 10:43:47 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\classes\grade_manager_model.php 11
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:08 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 97
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$zone_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$region_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 99
ERROR - 2017-09-24 10:44:09 --> Severity: Notice --> Undefined property: stdClass::$district_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\grade_manager.php 100
ERROR - 2017-09-24 11:05:21 --> Query error: Unknown column 'grade_order' in 'order clause' - Invalid query: SELECT *
FROM `menu`
ORDER BY `grade_order`
ERROR - 2017-09-24 11:49:40 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 37
ERROR - 2017-09-24 12:22:57 --> Severity: 4096 --> Object of class Grade_manager could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Grade_manager.php 61
ERROR - 2017-09-24 12:22:57 --> Severity: 4096 --> Object of class Grade_manager could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Grade_manager.php 89
ERROR - 2017-09-24 12:24:03 --> Severity: 4096 --> Object of class Grade_manager could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Grade_manager.php 61
ERROR - 2017-09-24 12:24:08 --> Severity: 4096 --> Object of class Grade_manager could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Grade_manager.php 61
ERROR - 2017-09-24 12:24:11 --> Severity: 4096 --> Object of class Grade_manager could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Grade_manager.php 61
ERROR - 2017-09-24 12:26:04 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Grade_manager.php 61
ERROR - 2017-09-24 12:26:04 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Grade_manager.php 89
ERROR - 2017-09-24 13:10:11 --> Query error: Duplicate entry '15' for key 'grade_order' - Invalid query: UPDATE `grade` SET `grade_order` = '15'
WHERE `grade_id` = '19'
ERROR - 2017-09-24 13:10:16 --> Query error: Duplicate entry '15' for key 'grade_order' - Invalid query: UPDATE `grade` SET `grade_order` = '15'
WHERE `grade_id` = '19'
ERROR - 2017-09-24 14:31:48 --> Query error: Duplicate entry 'lokeshm' for key 'USER_NAME' - Invalid query: INSERT INTO `users` (`FNAME`, `LNAME`, `USER_NAME`, `USER_PASSWORD`, `ACC_STATUS`, `ROLE_ID`) VALUES ('lokesh', 'maharjan', 'lokeshm', '0c7540eb7e65b553ec1ba6b20de79608', 'ON', '1')
