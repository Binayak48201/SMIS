<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 100
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:49 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:49 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:02:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:12:54 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:12:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:12:54 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:12:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 100
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Undefined variable: teacher C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 141
ERROR - 2018-01-31 10:28:42 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-31 10:28:55 --> 404 Page Not Found: /index
ERROR - 2018-01-31 10:28:55 --> 404 Page Not Found: /index
ERROR - 2018-01-31 10:28:55 --> 404 Page Not Found: /index
ERROR - 2018-01-31 10:28:55 --> 404 Page Not Found: /index
ERROR - 2018-01-31 10:28:55 --> 404 Page Not Found: /index
ERROR - 2018-01-31 10:38:54 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:38:54 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:38:54 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:39:28 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:39:28 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:39:28 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:39:43 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:39:43 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:39:43 --> Severity: Notice --> Undefined variable: st_ids C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 101
ERROR - 2018-01-31 10:45:36 --> Query error: Unknown column 'ca.student_id' in 'on clause' - Invalid query: SELECT `s`.`student_id`
FROM `student` `s`
JOIN `class_days` `cd` ON `cd`.`section_id` = `s`.`class_id`
JOIN `class_attendance` `ca` ON `ca`.`student_id` = `s`.`student_id`
WHERE `cd`.`class_days_id` = '1300'
AND `ca`.`terminal_id` = '12'
ORDER BY `s`.`current_roll`
ERROR - 2018-01-31 10:57:15 --> Query error: Unknown table 'smis.ca' - Invalid query: SELECT `s`.`student_id`, `s`.`st_fname`, `s`.`st_mname`, `s`.`st_lname`, `s`.`current_roll`, `cd`.*, `ca`.*
FROM `student` `s`
JOIN `class_days` `cd` ON `cd`.`section_id` = `s`.`class_id`
WHERE `cd`.`class_days_id` = '1300'
ORDER BY `s`.`current_roll`
ERROR - 2018-01-31 11:32:07 --> Severity: Error --> Call to undefined method Attendance_model::add_attendance() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Attendance.php 114
ERROR - 2018-01-31 11:44:15 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 52
ERROR - 2018-01-31 11:44:15 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 70
ERROR - 2018-01-31 11:44:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 88
ERROR - 2018-01-31 11:46:21 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:46:21 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:46:21 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:46:21 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:46:21 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:49:43 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:49:43 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:49:43 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:49:43 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:51:14 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:51:14 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:51:14 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:51:14 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:51:40 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:51:40 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:51:40 --> 404 Page Not Found: /index
ERROR - 2018-01-31 11:51:40 --> 404 Page Not Found: /index
ERROR - 2018-01-31 12:38:26 --> Severity: Parsing Error --> syntax error, unexpected 'fun' (T_STRING), expecting function (T_FUNCTION) C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 7
