<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-12 09:23:20 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-12 11:54:31 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-12 14:07:05 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-12 14:09:32 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 14:09:49 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 14:11:28 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 14:11:40 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 14:15:00 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 14:16:24 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 14:17:32 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 14:43:48 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 14:44:40 --> Query error: Unknown column 'ca.st_id' in 'where clause' - Invalid query: SELECT `ca`.*
FROM `class_attendance` `ca`
JOIN `class_days` `cd` ON `cd`.`class_days_id` = `ca`.`class_days_id`
JOIN `exam` `e` ON `e`.`exam_id` = `ca`.`terminal_id`
WHERE `e`.`numeric_value` = '1'
AND `cd`.`section_id` = '13'
AND `ca`.`st_id` = '1214'
ERROR - 2018-03-12 14:59:32 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-12 15:01:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-12 15:01:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-12 15:01:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-12 15:01:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-12 15:01:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-12 15:01:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-12 15:01:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-12 15:01:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-12 15:35:38 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 15:39:25 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 15:40:09 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 95
ERROR - 2018-03-12 15:40:45 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 95
ERROR - 2018-03-12 15:42:21 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:42:32 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:42:43 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:43:33 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:47:29 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:48:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:48:35 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:48:56 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:54:23 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:54:59 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:56:34 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:56:53 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:57:05 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:57:20 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 15:57:37 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:09:36 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 16:09:44 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:09:45 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:09:46 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:09:47 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:09:48 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:09:48 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:09:49 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:10:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:10:07 --> 404 Page Not Found: ../modules/pages/controllers/exam/Marks_entry/class_rank
ERROR - 2018-03-12 16:10:10 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-03-12 16:10:12 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 16:10:14 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 95
ERROR - 2018-03-12 16:16:44 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-03-12 16:16:50 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-12 16:17:36 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-12 16:17:45 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-12 16:21:50 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-12 16:29:47 --> Query error: Unknown column 'tr.grade_id' in 'where clause' - Invalid query: SELECT *
FROM `student` `s`
LEFT JOIN `terminal_result` `tr` ON `tr`.`student_id` = `s`.`student_id`
WHERE `tr`.`grade_id` = 'One'
AND `tr`.`terminal_id` = '1'
GROUP BY `tr`.`student_id`, `tr`.`grade`, `tr`.`terminal_id`
ERROR - 2018-03-12 16:29:59 --> Query error: Unknown column 'tr.grade_id' in 'where clause' - Invalid query: SELECT *
FROM `student` `s`
LEFT JOIN `terminal_result` `tr` ON `tr`.`student_id` = `s`.`student_id`
WHERE `tr`.`grade_id` = 'One'
AND `tr`.`terminal_id` = '1'
GROUP BY `tr`.`student_id`, `tr`.`grade`, `tr`.`terminal_id`
ERROR - 2018-03-12 16:30:13 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2018-03-12 16:35:47 --> Severity: Parsing Error --> syntax error, unexpected '"%"' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\smis\application\modules\pages\views\reports\view_class_rank.php 35
