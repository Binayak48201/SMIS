<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-18 11:42:03 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 11:42:07 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 11:42:18 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 11:51:03 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 11:59:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 115
ERROR - 2017-12-18 11:59:32 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:00:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 115
ERROR - 2017-12-18 12:00:04 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:00:29 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:01:46 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:01:50 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:02:37 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:02:42 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:03:32 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:05:17 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 10
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 10
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 49
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 49
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 64
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 64
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 101
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 101
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 103
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 103
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 105
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 105
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 107
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 107
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 109
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 109
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2017-12-18 12:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2017-12-18 12:07:26 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 10
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 10
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 49
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 49
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 64
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 64
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 101
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 101
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 103
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 103
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 105
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 105
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 107
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 107
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\header.php 109
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\header.php 109
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2017-12-18 12:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2017-12-18 12:25:23 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-18 12:26:27 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 1
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 1
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 5
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 5
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 21
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 21
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 29
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 29
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 37
ERROR - 2017-12-18 12:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 37
ERROR - 2017-12-18 12:32:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\classes\manage_routine.php 14
ERROR - 2017-12-18 12:32:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\manage_routine.php 14
ERROR - 2017-12-18 13:32:41 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2017-12-18 13:46:55 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/get_routine
ERROR - 2017-12-18 13:46:57 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/get_routine
ERROR - 2017-12-18 13:54:21 --> Severity: Warning --> Missing argument 1 for Class_manager_model::get_routine(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Class_manager.php on line 94 and defined C:\xampp\htdocs\smis\application\modules\pages\models\classes\class_manager_model.php 14
ERROR - 2017-12-18 13:54:21 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\classes\class_manager_model.php 16
ERROR - 2017-12-18 13:54:58 --> Severity: Notice --> Undefined property: stdClass::$Routine C:\xampp\htdocs\smis\application\modules\pages\views\classes\manage_routine.php 49
ERROR - 2017-12-18 14:01:03 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`class_routine`, CONSTRAINT `FK_class_routine` FOREIGN KEY (`routing_id`) REFERENCES `class` (`class_id`) ON DELETE CASCADE) - Invalid query: INSERT INTO `class_routine` (`routine`, `section_id`) VALUES ('<p>testeradfasdv</p>', '')
ERROR - 2017-12-18 14:07:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`class_routine`, CONSTRAINT `class_routine_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `section` (`section_id`)) - Invalid query: INSERT INTO `class_routine` (`routine`, `section_id`) VALUES ('<p>testeradfasdv</p>', '')
ERROR - 2017-12-18 14:08:29 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`smis`.`class_routine`, CONSTRAINT `class_routine_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `section` (`section_id`)) - Invalid query: INSERT INTO `class_routine` (`routine`, `section_id`) VALUES ('<p>tesdfasdvsdb</p>', '')
