<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-09 10:41:18 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-05-09 10:41:30 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-05-09 10:43:30 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-05-09 10:43:47 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-05-09 10:43:53 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-05-09 10:43:54 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-05-09 10:44:12 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 100
ERROR - 2018-05-09 10:53:21 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 101
ERROR - 2018-05-09 10:54:21 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 101
ERROR - 2018-05-09 10:58:03 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 101
ERROR - 2018-05-09 10:58:11 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 101
ERROR - 2018-05-09 10:58:25 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_overall.php 101
