<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-07 14:34:00 --> 404 Page Not Found: ../modules/pages/controllers/classes/Section_manager/list_student
ERROR - 2018-02-07 14:34:42 --> Severity: Notice --> Undefined property: CI::$course_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-02-07 14:34:42 --> Severity: Error --> Call to a member function get_courses_by_id() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Section_manager.php 143
ERROR - 2018-02-07 14:35:29 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:35:29 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:35:29 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:35:29 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:36:13 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:36:13 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:36:13 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:36:13 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:36:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:37:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:37:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:37:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:37:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 127
ERROR - 2018-02-07 14:39:25 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 136
ERROR - 2018-02-07 14:39:25 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 136
ERROR - 2018-02-07 14:39:25 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 136
ERROR - 2018-02-07 14:39:25 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 136
ERROR - 2018-02-07 14:39:54 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:39:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 136
ERROR - 2018-02-07 14:39:54 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:39:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 136
ERROR - 2018-02-07 14:39:54 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:39:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 136
ERROR - 2018-02-07 14:39:54 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:39:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 136
ERROR - 2018-02-07 14:40:18 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:40:18 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:40:18 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:40:18 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:40:48 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:40:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:40:48 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:40:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:40:48 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:40:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:40:48 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:40:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:41:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:41:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:41:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:41:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:41:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:41:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:41:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:41:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:43:28 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:43:28 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:43:28 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:43:28 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:43:50 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:43:50 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:43:50 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:43:50 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:44:12 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:44:12 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:44:12 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:44:12 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:46:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:46:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:46:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:46:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:46:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:46:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:46:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:46:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:46:43 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:46:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:46:43 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:46:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:46:43 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:46:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:46:43 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:46:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:47:01 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:47:01 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:47:01 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:47:01 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:47:29 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:47:29 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:47:29 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:47:29 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:48:00 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:48:00 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:48:00 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:48:00 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:48:21 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:48:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:48:21 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:48:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:48:21 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:48:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:48:21 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:48:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 130
ERROR - 2018-02-07 14:49:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:49:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 137
ERROR - 2018-02-07 14:49:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:49:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 137
ERROR - 2018-02-07 14:49:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:49:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 137
ERROR - 2018-02-07 14:49:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:49:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 137
ERROR - 2018-02-07 14:50:03 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:03 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:03 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:03 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:50:38 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:50:38 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:50:38 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:50:38 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:51:59 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:51:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:51:59 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:51:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:51:59 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:51:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:51:59 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:51:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:52:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:52:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:52:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:52:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:52:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:52:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:52:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:52:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:52:42 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:52:42 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:52:42 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:52:42 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:52:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:53:03 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:53:03 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:53:03 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:53:03 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 131
ERROR - 2018-02-07 14:53:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:53:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:53:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:53:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:53:32 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:53:32 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:53:32 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:53:32 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 14:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 14:55:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 20
ERROR - 2018-02-07 14:55:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 21
ERROR - 2018-02-07 14:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 49
ERROR - 2018-02-07 14:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 61
ERROR - 2018-02-07 15:01:09 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:09 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:09 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:09 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:13 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:13 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:13 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:13 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:51 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:51 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:51 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:01:51 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:03:54 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:03:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:03:54 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:03:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:03:54 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:03:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:03:54 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-02-07 15:03:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\list_students.php 128
ERROR - 2018-02-07 15:46:49 --> Severity: Warning --> Missing argument 2 for Evaluation::get_evaluation_option() C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 71
ERROR - 2018-02-07 15:46:49 --> Severity: Notice --> Undefined variable: type_id C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 73
ERROR - 2018-02-07 15:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 127
ERROR - 2018-02-07 15:46:49 --> Severity: Warning --> Missing argument 2 for Evaluation::get_evaluation_option() C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 71
ERROR - 2018-02-07 15:46:49 --> Severity: Notice --> Undefined variable: type_id C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 73
ERROR - 2018-02-07 15:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 127
ERROR - 2018-02-07 15:46:49 --> Severity: Warning --> Missing argument 2 for Evaluation::get_evaluation_option() C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 71
ERROR - 2018-02-07 15:46:49 --> Severity: Notice --> Undefined variable: type_id C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 73
ERROR - 2018-02-07 15:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 127
ERROR - 2018-02-07 15:46:49 --> Severity: Warning --> Missing argument 2 for Evaluation::get_evaluation_option() C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 71
ERROR - 2018-02-07 15:46:49 --> Severity: Notice --> Undefined variable: type_id C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 73
ERROR - 2018-02-07 15:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\list_students.php 127
ERROR - 2018-02-07 15:51:03 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:52:10 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:52:44 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:52:54 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:57:02 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:57:07 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:57:42 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:57:56 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:58:15 --> 404 Page Not Found: ../modules/pages/controllers/classes//index
ERROR - 2018-02-07 15:59:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_st_evaluation.php 15
ERROR - 2018-02-07 15:59:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_st_evaluation.php 15
