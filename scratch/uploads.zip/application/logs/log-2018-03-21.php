<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-21 14:34:53 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-21 14:35:42 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-03-21 14:38:13 --> Severity: error --> Exception: Unable to locate the model you have specified: General_reports_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2018-03-21 14:38:45 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-21 14:39:20 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-21 14:40:04 --> Severity: Notice --> Undefined property: CI::$student_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-21 14:40:04 --> Severity: Error --> Call to a member function get_students() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 72
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 14:47:29 --> Severity: Notice --> Undefined property: stdClass::$section_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 150
ERROR - 2018-03-21 15:19:40 --> Severity: Notice --> Undefined variable: district C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 69
ERROR - 2018-03-21 15:19:40 --> Severity: Notice --> Undefined variable: post C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 69
ERROR - 2018-03-21 15:22:35 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-21 15:22:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-21 15:28:46 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-21 15:38:50 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\models\reports\general_reports_model.php 10
ERROR - 2018-03-21 15:43:36 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-21 15:53:53 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-21 15:54:55 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-21 15:54:58 --> Severity: Notice --> Undefined property: CI::$district_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-21 15:54:58 --> Severity: Error --> Call to a member function get_district() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 182
ERROR - 2018-03-21 15:55:40 --> Severity: Notice --> Undefined variable: schools C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 53
ERROR - 2018-03-21 15:55:57 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-21 15:56:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-21 15:56:57 --> Severity: Notice --> Undefined property: CI::$School_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-21 15:56:57 --> Severity: Error --> Call to a member function get_school() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 135
ERROR - 2018-03-21 15:57:22 --> Severity: Notice --> Undefined property: CI::$School_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-21 15:57:22 --> Severity: Error --> Call to a member function get_school() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\General_reports.php 135
ERROR - 2018-03-21 15:58:05 --> Severity: Notice --> Undefined variable: schools C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 53
ERROR - 2018-03-21 15:58:17 --> Severity: Notice --> Undefined variable: schools C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 53
ERROR - 2018-03-21 16:30:44 --> Severity: Notice --> Undefined variable: schools C:\xampp\htdocs\smis\application\modules\pages\views\reports\district_st_list.php 53
ERROR - 2018-03-21 16:30:48 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
