<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-11 13:28:01 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_standards.php 88
ERROR - 2017-12-11 13:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_standards.php 88
ERROR - 2017-12-11 13:28:01 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_standards.php 90
ERROR - 2017-12-11 13:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_standards.php 90
ERROR - 2017-12-11 13:28:01 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_standards.php 90
ERROR - 2017-12-11 13:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_standards.php 90
ERROR - 2017-12-11 13:28:01 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_standards.php 91
ERROR - 2017-12-11 13:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\activity_standards.php 91
ERROR - 2017-12-11 13:46:47 --> 404 Page Not Found: ../modules/pages/controllers/classes/Lession_plan/delete_standard2
ERROR - 2017-12-11 14:17:15 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-11 14:17:15 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-11 14:17:53 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-11 14:17:53 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-11 14:17:57 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-11 14:17:57 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-11 14:17:59 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-11 14:17:59 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-11 14:20:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-11 14:20:26 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-11 14:20:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-11 14:20:28 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-11 14:24:50 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-11 14:24:50 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-11 14:26:06 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-11 14:26:06 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
