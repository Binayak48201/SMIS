<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-15 10:20:25 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-15 10:20:25 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-15 10:21:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Subjecteacher_model C:\xampp\htdocs\smis\system\core\Loader.php 344
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$first_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 52
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$last_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 52
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$first_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$last_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 57
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 61
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 83
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 83
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:28:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$semester_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 57
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 61
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 83
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 83
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:28:53 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 61
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 83
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 83
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:29:13 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 81
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 83
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 83
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 118
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 119
ERROR - 2017-12-15 10:29:56 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 122
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 75
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined variable: lession_plan C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 77
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 77
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 112
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 113
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 116
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 112
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 113
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 116
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 112
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 113
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 116
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 112
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 113
ERROR - 2017-12-15 10:30:17 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 116
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 106
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 106
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 106
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$period C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 106
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$activity_txt C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:30:43 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:34:07 --> Query error: Unknown column 'exma.exam_id' in 'on clause' - Invalid query: SELECT `cd`.*, `exam`.`terminal_name`, `sb`.*, `sc`.`section_name`, `sc`.`grade`, CONCAT(e.first_name, " ", `e`.`middle_name`, " ", e.last_name) as emp_fullname
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
JOIN `employee` `e` ON `e`.`employee_id` = `cd`.`employee_id`
LEFT JOIN `exam` ON `exma`.`exam_id` = `cd`.`target_exam`
WHERE `class_days_id` = '1295'
ERROR - 2017-12-15 10:34:24 --> Query error: Unknown column 'cd.target_exam' in 'on clause' - Invalid query: SELECT `cd`.*, `exam`.`terminal_name`, `sb`.*, `sc`.`section_name`, `sc`.`grade`, CONCAT(e.first_name, " ", `e`.`middle_name`, " ", e.last_name) as emp_fullname
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
JOIN `employee` `e` ON `e`.`employee_id` = `cd`.`employee_id`
LEFT JOIN `exam` ON `exam`.`exam_id` = `cd`.`target_exam`
WHERE `class_days_id` = '1295'
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:34:50 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:36:03 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:36:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:36:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:36:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:36:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$terminal_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 107
ERROR - 2017-12-15 10:37:10 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:37:18 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:37:18 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:37:18 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:37:18 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:37:18 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:38:03 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:38:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:38:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:38:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:38:03 --> Severity: Notice --> Undefined property: stdClass::$activity_link C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 110
ERROR - 2017-12-15 10:39:31 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:40:00 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:41:11 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:41:47 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:41:52 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 128
ERROR - 2017-12-15 10:44:05 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:47:44 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:48:23 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:53:09 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:53:17 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:55:30 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 10:59:46 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 13:50:27 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2017-12-15 13:50:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 139
ERROR - 2017-12-15 13:50:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 140
ERROR - 2017-12-15 13:50:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 140
ERROR - 2017-12-15 13:50:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 148
ERROR - 2017-12-15 13:50:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 152
ERROR - 2017-12-15 13:54:04 --> Severity: Notice --> Undefined variable: class_day C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 920
ERROR - 2017-12-15 13:54:04 --> Severity: Notice --> Undefined variable: class_day C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 921
ERROR - 2017-12-15 13:54:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 55
ERROR - 2017-12-15 13:54:25 --> Severity: Notice --> Undefined variable: class_day C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 920
ERROR - 2017-12-15 13:54:25 --> Severity: Notice --> Undefined variable: class_day C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 921
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined property: stdClass::$updater C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 80
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 85
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 85
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined property: stdClass::$updater C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 80
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 85
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 85
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined property: stdClass::$updater C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 80
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 85
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 85
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined property: stdClass::$updater C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 80
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 85
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 85
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:56:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:56:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:56:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:56:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:56:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:56:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:56:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:56:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\course_pointer.php 91
ERROR - 2017-12-15 13:59:08 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-12-15 13:59:10 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-12-15 14:12:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`district_name`' at line 3 - Invalid query: SELECT *
FROM `district`
ORDER BY `state` `district_name`
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:34:08 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 176
ERROR - 2017-12-15 15:34:52 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 152
ERROR - 2017-12-15 15:34:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 152
ERROR - 2017-12-15 15:34:52 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 155
ERROR - 2017-12-15 15:34:52 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 152
ERROR - 2017-12-15 15:34:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 152
ERROR - 2017-12-15 15:34:52 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 155
ERROR - 2017-12-15 15:34:52 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 152
ERROR - 2017-12-15 15:34:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 152
ERROR - 2017-12-15 15:34:52 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 155
ERROR - 2017-12-15 15:34:52 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 152
ERROR - 2017-12-15 15:34:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 152
ERROR - 2017-12-15 15:34:52 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 155
ERROR - 2017-12-15 15:34:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:35:05 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 176
ERROR - 2017-12-15 15:35:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 171
ERROR - 2017-12-15 15:35:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 171
ERROR - 2017-12-15 15:35:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 174
ERROR - 2017-12-15 15:35:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 171
ERROR - 2017-12-15 15:35:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 171
ERROR - 2017-12-15 15:35:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 174
ERROR - 2017-12-15 15:35:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 171
ERROR - 2017-12-15 15:35:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 171
ERROR - 2017-12-15 15:35:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 174
ERROR - 2017-12-15 15:35:27 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 171
ERROR - 2017-12-15 15:35:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 171
ERROR - 2017-12-15 15:35:27 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 174
ERROR - 2017-12-15 15:35:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 147
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 160
ERROR - 2017-12-15 15:35:59 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 176
ERROR - 2017-12-15 15:38:05 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-15 15:38:05 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-15 15:38:28 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-15 15:38:28 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-15 15:38:37 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-15 15:38:37 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-15 15:38:58 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-15 15:38:58 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-15 15:39:32 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-15 15:39:32 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-15 15:39:57 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-15 15:39:57 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-15 15:41:16 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-15 15:41:16 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-15 16:43:47 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 140
ERROR - 2017-12-15 16:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 139
ERROR - 2017-12-15 16:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 140
ERROR - 2017-12-15 16:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 140
ERROR - 2017-12-15 16:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 148
ERROR - 2017-12-15 16:43:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 152
ERROR - 2017-12-15 16:46:56 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-15 16:47:32 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-15 16:47:38 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
ERROR - 2017-12-15 16:47:45 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
