<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-19 08:55:27 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 08:55:35 --> 404 Page Not Found: /index
ERROR - 2018-01-19 08:55:35 --> 404 Page Not Found: /index
ERROR - 2018-01-19 08:55:35 --> 404 Page Not Found: /index
ERROR - 2018-01-19 08:55:35 --> 404 Page Not Found: /index
ERROR - 2018-01-19 08:55:35 --> 404 Page Not Found: /index
ERROR - 2018-01-19 08:55:35 --> 404 Page Not Found: /index
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 08:58:05 --> Severity: Notice --> Undefined property: stdClass::$school_id C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 127
ERROR - 2018-01-19 09:11:39 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:11:39 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:11:39 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:11:39 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:11:39 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:11:39 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:47:33 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 09:47:42 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:47:42 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:47:42 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:47:42 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:47:42 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:47:42 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:47:42 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:49:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 09:49:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 09:49:51 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2018-01-19 09:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2018-01-19 09:49:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 09:49:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 09:49:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 09:49:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 09:50:01 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 09:50:07 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:50:07 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:50:07 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:50:07 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:50:07 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:50:07 --> 404 Page Not Found: /index
ERROR - 2018-01-19 09:50:07 --> 404 Page Not Found: /index
ERROR - 2018-01-19 10:09:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 10:09:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 10:09:41 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2018-01-19 10:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2018-01-19 10:09:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 10:09:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 10:10:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 10:10:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 10:15:02 --> Severity: Error --> Call to undefined function file_name_info() C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 119
ERROR - 2018-01-19 11:29:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:29:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:29:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:29:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:29:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:29:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:29:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:29:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 11:29:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 334
ERROR - 2018-01-19 11:32:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 11:32:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:32:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:32:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:32:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:32:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:32:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:32:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:47:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:47:54 --> Severity: Notice --> Undefined variable: biodata C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 138
ERROR - 2018-01-19 11:48:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:48:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:48:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:48:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:48:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:48:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:48:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:48:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 11:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:27:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:27:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:27:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:27:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:27:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:27:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:27:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 12:28:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 12:28:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:29:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:29:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:30:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:30:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:30:50 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:30:50 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:30:51 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:30:51 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:30:51 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:30:51 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:30:51 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:32:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:32:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:33:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:20 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:20 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:20 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:20 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:20 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:20 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:33:20 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:15 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:15 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:15 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:15 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:15 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:15 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:15 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:35:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:35:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:35:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:35:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:57 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:57 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:57 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:57 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:35:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:51 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:55 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:36:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:02 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:02 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:02 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:02 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:02 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:02 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:02 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:33 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:33 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:33 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:33 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:33 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:33 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:33 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:36 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:36 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:36 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:36 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:36 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:36 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:36 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:44 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:44 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:44 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:44 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:44 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:44 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:37:44 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:38:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:38:23 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:23 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:23 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:23 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:23 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:23 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:23 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:38:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:39:19 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:39:19 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:39:19 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:39:19 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:39:19 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:39:19 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:40:12 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:40:12 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:40:12 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:40:12 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:40:12 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:40:12 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:40:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:40:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:40:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:41:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:41:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:41:52 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:41:52 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:41:52 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:41:52 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:41:52 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:41:52 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:42:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:42:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:42:46 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 12:42:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:42:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:42:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:42:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:42:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:42:53 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:45:26 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:45:26 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:45:26 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:45:26 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:45:26 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:45:26 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:45:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:45:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:45:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:46:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:46:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:46:03 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 12:46:09 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:09 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:09 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:09 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:09 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:09 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:17 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:18 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:18 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:18 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:18 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:18 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:37 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:42 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:43 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:43 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:43 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:43 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:43 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 12:46:51 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 12:46:54 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:54 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:54 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:54 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:54 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:46:54 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:48:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:48:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:48:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:48:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:48:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:48:32 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:49:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:49:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:49:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:49:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:49:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:49:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:49:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:49:40 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:50:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:50:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:53:16 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 12:53:21 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:53:21 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:53:21 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:53:21 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:53:21 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:53:21 --> 404 Page Not Found: /index
ERROR - 2018-01-19 12:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 12:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 335
ERROR - 2018-01-19 13:00:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:00:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:04:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:08:57 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:08:57 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:08:57 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:08:57 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:08:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:08:58 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:13:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:13:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 338
ERROR - 2018-01-19 13:18:22 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-19 13:18:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:18:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:18:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:18:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:18:27 --> 404 Page Not Found: /index
ERROR - 2018-01-19 13:18:27 --> 404 Page Not Found: /index
