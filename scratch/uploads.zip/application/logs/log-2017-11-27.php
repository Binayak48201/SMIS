<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-27 11:48:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:48:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:48:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:49:36 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 118
ERROR - 2017-11-27 11:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 118
ERROR - 2017-11-27 11:49:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:49:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:49:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:51:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:51:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:51:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:52:15 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 146
ERROR - 2017-11-27 11:52:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 146
ERROR - 2017-11-27 11:52:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 186
ERROR - 2017-11-27 11:52:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 186
ERROR - 2017-11-27 11:52:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 186
ERROR - 2017-11-27 11:52:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 186
ERROR - 2017-11-27 11:52:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 186
ERROR - 2017-11-27 11:52:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 186
ERROR - 2017-11-27 11:54:34 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2017-11-27 11:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2017-11-27 11:54:39 --> Severity: Notice --> Undefined variable: theme_option C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2017-11-27 11:54:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\views\common\footer.php 5
ERROR - 2017-11-27 11:57:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:57:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 11:57:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-27 14:42:01 --> Severity: Notice --> Undefined property: CI::$assessment_setting_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-11-27 14:42:01 --> Severity: Error --> Call to a member function get_assessments() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 67
ERROR - 2017-11-27 14:58:52 --> Query error: Column 'section_id' in where clause is ambiguous - Invalid query: SELECT `cd`.*, `sb`.*, `sc`.`section_name`
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `section_id` = '2'
ERROR - 2017-11-27 15:01:43 --> Query error: Column 'section_id' in where clause is ambiguous - Invalid query: SELECT `cd`.*, `sb`.*, `sc`.`section_name`
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `section_id` = '2'
ERROR - 2017-11-27 15:01:50 --> Query error: Column 'section_id' in where clause is ambiguous - Invalid query: SELECT `cd`.*, `sb`.*, `sc`.`section_name`
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `section_id` = '2'
ERROR - 2017-11-27 15:03:25 --> Query error: Column 'section_id' in where clause is ambiguous - Invalid query: SELECT `cd`.*, `sb`.*, `sc`.`section_name`
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `section_id` = '2'
ERROR - 2017-11-27 15:04:00 --> Query error: Column 'section_id' in where clause is ambiguous - Invalid query: SELECT `cd`.*, `sb`.*, `sc`.`section_name`
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `section_id` = ''
ERROR - 2017-11-27 15:04:18 --> Query error: Column 'section_id' in where clause is ambiguous - Invalid query: SELECT `cd`.*, `sb`.*, `sc`.`section_name`
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `section_id` = 1
