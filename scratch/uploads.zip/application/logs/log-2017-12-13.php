<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-13 14:02:38 --> 404 Page Not Found: ../modules/pages/controllers/classes/Class_manager/routine
