<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-23 14:27:17 --> Query error: Duplicate entry '298-53' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('09:45', '82', '298', '53', '2075-01-09', '2018-04-23', '82')
ERROR - 2018-04-23 15:18:51 --> Query error: Duplicate entry '269-44' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('10:45', '101', '269', '44', '2075-01-09', '2075-12-04', '101')
ERROR - 2018-04-23 15:37:18 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-04-23 15:37:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-04-23 15:37:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-04-23 15:37:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-04-23 15:37:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-04-23 15:37:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-04-23 15:37:52 --> Query error: Duplicate entry '349-43' for key 'unique_record' - Invalid query: INSERT INTO `class_days` (`class_time`, `employee_id`, `subject_id`, `section_id`, `start_date`, `end_date`, `updater`) VALUES ('10:15', '92', '349', '43', '2075-01-09', '2075-12-04', '92')
ERROR - 2018-04-23 15:49:18 --> Severity: Notice --> Undefined variable: res C:\xampp\htdocs\smis\application\modules\pages\models\classes\Lession_plan_model.php 26
