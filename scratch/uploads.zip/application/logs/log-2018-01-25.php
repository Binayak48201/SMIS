<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-25 09:34:54 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-25 09:34:59 --> Severity: Warning --> Missing argument 2 for Student_model::get_students(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php on line 225 and defined C:\xampp\htdocs\smis\application\modules\pages\models\profile\student_model.php 189
ERROR - 2018-01-25 09:34:59 --> Severity: Warning --> Missing argument 3 for Student_model::get_students(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php on line 225 and defined C:\xampp\htdocs\smis\application\modules\pages\models\profile\student_model.php 189
ERROR - 2018-01-25 09:34:59 --> 404 Page Not Found: /index
ERROR - 2018-01-25 09:36:20 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-25 09:36:25 --> Severity: Warning --> Missing argument 2 for Student_model::get_students(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php on line 225 and defined C:\xampp\htdocs\smis\application\modules\pages\models\profile\student_model.php 189
ERROR - 2018-01-25 09:36:25 --> Severity: Warning --> Missing argument 3 for Student_model::get_students(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php on line 225 and defined C:\xampp\htdocs\smis\application\modules\pages\models\profile\student_model.php 189
ERROR - 2018-01-25 09:36:26 --> 404 Page Not Found: /index
ERROR - 2018-01-25 09:37:36 --> 404 Page Not Found: /index
ERROR - 2018-01-25 14:18:09 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 14:22:10 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:04:37 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:04:46 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:04:50 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:05:54 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:06:11 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:06:11 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:06:12 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:06:13 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:06:14 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:06:15 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:06:16 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:07:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-25 15:07:59 --> 404 Page Not Found: /index
ERROR - 2018-01-25 15:07:59 --> 404 Page Not Found: /index
ERROR - 2018-01-25 15:07:59 --> 404 Page Not Found: /index
ERROR - 2018-01-25 15:09:11 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:25:45 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:39:09 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:39:14 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:40:44 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:42:05 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-01-25 15:46:32 --> 404 Page Not Found: ../modules/pages/controllers//index
