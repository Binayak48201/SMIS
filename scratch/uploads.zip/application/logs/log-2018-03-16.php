<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-16 12:06:42 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 157
ERROR - 2018-03-16 12:06:44 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 157
ERROR - 2018-03-16 12:06:47 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 157
ERROR - 2018-03-16 12:07:44 --> 404 Page Not Found: ../modules/pages/controllers/profile/Student/detail
ERROR - 2018-03-16 12:07:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:13:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:13:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:15:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:15:45 --> Severity: Notice --> Undefined property: stdClass::$district C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 172
ERROR - 2018-03-16 12:15:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:17:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:20:49 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:21:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:22:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:22:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:23:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:25:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:25:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:26:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:27:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:31:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:33:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:36:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:37:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:40:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:40:39 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:42:29 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 12:47:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 334
ERROR - 2018-03-16 12:47:58 --> Severity: Notice --> Undefined variable: main_content C:\xampp\htdocs\smis\application\modules\pages\views\ajax_template.php 4
ERROR - 2018-03-16 12:47:58 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 347
ERROR - 2018-03-16 13:26:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 13:26:42 --> Severity: Notice --> Undefined property: CI::$appraisal_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-16 13:26:42 --> Severity: Error --> Call to a member function get_appraisals() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 308
ERROR - 2018-03-16 13:26:56 --> Severity: Notice --> Undefined property: CI::$appraisal_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-16 13:26:56 --> Severity: Error --> Call to a member function get_appraisals() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 308
ERROR - 2018-03-16 13:27:59 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 7
ERROR - 2018-03-16 13:28:40 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 8
ERROR - 2018-03-16 13:44:42 --> Severity: Notice --> Undefined property: CI::$club_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-16 13:44:42 --> Severity: Error --> Call to a member function get_club_type() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 315
ERROR - 2018-03-16 13:44:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 13:44:47 --> Severity: Notice --> Undefined property: CI::$club_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-16 13:44:47 --> Severity: Error --> Call to a member function get_club_type() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 315
ERROR - 2018-03-16 13:45:18 --> Severity: Notice --> Undefined property: stdClass::$club_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 13
ERROR - 2018-03-16 13:45:18 --> Severity: Notice --> Undefined property: stdClass::$club_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 13
ERROR - 2018-03-16 13:45:18 --> Severity: Notice --> Undefined property: stdClass::$club_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 13
ERROR - 2018-03-16 13:45:18 --> Severity: Notice --> Undefined property: stdClass::$club_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 13
ERROR - 2018-03-16 13:46:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 13:46:33 --> Severity: Notice --> Undefined property: stdClass::$club_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 13
ERROR - 2018-03-16 13:46:33 --> Severity: Notice --> Undefined property: stdClass::$club_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 13
ERROR - 2018-03-16 13:46:33 --> Severity: Notice --> Undefined property: stdClass::$club_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 13
ERROR - 2018-03-16 13:46:33 --> Severity: Notice --> Undefined property: stdClass::$club_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 13
ERROR - 2018-03-16 13:51:48 --> Severity: Notice --> Undefined property: CI::$club_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-16 13:51:48 --> Severity: Error --> Call to a member function get_club_by_type() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 306
ERROR - 2018-03-16 13:51:55 --> Severity: Notice --> Undefined property: CI::$club_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-16 13:51:55 --> Severity: Error --> Call to a member function get_club_by_type() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 306
ERROR - 2018-03-16 13:54:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 13:57:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 13:57:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 13:57:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 13:58:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:03:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:05:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:06:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:07:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:13:00 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 68
ERROR - 2018-03-16 14:23:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:28:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:28:46 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:29:13 --> Query error: Table 'smis.student_clubs' doesn't exist - Invalid query: INSERT INTO `student_clubs` (`club_type`, `club`, `designation`, `student_id`) VALUES ('eca', '', 'dfsd', '1214')
ERROR - 2018-03-16 14:35:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:35:14 --> Severity: Notice --> Undefined property: stdClass::$delete_clubs C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 61
ERROR - 2018-03-16 14:35:14 --> Severity: Notice --> Undefined property: stdClass::$delete_clubs C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 61
ERROR - 2018-03-16 14:35:14 --> Severity: Notice --> Undefined property: stdClass::$delete_clubs C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 61
ERROR - 2018-03-16 14:35:14 --> Severity: Notice --> Undefined property: stdClass::$delete_clubs C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 61
ERROR - 2018-03-16 14:35:14 --> Severity: Notice --> Undefined property: stdClass::$delete_clubs C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 61
ERROR - 2018-03-16 14:35:14 --> Severity: Notice --> Undefined property: stdClass::$delete_clubs C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_clubs.php 61
ERROR - 2018-03-16 14:35:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:35:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:37:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:39:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:40:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:41:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:42:11 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:45:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 14:46:49 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:05:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:05:47 --> Severity: Error --> Call to undefined method Ajax_model::st_medical_condition() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 402
ERROR - 2018-03-16 15:07:12 --> Severity: Error --> Call to undefined method Ajax_model::st_medical_condition() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 405
ERROR - 2018-03-16 15:08:17 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:08:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:10:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:12:48 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:13:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:13:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:13:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:13:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:13:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:13:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:13:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:17:35 --> Severity: Notice --> Undefined variable: main_content C:\xampp\htdocs\smis\application\modules\pages\views\ajax_template.php 4
ERROR - 2018-03-16 15:17:35 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 347
ERROR - 2018-03-16 15:22:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:22:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:29:38 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:30:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:31:00 --> Severity: Notice --> Undefined property: stdClass::$club_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_medical_condition_list.php 18
ERROR - 2018-03-16 15:31:00 --> Severity: Notice --> Undefined property: stdClass::$club C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_medical_condition_list.php 19
ERROR - 2018-03-16 15:31:00 --> Severity: Notice --> Undefined property: stdClass::$designation C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_medical_condition_list.php 20
ERROR - 2018-03-16 15:31:00 --> Severity: Notice --> Undefined property: stdClass::$st_club_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_medical_condition_list.php 21
ERROR - 2018-03-16 15:31:05 --> Severity: Notice --> Undefined property: stdClass::$st_club_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_student_medical_conditions.php 67
ERROR - 2018-03-16 15:32:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:33:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:35:54 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:36:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:37:08 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:38:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:40:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:42:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:44:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:53:50 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:57:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:58:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:59:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:59:48 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 15:59:48 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:00:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:00:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:03:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:03:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:04:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:18:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:19:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:20:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:23:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:23:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:34:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:42:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:42:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:43:31 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-16 16:43:56 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
