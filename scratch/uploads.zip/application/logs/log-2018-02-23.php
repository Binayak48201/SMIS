<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-23 10:49:47 --> 404 Page Not Found: 
ERROR - 2018-02-23 11:02:15 --> Severity: Notice --> Undefined property: stdClass::$batch C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:02:15 --> Severity: Notice --> Undefined property: stdClass::$batch C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:02:15 --> Severity: Notice --> Undefined property: stdClass::$batch C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:02:21 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:02:21 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:02:21 --> Severity: Notice --> Undefined property: stdClass::$batch_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:02:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:02:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:02:28 --> Severity: Notice --> Undefined property: stdClass::$batch_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 181
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:28 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:35 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:09:36 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:09:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:09:45 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:13:08 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2018-02-23 11:14:28 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:28 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:28 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:14:29 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:14:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 190
ERROR - 2018-02-23 11:16:44 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 193
ERROR - 2018-02-23 11:16:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:17:00 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:20:45 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2018-02-23 11:20:47 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:47 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:20:48 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:20:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2018-02-23 11:21:11 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 183
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:55 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> unserialize(): Error at offset 0 of 1509 bytes C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 189
ERROR - 2018-02-23 11:21:56 --> Severity: Notice --> Undefined variable: assessments C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 192
ERROR - 2018-02-23 11:21:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\smis\system\core\Exceptions.php:271) C:\xampp\htdocs\smis\system\helpers\url_helper.php 561
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:57 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:21:58 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:21:58 --> Severity: Notice --> Undefined variable: assessment_ids C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 174
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:21 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-02-23 11:24:55 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-02-23 12:20:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-02-23 12:20:47 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-02-23 12:21:01 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-02-23 12:21:01 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-02-23 12:21:27 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-02-23 12:21:27 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-02-23 12:21:45 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-02-23 12:21:45 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-02-23 12:22:49 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-02-23 12:22:49 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-02-23 12:25:57 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-02-23 12:25:57 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
