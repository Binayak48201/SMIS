<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-06 09:49:30 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-06 10:54:30 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-03-06 10:54:32 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-03-06 11:21:58 --> 404 Page Not Found: ../modules/pages/controllers/exam/Exam_setting/exam_grade
ERROR - 2018-03-06 11:22:02 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 55
ERROR - 2018-03-06 11:22:02 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 73
ERROR - 2018-03-06 11:32:41 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-06 11:32:54 --> Query error: Unknown column 'matk_to' in 'order clause' - Invalid query: SELECT *
FROM `exam_grades`
ORDER BY `matk_to` DESC
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 106
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 106
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 107
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 107
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 108
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 108
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 109
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 109
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 111
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 111
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 120
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 120
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 121
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 121
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 106
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 106
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 107
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 107
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 108
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 108
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 109
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 109
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 111
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 111
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 120
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 120
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 121
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 121
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 106
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 106
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 107
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 107
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 108
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 108
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 109
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 109
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 111
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 111
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 120
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 120
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 121
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 121
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 106
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 106
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 107
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 107
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 108
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 108
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 109
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 109
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 111
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 111
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 120
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 120
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 121
ERROR - 2018-03-06 11:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 121
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 100
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 101
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 102
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 100
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 101
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 102
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 100
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 101
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 102
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 100
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 101
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 102
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:34:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 100
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 101
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 102
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 100
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 101
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 102
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 100
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 101
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 102
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 100
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 101
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 102
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 105
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 104
ERROR - 2018-03-06 11:59:13 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 11:59:13 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:00:04 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 12:00:04 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:00:09 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 12:00:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:00:14 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 12:00:14 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:00:18 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 12:00:18 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:00:21 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 12:00:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:00:25 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 12:00:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:00:29 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 12:00:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:00:33 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::delete_exam_grade(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php on line 268 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 103
ERROR - 2018-03-06 12:00:33 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 105
ERROR - 2018-03-06 12:15:17 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 176
ERROR - 2018-03-06 12:15:29 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 175
ERROR - 2018-03-06 12:15:36 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 175
ERROR - 2018-03-06 12:15:46 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 175
ERROR - 2018-03-06 12:15:51 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-06 12:15:58 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 175
ERROR - 2018-03-06 12:16:13 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 175
ERROR - 2018-03-06 12:16:17 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 175
ERROR - 2018-03-06 12:16:31 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 175
ERROR - 2018-03-06 12:17:06 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 120
ERROR - 2018-03-06 12:17:06 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 130
ERROR - 2018-03-06 12:17:06 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 130
ERROR - 2018-03-06 12:17:06 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 130
ERROR - 2018-03-06 12:17:06 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 130
ERROR - 2018-03-06 12:17:06 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 130
ERROR - 2018-03-06 12:17:06 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 130
ERROR - 2018-03-06 12:18:54 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 110
ERROR - 2018-03-06 12:18:54 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 110
ERROR - 2018-03-06 12:18:54 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 110
ERROR - 2018-03-06 12:18:54 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 110
ERROR - 2018-03-06 12:18:54 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 110
ERROR - 2018-03-06 12:18:54 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 110
ERROR - 2018-03-06 12:18:54 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 110
ERROR - 2018-03-06 12:19:46 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 112
ERROR - 2018-03-06 12:19:46 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 112
ERROR - 2018-03-06 12:19:46 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 112
ERROR - 2018-03-06 12:19:46 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 112
ERROR - 2018-03-06 12:19:46 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 112
ERROR - 2018-03-06 12:19:46 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 112
ERROR - 2018-03-06 12:19:46 --> Severity: Notice --> Undefined property: stdClass::$descrition C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_grade_setting.php 112
ERROR - 2018-03-06 12:44:10 --> 404 Page Not Found: ../modules/pages/controllers/classes/Attendance/index
ERROR - 2018-03-06 12:44:17 --> Severity: Warning --> Missing argument 1 for Attendance::add() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Attendance.php 18
ERROR - 2018-03-06 12:44:17 --> Severity: Notice --> Undefined variable: class_days_id C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Attendance.php 90
ERROR - 2018-03-06 12:44:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 20
ERROR - 2018-03-06 12:44:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\Marks_entry_model.php 21
ERROR - 2018-03-06 12:44:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 49
ERROR - 2018-03-06 12:44:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 61
ERROR - 2018-03-06 12:44:56 --> 404 Page Not Found: ../modules/pages/controllers/classes/Attendance/index
ERROR - 2018-03-06 12:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 49
ERROR - 2018-03-06 12:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 61
ERROR - 2018-03-06 12:45:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 49
ERROR - 2018-03-06 12:45:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\classes\add_attandance.php 61
ERROR - 2018-03-06 13:06:59 --> Severity: Warning --> Missing argument 1 for Exam_setting_model::get_exam_info(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php on line 182 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 40
ERROR - 2018-03-06 13:06:59 --> Severity: Warning --> Missing argument 2 for Exam_setting_model::get_exam_info(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php on line 182 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 40
ERROR - 2018-03-06 13:06:59 --> Severity: Warning --> Missing argument 3 for Exam_setting_model::get_exam_info(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php on line 182 and defined C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 40
ERROR - 2018-03-06 13:06:59 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 46
ERROR - 2018-03-06 13:06:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 47
ERROR - 2018-03-06 13:06:59 --> Severity: Notice --> Undefined variable: numeric_value C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 48
ERROR - 2018-03-06 13:17:24 --> Query error: Column 'subject_id' in group statement is ambiguous - Invalid query: SELECT `cd`.*, `s`.*, `sb`.*
FROM `class_days` `cd`
JOIN `section` `s` ON `s`.`section_id` = `cd`.`section_id`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `subject_id`
ERROR - 2018-03-06 13:17:33 --> Query error: Column 'subject_id' in group statement is ambiguous - Invalid query: SELECT `cd`.*, `s`.*, `sb`.*
FROM `class_days` `cd`
JOIN `section` `s` ON `s`.`section_id` = `cd`.`section_id`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `subject_id`
ERROR - 2018-03-06 13:18:03 --> Query error: Unknown column 's.subject_id' in 'group statement' - Invalid query: SELECT `cd`.*, `s`.*, `sb`.*
FROM `class_days` `cd`
JOIN `section` `s` ON `s`.`section_id` = `cd`.`section_id`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `s`.`subject_id`
ERROR - 2018-03-06 13:18:19 --> Query error: Unknown column 's.subject_id' in 'group statement' - Invalid query: SELECT *
FROM `class_days` `cd`
JOIN `section` `s` ON `s`.`section_id` = `cd`.`section_id`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `s`.`subject_id`
ERROR - 2018-03-06 13:18:56 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-06 13:19:05 --> Query error: Unknown column 's.subject_id' in 'group statement' - Invalid query: SELECT *
FROM `class_days` `cd`
JOIN `section` `s` ON `s`.`section_id` = `cd`.`section_id`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `s`.`subject_id`
ERROR - 2018-03-06 13:19:12 --> Query error: Unknown column 's.subject_id' in 'group statement' - Invalid query: SELECT *
FROM `class_days` `cd`
JOIN `section` `s` ON `s`.`section_id` = `cd`.`section_id`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
WHERE `s`.`batch` = ''
AND `s`.`grade` = ''
GROUP BY `s`.`subject_id`
ERROR - 2018-03-06 13:33:52 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `s`.`numeric_value`
ERROR - 2018-03-06 13:34:01 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `s`.`numeric_value`
ERROR - 2018-03-06 13:34:13 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `s`.`numeric_value`
ERROR - 2018-03-06 13:35:03 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `a`.`numeric_value`
ERROR - 2018-03-06 13:35:20 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `a`.`numeric_value`
ERROR - 2018-03-06 13:35:30 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `a`.`numeric_value`
ERROR - 2018-03-06 13:35:38 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `a`.`numeric_value`
ERROR - 2018-03-06 13:35:42 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `a`.`numeric_value`
ERROR - 2018-03-06 13:35:44 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `e`.`numeric_value`, `a`.`numeric_value`
ERROR - 2018-03-06 13:36:08 --> Query error: Unknown column 'e.numeric_value' in 'group statement' - Invalid query: SELECT `a`.*
FROM `assessment` `a`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `s`.`batch` = ''
AND `s`.`grade` = ''
GROUP BY `e`.`numeric_value`, `a`.`numeric_value`
ERROR - 2018-03-06 13:36:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 2
ERROR - 2018-03-06 13:36:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 2
ERROR - 2018-03-06 13:36:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 8
ERROR - 2018-03-06 13:36:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 28
ERROR - 2018-03-06 13:50:11 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 46
ERROR - 2018-03-06 13:50:11 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 46
ERROR - 2018-03-06 13:50:11 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 46
ERROR - 2018-03-06 13:50:11 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 46
ERROR - 2018-03-06 13:50:11 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 46
ERROR - 2018-03-06 13:50:11 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 46
ERROR - 2018-03-06 13:50:11 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 46
ERROR - 2018-03-06 13:50:38 --> Severity: Notice --> Undefined variable: full_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 47
ERROR - 2018-03-06 13:52:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 2
ERROR - 2018-03-06 13:52:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 2
ERROR - 2018-03-06 13:52:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 8
ERROR - 2018-03-06 14:17:45 --> Module controller failed to run: pages/ajax/get_exam_gradesa
ERROR - 2018-03-06 14:39:56 --> Severity: Notice --> Undefined property: stdClass::$section C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 17
ERROR - 2018-03-06 14:51:59 --> Query error: Not unique table/alias: 's' - Invalid query: SELECT `s`.*, `ca`.*
FROM (`student` `s`, `student`)
LEFT JOIN `class_attendance` `ca` ON `ca`.`student_id` = `s`.`student_id`
LEFT JOIN `exam` `e` ON `e`.`exam_id` = `ca`.`terminal_id`
LEFT JOIN `section` `s` ON `s`.`section_id` = `e`.`section_id`
WHERE `s`.`student_id` = '1218'
AND `s`.`grade` = 'One'
AND `s`.`batch` = '2073'
ERROR - 2018-03-06 14:52:13 --> Query error: Not unique table/alias: 's' - Invalid query: SELECT `s`.*, `ca`.*
FROM (`student` `s`, `student`)
LEFT JOIN `class_attendance` `ca` ON `ca`.`student_id` = `s`.`student_id`
LEFT JOIN `exam` `e` ON `e`.`exam_id` = `ca`.`terminal_id`
LEFT JOIN `section` `s` ON `s`.`section_id` = `e`.`section_id`
WHERE `s`.`student_id` = '1218'
AND `s`.`grade` = 'One'
AND `s`.`batch` = '2073'
ERROR - 2018-03-06 14:52:23 --> Query error: Not unique table/alias: 's' - Invalid query: SELECT `s`.*, `ca`.*
FROM (`student` `s`, `student`)
LEFT JOIN `class_attendance` `ca` ON `ca`.`student_id` = `s`.`student_id`
LEFT JOIN `exam` `e` ON `e`.`exam_id` = `ca`.`terminal_id`
LEFT JOIN `section` `s` ON `s`.`section_id` = `e`.`section_id`
WHERE `s`.`student_id` = ''
AND `s`.`grade` = ''
AND `s`.`batch` = ''
ERROR - 2018-03-06 14:52:54 --> Query error: Unknown column 's.student_id' in 'on clause' - Invalid query: SELECT `st`.*, `ca`.*
FROM (`student` `st`, `student`)
LEFT JOIN `class_attendance` `ca` ON `ca`.`student_id` = `s`.`student_id`
LEFT JOIN `exam` `e` ON `e`.`exam_id` = `ca`.`terminal_id`
LEFT JOIN `section` `s` ON `s`.`section_id` = `e`.`section_id`
WHERE `st`.`student_id` = ''
AND `s`.`grade` = ''
AND `s`.`batch` = ''
ERROR - 2018-03-06 15:11:24 --> Severity: Error --> Call to undefined method Ajax_model::get_st_with_attendance() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 189
ERROR - 2018-03-06 15:11:29 --> Severity: Error --> Call to undefined method Ajax_model::get_st_with_attendance() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 189
ERROR - 2018-03-06 15:11:33 --> Severity: Error --> Call to undefined method Ajax_model::get_st_with_attendance() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 189
ERROR - 2018-03-06 15:11:38 --> Severity: Error --> Call to undefined method Ajax_model::get_st_with_attendance() C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 189
ERROR - 2018-03-06 15:24:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 10
ERROR - 2018-03-06 15:24:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 10
ERROR - 2018-03-06 15:24:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 13
ERROR - 2018-03-06 15:24:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 13
ERROR - 2018-03-06 15:24:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 13
ERROR - 2018-03-06 15:24:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 16
ERROR - 2018-03-06 15:24:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 19
ERROR - 2018-03-06 15:24:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 55
ERROR - 2018-03-06 15:24:20 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 113
ERROR - 2018-03-06 15:41:33 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 117
ERROR - 2018-03-06 15:41:39 --> Severity: Warning --> Division by zero C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 117
ERROR - 2018-03-06 15:45:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 11
ERROR - 2018-03-06 15:45:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 11
ERROR - 2018-03-06 15:45:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 17
ERROR - 2018-03-06 15:45:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 20
ERROR - 2018-03-06 15:45:33 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 140
ERROR - 2018-03-06 15:45:33 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 142
ERROR - 2018-03-06 15:45:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 15:50:15 --> Severity: Error --> Call to undefined function pex() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 6
ERROR - 2018-03-06 15:50:27 --> Severity: Error --> Call to undefined function pex() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 6
ERROR - 2018-03-06 15:58:23 --> Severity: Notice --> Undefined property: stdClass::$grade C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 330
ERROR - 2018-03-06 16:00:34 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-06 16:07:15 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:07:15 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:07:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:07:22 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:07:22 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:07:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:07:25 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:07:25 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:07:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:07:38 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:07:38 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:07:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:07:50 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:07:50 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:07:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:07:57 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:07:57 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:08:07 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:08:07 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:08:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:08:12 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:08:12 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:08:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:08:52 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:08:52 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:08:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:08:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-06 16:08:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-06 16:08:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:08:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:08:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:08:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-06 16:08:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-06 16:08:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 67
ERROR - 2018-03-06 16:10:11 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:10:11 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:10:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:10:17 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:10:17 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:10:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:11:52 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:11:52 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:11:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:12:07 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 150
ERROR - 2018-03-06 16:12:07 --> Severity: Notice --> Undefined property: stdClass::$obtain_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 152
ERROR - 2018-03-06 16:12:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND `mark_to` > `IS` `NULL`' at line 3 - Invalid query: SELECT *
FROM `exam_grades`
WHERE `mark_from` < `IS` `NULL`
AND `mark_to` > `IS` `NULL`
ERROR - 2018-03-06 16:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 20
ERROR - 2018-03-06 16:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 20
ERROR - 2018-03-06 16:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 23
ERROR - 2018-03-06 16:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 23
ERROR - 2018-03-06 16:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 23
ERROR - 2018-03-06 16:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 26
ERROR - 2018-03-06 16:12:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 29
ERROR - 2018-03-06 16:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 67
ERROR - 2018-03-06 16:13:07 --> Severity: Notice --> Undefined variable: totaling C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 203
ERROR - 2018-03-06 16:32:15 --> Module controller failed to run: pages/ajax/get_appraisal_heads
ERROR - 2018-03-06 16:32:19 --> Module controller failed to run: pages/ajax/get_appraisal_heads
ERROR - 2018-03-06 16:32:34 --> Module controller failed to run: pages/ajax/get_appraisal_heads
ERROR - 2018-03-06 16:33:26 --> Module controller failed to run: pages/ajax/get_appraisal_heads
ERROR - 2018-03-06 16:33:52 --> Module controller failed to run: pages/ajax/get_appraisal_heads
ERROR - 2018-03-06 16:36:37 --> Query error: Unknown table 'smis.tc' - Invalid query: SELECT `tc`.*
FROM (`appraisal` `a`, `student`)
JOIN `appraisal_fields` `af` ON `af`.`field_id` = `a`.`field_id`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `a`.`student_id` = '1218'
AND `s`.`grade` = 'One'
AND `s`.`batch` = '2073'
AND `af`.`head_id` = '1'
ERROR - 2018-03-06 16:36:46 --> Query error: Unknown table 'smis.tc' - Invalid query: SELECT `tc`.*
FROM (`appraisal` `a`, `student`)
JOIN `appraisal_fields` `af` ON `af`.`field_id` = `a`.`field_id`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `a`.`student_id` = '1214'
AND `s`.`grade` = 'E'
AND `s`.`batch` = '2073'
AND `af`.`head_id` = '1'
ERROR - 2018-03-06 16:36:55 --> Query error: Unknown table 'smis.tc' - Invalid query: SELECT `tc`.*
FROM (`appraisal` `a`, `student`)
JOIN `appraisal_fields` `af` ON `af`.`field_id` = `a`.`field_id`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `a`.`student_id` = '1218'
AND `s`.`grade` = 'One'
AND `s`.`batch` = '2073'
AND `af`.`head_id` = '1'
ERROR - 2018-03-06 16:37:35 --> Query error: Unknown table 'smis.tc' - Invalid query: SELECT `tc`.*
FROM (`appraisal` `a`, `student`)
JOIN `appraisal_fields` `af` ON `af`.`field_id` = `a`.`field_id`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `a`.`student_id` = '1218'
AND `s`.`grade` = 'One'
AND `s`.`batch` = '2073'
AND `af`.`head_id` = '1'
ERROR - 2018-03-06 16:38:34 --> Query error: Unknown table 'smis.tc' - Invalid query: SELECT `tc`.*
FROM (`appraisal` `a`, `student`)
JOIN `appraisal_fields` `af` ON `af`.`field_id` = `a`.`field_id`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `a`.`student_id` = '1214'
AND `s`.`grade` = 'E'
AND `s`.`batch` = '2073'
AND `af`.`head_id` = '1'
ERROR - 2018-03-06 16:38:40 --> Query error: Unknown table 'smis.tc' - Invalid query: SELECT `tc`.*
FROM (`appraisal` `a`, `student`)
JOIN `appraisal_fields` `af` ON `af`.`field_id` = `a`.`field_id`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `a`.`student_id` = '1214'
AND `s`.`grade` = 'E'
AND `s`.`batch` = '2073'
AND `af`.`head_id` = '1'
ERROR - 2018-03-06 16:39:33 --> Query error: Unknown table 'smis.tc' - Invalid query: SELECT `tc`.*
FROM (`appraisal` `a`, `student`)
JOIN `appraisal_fields` `af` ON `af`.`field_id` = `a`.`field_id`
JOIN `section` `s` ON `s`.`section_id` = `a`.`section_id`
WHERE `a`.`student_id` = '1218'
AND `s`.`grade` = 'One'
AND `s`.`batch` = '2073'
ERROR - 2018-03-06 16:40:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-06 16:41:45 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:41:45 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:41:50 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:41:50 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:41:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-06 16:41:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-06 16:41:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:41:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:41:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:41:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-06 16:41:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-06 16:41:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 68
ERROR - 2018-03-06 16:42:13 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:42:13 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:42:29 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:42:29 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:44:17 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:44:17 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:44:28 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:44:28 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:44:36 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:44:36 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:44:43 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:44:43 --> Severity: Error --> Call to a member function result() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 321
ERROR - 2018-03-06 16:45:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-06 16:45:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 21
ERROR - 2018-03-06 16:45:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:45:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:45:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 24
ERROR - 2018-03-06 16:45:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 27
ERROR - 2018-03-06 16:45:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 30
ERROR - 2018-03-06 16:45:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 68
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$field_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 295
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$field_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 295
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$field_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 295
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$field_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 295
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$field_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 295
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$field_name C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 295
ERROR - 2018-03-06 16:47:29 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:52 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:52 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:52 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:52 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:52 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:47:52 --> Severity: Notice --> Undefined property: stdClass::$Grade C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 296
ERROR - 2018-03-06 16:53:59 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
