<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-13 15:21:36 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-13 19:37:14 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2018-04-13 19:37:14 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2018-04-13 19:42:26 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-13 19:42:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-13 19:53:11 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-13 19:53:41 --> 404 Page Not Found: /index
ERROR - 2018-04-13 19:53:41 --> 404 Page Not Found: /index
ERROR - 2018-04-13 19:54:10 --> Severity: Notice --> Undefined property: stdClass::$guardian_relation C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 487
ERROR - 2018-04-13 19:54:30 --> Severity: Notice --> Undefined property: stdClass::$guardian_relation C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 487
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 145
ERROR - 2018-04-13 19:55:50 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\exam\add_marks.php 158
ERROR - 2018-04-13 19:58:09 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-13 20:00:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-13 20:00:45 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:00:56 --> 404 Page Not Found: /index
ERROR - 2018-04-13 20:01:05 --> Severity: Notice --> Undefined property: stdClass::$guardian_relation C:\xampp\htdocs\smis\application\modules\pages\views\profile\edit_student.php 487
ERROR - 2018-04-13 20:02:31 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\st_bulk_edit.php 90
ERROR - 2018-04-13 20:05:22 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\terminal_total.php 95
ERROR - 2018-04-13 20:09:41 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-13 20:10:59 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
