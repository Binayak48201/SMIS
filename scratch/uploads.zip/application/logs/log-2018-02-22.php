<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-22 10:56:26 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
