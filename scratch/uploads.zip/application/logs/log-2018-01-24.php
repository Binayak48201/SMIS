<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-24 10:49:18 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '11'
ERROR - 2018-01-24 10:49:22 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '10'
ERROR - 2018-01-24 10:49:34 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '5'
ERROR - 2018-01-24 10:49:36 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '4'
ERROR - 2018-01-24 10:49:40 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '3'
ERROR - 2018-01-24 10:49:42 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 10:49:45 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '1'
ERROR - 2018-01-24 10:49:48 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 10:51:11 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '1'
ERROR - 2018-01-24 10:51:14 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 10:51:19 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '3'
ERROR - 2018-01-24 10:55:05 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '1'
ERROR - 2018-01-24 10:55:07 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 10:55:10 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '3'
ERROR - 2018-01-24 10:55:14 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '4'
ERROR - 2018-01-24 10:55:18 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '5'
ERROR - 2018-01-24 10:55:21 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '10'
ERROR - 2018-01-24 10:55:24 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '11'
ERROR - 2018-01-24 11:18:08 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-24 11:22:19 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 11:23:31 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpclassdays`, CONSTRAINT `FK_ncpclassdays` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 11:27:41 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpcoursecomment`, CONSTRAINT `FK_ncpcoursecomment1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 11:27:58 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpcoursecomment`, CONSTRAINT `FK_ncpcoursecomment1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 11:28:16 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncpshootsummarynew`, CONSTRAINT `FK_ncpshootsummarynew` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 11:28:38 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`smis`.`ncptermsummary`, CONSTRAINT `FK_ncptermsummary2` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`)) - Invalid query: DELETE FROM `employee`
WHERE `employee_id` = '2'
ERROR - 2018-01-24 14:53:46 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-24 14:53:54 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:53:54 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:53:54 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:53:54 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:53:54 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:53:54 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:55:18 --> 404 Page Not Found: ../modules/pages/controllers/profile/Student/reassign_student
ERROR - 2018-01-24 14:55:34 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 88
ERROR - 2018-01-24 14:56:07 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 88
ERROR - 2018-01-24 14:56:40 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\reassign_student.php 89
ERROR - 2018-01-24 14:56:46 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:56:46 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:56:46 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:56:46 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:56:46 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:56:46 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:58:27 --> 404 Page Not Found: /index
ERROR - 2018-01-24 14:58:32 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:00:22 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:00:58 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:01:56 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:50 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:50 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:50 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:50 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:50 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:50 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:50 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:59 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:59 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:59 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:59 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:59 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:02:59 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:03:06 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:03:06 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:03:06 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:03:06 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:03:06 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:03:06 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:03:06 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:05:47 --> Query error: Unknown column 'batch_id' in 'where clause' - Invalid query: SELECT `s`.*, `u`.`USER_NAME`
FROM `student` `s`
JOIN `users` `u` ON `u`.`PROFILE_ID` = `s`.`student_id`
WHERE `batch_id` = '2072'
AND `grade_id` = 'One'
ORDER BY `st_fname` ASC
ERROR - 2018-01-24 15:06:44 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:44 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:44 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:44 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:44 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:44 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:48 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:52 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:52 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:52 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:52 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:52 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:06:52 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:27:01 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 135
ERROR - 2018-01-24 15:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 144
ERROR - 2018-01-24 15:27:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 148
ERROR - 2018-01-24 15:27:46 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:27:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 135
ERROR - 2018-01-24 15:27:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:27:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:27:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 144
ERROR - 2018-01-24 15:27:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 148
ERROR - 2018-01-24 15:29:29 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:29:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 135
ERROR - 2018-01-24 15:29:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:29:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:29:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 144
ERROR - 2018-01-24 15:29:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 148
ERROR - 2018-01-24 15:37:25 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:37:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 135
ERROR - 2018-01-24 15:37:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:37:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:37:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 144
ERROR - 2018-01-24 15:37:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 148
ERROR - 2018-01-24 15:38:53 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:38:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:38:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:38:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:38:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-01-24 15:38:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-01-24 15:39:05 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:39:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:39:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:39:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:39:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-01-24 15:39:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-01-24 15:40:10 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-01-24 15:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-01-24 15:40:35 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:40:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:40:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:40:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:40:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-01-24 15:40:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-01-24 15:40:41 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 15:40:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 15:40:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:40:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 15:40:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-01-24 15:40:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-01-24 15:46:08 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 89
ERROR - 2018-01-24 15:46:36 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:46:56 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 89
ERROR - 2018-01-24 15:50:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:50:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:50:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:50:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:50:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 15:50:40 --> 404 Page Not Found: /index
ERROR - 2018-01-24 16:06:15 --> Query error: Unknown column 'st_id' in 'where clause' - Invalid query: UPDATE `student` SET `current_roll` = ''
WHERE `st_id` = '1199'
ERROR - 2018-01-24 16:06:41 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-01-24 16:06:51 --> Query error: Unknown column 'st_id' in 'where clause' - Invalid query: UPDATE `student` SET `current_roll` = '1'
WHERE `st_id` = '1199'
ERROR - 2018-01-24 16:07:10 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-01-24 16:07:27 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-01-24 16:07:51 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-24 16:07:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-24 16:07:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 16:07:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-24 16:07:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-01-24 16:07:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-01-24 16:07:56 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
