<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-28 10:04:16 --> Severity: Notice --> Undefined variable: main_content C:\xampp\htdocs\smis\application\modules\pages\views\template.php 4
ERROR - 2018-01-28 10:04:16 --> Severity: Notice --> Undefined variable: _ci_file C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 347
ERROR - 2018-01-28 10:44:49 --> Severity: Notice --> Undefined variable: year C:\xampp\htdocs\smis\application\modules\pages\models\classes\class_manager_model.php 43
ERROR - 2018-01-28 12:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 20
ERROR - 2018-01-28 12:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 21
ERROR - 2018-01-28 12:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 35
ERROR - 2018-01-28 12:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 36
ERROR - 2018-01-28 12:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 50
ERROR - 2018-01-28 12:37:32 --> Severity: Error --> Call to undefined function faculty_restrict() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\marks_entry.php 90
ERROR - 2018-01-28 12:38:57 --> Severity: Notice --> Undefined property: stdClass::$picture C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 53
ERROR - 2018-01-28 12:38:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 136
ERROR - 2018-01-28 12:38:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-28 12:38:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 137
ERROR - 2018-01-28 12:38:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 145
ERROR - 2018-01-28 12:38:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\view_lesson_plan.php 149
ERROR - 2018-01-28 12:42:25 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
ERROR - 2018-01-28 12:54:02 --> Severity: Notice --> Undefined variable: class_days C:\xampp\htdocs\smis\application\helpers\General_Helper.php 194
ERROR - 2018-01-28 12:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 20
ERROR - 2018-01-28 12:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 21
ERROR - 2018-01-28 12:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 35
ERROR - 2018-01-28 12:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 36
ERROR - 2018-01-28 12:55:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\models\exam\marks_entry_model.php 50
ERROR - 2018-01-28 13:08:46 --> Severity: Notice --> Undefined variable: ci C:\xampp\htdocs\smis\application\helpers\General_Helper.php 195
ERROR - 2018-01-28 13:08:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\helpers\General_Helper.php 195
ERROR - 2018-01-28 13:08:46 --> Severity: Error --> Call to a member function userdata() on null C:\xampp\htdocs\smis\application\helpers\General_Helper.php 195
ERROR - 2018-01-28 16:22:53 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-28 16:23:01 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:23:01 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:23:01 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:23:01 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:25:04 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-28 16:26:21 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:26:21 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:26:21 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:26:21 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:36:59 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-01-28 16:37:05 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:37:05 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:37:05 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:46:29 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:46:29 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:46:29 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:46:29 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:46:29 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:46:29 --> 404 Page Not Found: /index
ERROR - 2018-01-28 16:46:29 --> 404 Page Not Found: /index
