<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-02 11:32:54 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
