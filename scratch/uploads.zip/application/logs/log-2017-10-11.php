<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-11 10:10:57 --> Severity: Notice --> Undefined variable: results3 C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
ERROR - 2017-10-11 10:10:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\profile\add_employee.php 102
