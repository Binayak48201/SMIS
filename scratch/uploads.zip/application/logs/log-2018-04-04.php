<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 12:09:42 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 12:53:34 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_attendance_report.php 95
ERROR - 2018-04-04 12:56:16 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 13:10:47 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 13:14:49 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 13:39:55 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 13:40:01 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Academic_report.php 715
ERROR - 2018-04-04 13:40:01 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 13:48:15 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 13:49:14 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 13:50:34 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 13:51:04 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 13:51:34 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 14:03:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 14:03:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 14:03:32 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 14:03:32 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 14:03:32 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 14:03:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 14:03:33 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 14:03:33 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 14:03:33 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1072
ERROR - 2018-04-04 14:05:12 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 14:12:56 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 14:14:25 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 14:19:03 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 14:21:02 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 14:21:56 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 14:29:16 --> Severity: Notice --> Undefined variable: prev_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-04 14:29:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_classes.php 71
ERROR - 2018-04-04 14:41:45 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 14:41:57 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/st_appraisal
ERROR - 2018-04-04 14:43:36 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/st_appraisal
ERROR - 2018-04-04 14:50:34 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_students_for_eval.php 34
ERROR - 2018-04-04 14:50:42 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_students_for_eval.php 34
ERROR - 2018-04-04 14:52:55 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:53:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:53:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 14:53:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-04 14:54:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-04 14:54:52 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-04 14:56:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:56:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:56:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 14:57:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-04 14:57:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:57:18 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 14:57:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:57:18 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 14:57:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:57:18 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 14:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:01:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-04 15:01:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:12 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:01:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:12 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:01:12 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:12 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:01:56 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-04 15:01:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:56 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:01:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:56 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:01:56 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:56 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:02:55 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-04 15:03:13 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\exam\marksheet_allow.php 95
ERROR - 2018-04-04 15:03:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\student_home.php 58
ERROR - 2018-04-04 15:03:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:03:16 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:03:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:03:16 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:03:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:03:16 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:13:18 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/st_appraisal
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:16:08 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:18 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:17:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:17:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:41 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:17:41 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:41 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:17:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:42 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:17:42 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:42 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:17:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:21:41 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 355
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:22:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:22:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:22:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:22:09 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:22:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:31:10 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 15:33:11 --> Severity: Notice --> Undefined variable: subject C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_students_for_eval.php 31
ERROR - 2018-04-04 15:33:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\list_students_for_eval.php 31
ERROR - 2018-04-04 15:34:39 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:08 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 179
ERROR - 2018-04-04 15:43:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:48 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:43:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 74
ERROR - 2018-04-04 15:45:03 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:45:03 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:45:03 --> Severity: Notice --> Undefined variable: total_obtain C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 264
ERROR - 2018-04-04 15:45:18 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:45:18 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:45:18 --> Severity: Notice --> Undefined variable: total_obtain C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 264
ERROR - 2018-04-04 15:45:40 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:45:40 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:45:40 --> Severity: Notice --> Undefined variable: total_obtain C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_view.php 264
ERROR - 2018-04-04 15:46:22 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:22 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:27 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:27 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:43 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:43 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:43 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:46:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\print_all_marksheet.php 84
ERROR - 2018-04-04 15:49:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:49:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:49:16 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:49:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:49:16 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:49:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:49:17 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:49:17 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:49:17 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:50:04 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:52:05 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:52:05 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:53:42 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 172
ERROR - 2018-04-04 15:53:50 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 172
ERROR - 2018-04-04 15:53:54 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\smis\application\modules\pages\models\exam\Exam_setting_model.php 172
ERROR - 2018-04-04 15:54:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:15 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:25 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:26 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:54:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:34 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:34 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:34 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:35 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:35 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:35 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:54:48 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:55:14 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 15:56:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 15:56:15 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:56:15 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:56:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:56:16 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:56:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:56:16 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:56:16 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:56:16 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 15:57:57 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 16:02:29 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 16:05:00 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 16:08:40 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 16:10:56 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 16:21:03 --> Severity: Notice --> Undefined variable: opd_id C:\xampp\htdocs\smis\application\modules\pages\models\profile\Evaluation_model.php 47
ERROR - 2018-04-04 16:35:26 --> Severity: Notice --> Undefined variable: section_id C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 93
ERROR - 2018-04-04 16:35:26 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 93
ERROR - 2018-04-04 16:35:36 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 93
ERROR - 2018-04-04 16:35:36 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 93
ERROR - 2018-04-04 16:39:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:39:55 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:41:43 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 16:43:06 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:06 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:07 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:07 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:07 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:07 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:43:29 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:46:45 --> Query error: Unknown column 's.section' in 'where clause' - Invalid query: SELECT *
FROM `subject_evaluation` `se`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
JOIN `section` `s` ON `s`.`section_id` = `e`.`section_id`
JOIN `subject` `sb` ON `sb`.`subject_id` = `e`.`subject_id`
WHERE `s`.`section` = '17'
GROUP BY `e`.`exam_id`, `e`.`subject_id`
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:47:59 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:48:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 16:48:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:48:30 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:48:30 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:48:30 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:48:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:48:31 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:48:31 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:48:31 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined variable: grade C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:00 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1080
ERROR - 2018-04-04 16:51:37 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 16:53:12 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 16:56:15 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-04 16:56:24 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/st_appraisal
