<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-11 09:38:48 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-11 09:57:58 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-11 10:00:02 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-11 10:01:20 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-11 10:03:39 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-11 10:45:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:45:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:45:17 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:46:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 24
ERROR - 2018-03-11 10:48:16 --> Severity: Notice --> Undefined variable: final_mark C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 23
ERROR - 2018-03-11 10:53:33 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 16
ERROR - 2018-03-11 10:53:33 --> Severity: Notice --> Undefined property: stdClass::$total_marks C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 16
ERROR - 2018-03-11 10:55:56 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 56
ERROR - 2018-03-11 10:56:02 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 56
ERROR - 2018-03-11 10:56:33 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 56
ERROR - 2018-03-11 10:56:43 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 56
ERROR - 2018-03-11 10:57:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 11
ERROR - 2018-03-11 11:26:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 19
ERROR - 2018-03-11 11:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 49
ERROR - 2018-03-11 11:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 49
ERROR - 2018-03-11 11:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 50
ERROR - 2018-03-11 11:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 50
ERROR - 2018-03-11 11:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\marksheet_graph_view.php 50
ERROR - 2018-03-11 11:28:17 --> Severity: Parsing Error --> syntax error, unexpected '$subject' (T_VARIABLE), expecting ')' C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 372
ERROR - 2018-03-11 11:29:43 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-11 11:37:14 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-11 12:21:38 --> Severity: Parsing Error --> syntax error, unexpected ''tttt;' (T_ENCAPSED_AND_WHITESPACE) C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 282
