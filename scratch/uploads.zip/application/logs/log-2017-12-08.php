<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-08 10:13:01 --> Severity: Notice --> Undefined property: CI::$program_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-12-08 10:13:01 --> Severity: Error --> Call to a member function get_program_by_level() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 346
ERROR - 2017-12-08 10:37:09 --> Query error: Unknown column 'cd.updater' in 'field list' - Invalid query: SELECT `lp`.*, `cd`.`updater`
FROM `lession_plan` `lp`
JOIN `class_days` `cd` ON `cd`.`class_days_id` = `lp`.`class_days_id`
WHERE `lp`.`class_days_id` = '1295'
ORDER BY `lp`.`ch_id` ASC
ERROR - 2017-12-08 10:38:20 --> Severity: Notice --> Undefined variable: session_start C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 10:40:08 --> Severity: Notice --> Undefined variable: session_start C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 10:42:55 --> Severity: Notice --> Undefined variable: session_start C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 10:44:08 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-08 10:44:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-08 10:44:13 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-08 10:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-08 10:44:25 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-08 10:44:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-08 10:46:34 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-08 10:46:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\control\employee_list.php 201
ERROR - 2017-12-08 10:50:20 --> Severity: Notice --> Undefined property: CI::$course_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2017-12-08 10:50:20 --> Severity: Error --> Call to a member function get_courses_by_id() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 352
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:05 --> Severity: Notice --> Undefined variable: session_start C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 190
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:54:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:55:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\smis\system\database\DB_query_builder.php 683
ERROR - 2017-12-08 10:55:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 5 - Invalid query: SELECT `cd`.*, `sb`.*, `sc`.`section_name`
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `cd`.`section_id` =
ERROR - 2017-12-08 10:56:28 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\smis\system\database\DB_query_builder.php 683
ERROR - 2017-12-08 10:56:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 5 - Invalid query: SELECT `cd`.*, `sb`.*, `sc`.`section_name`
FROM `class_days` `cd`
JOIN `subject` `sb` ON `sb`.`subject_id` = `cd`.`subject_id`
JOIN `section` `sc` ON `sc`.`section_id` = `cd`.`section_id`
WHERE `cd`.`section_id` =
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 10:57:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:06:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 170
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:43 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:08:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:09:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:10:02 --> Severity: Error --> Call to undefined function faculty_class_restrict() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Lession_plan.php 364
ERROR - 2017-12-08 11:10:58 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-08 11:10:58 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:11:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:01 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-08 11:14:01 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-08 11:14:06 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-08 11:14:06 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Undefined variable: section C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 107
ERROR - 2017-12-08 11:18:43 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-08 11:18:43 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-08 11:19:00 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-08 11:19:00 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-08 11:19:04 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 102
ERROR - 2017-12-08 11:19:04 --> Severity: Notice --> Undefined variable: subjects C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_lession_plan.php 120
ERROR - 2017-12-08 11:29:34 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 156
ERROR - 2017-12-08 11:29:34 --> Severity: Error --> Call to a member function num_rows() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 156
ERROR - 2017-12-08 11:29:36 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 156
ERROR - 2017-12-08 11:29:36 --> Severity: Error --> Call to a member function num_rows() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 156
ERROR - 2017-12-08 11:30:34 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 156
ERROR - 2017-12-08 11:30:34 --> Severity: Error --> Call to a member function num_rows() on null C:\xampp\htdocs\smis\application\modules\pages\models\ajax_model.php 156
