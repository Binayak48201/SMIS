<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-23 09:38:01 --> Query error: Duplicate entry '2071' for key 'batch_name' - Invalid query: INSERT INTO `batch` (`batch_name`) VALUES ('2071')
ERROR - 2017-10-23 09:42:10 --> Query error: Duplicate entry '2072' for key 'batch_name' - Invalid query: INSERT INTO `batch` (`batch_name`) VALUES ('2072')
