<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-27 09:50:31 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-27 09:50:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 09:51:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 09:52:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 09:54:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 11:18:25 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-27 11:18:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 11:49:29 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:49:54 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:50:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:50:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:50:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:50:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:50:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:50:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 11:50:33 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:31:59 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 12:41:36 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:10:06 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:12:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:12:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:14:00 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:14:00 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:14:00 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:14:00 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:14:00 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:17:52 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:17:52 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:18:58 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:19 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-27 13:23:24 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:24 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:24 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:24 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:23:25 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:34:23 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:34:23 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:42 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 13:39:51 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:14:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:20:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:20:48 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:20:56 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 601
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 601
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 45
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 52
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 97
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 100
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 158
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 162
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 164
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 168
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 170
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 175
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 177
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 181
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 183
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 187
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 189
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 193
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 195
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 199
ERROR - 2018-03-27 14:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 201
ERROR - 2018-03-27 14:28:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:36:31 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 613
ERROR - 2018-03-27 14:36:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:40:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 602
ERROR - 2018-03-27 14:51:44 --> Query error: Unknown column 'e.exma_id' in 'on clause' - Invalid query: SELECT *
FROM `student_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exma_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `exam_id`
ERROR - 2018-03-27 14:51:59 --> Query error: Column 'exam_id' in group statement is ambiguous - Invalid query: SELECT *
FROM `student_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `exam_id`
ERROR - 2018-03-27 14:52:00 --> Query error: Column 'exam_id' in group statement is ambiguous - Invalid query: SELECT *
FROM `student_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `s`.`batch` = '2073'
AND `s`.`grade` = 'One'
GROUP BY `exam_id`
ERROR - 2018-03-27 14:56:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:57:13 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:58:00 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:58:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:58:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 251
ERROR - 2018-03-27 14:58:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 14:59:15 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:15 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:15 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:15 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:15 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:15 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:16 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 14:59:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:02:11 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:02:26 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:02:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:02:58 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:03:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:03:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:04:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:04:06 --> 404 Page Not Found: ../modules/pages/controllers/Ajax/st_evaluation
ERROR - 2018-03-27 15:04:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:05:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:05:21 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:05:37 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:06:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:08:03 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:09 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:10 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:10 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:10 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:10 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:10 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:10 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:10 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:08:10 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:09:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:09:53 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:10:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:10:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:10:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:11:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:14:00 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:14:00 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:14:47 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-27 15:16:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:18:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:18:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:18:38 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:18:38 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:26 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:26 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:26 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:26 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:26 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:22:27 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:26:16 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-27 15:26:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:26:39 --> Query error: Unknown column 'se.st_id' in 'where clause' - Invalid query: SELECT *
FROM `student_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `se`.`st_id` = '1214'
AND `se`.`exam_id` = '13'
ERROR - 2018-03-27 15:26:46 --> Query error: Unknown column 'se.st_id' in 'where clause' - Invalid query: SELECT *
FROM `student_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `se`.`st_id` = '1214'
AND `se`.`exam_id` = '13'
ERROR - 2018-03-27 15:27:05 --> Query error: Unknown column 'se.st_id' in 'where clause' - Invalid query: SELECT *
FROM `student_evaluation` `se`
JOIN `section` `s` ON `s`.`section_id` = `se`.`section_id`
JOIN `exam` `e` ON `e`.`exam_id` = `se`.`exam_id`
WHERE `se`.`st_id` = '1214'
AND `se`.`exam_id` = '13'
ERROR - 2018-03-27 15:33:23 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 53
ERROR - 2018-03-27 15:33:23 --> Severity: Notice --> Undefined variable: grades C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 71
ERROR - 2018-03-27 15:33:23 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: st_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:34:22 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:34:22 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 49
ERROR - 2018-03-27 15:37:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:23 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:23 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 49
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 16
ERROR - 2018-03-27 15:37:33 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:37:33 --> Severity: Notice --> Undefined variable: exam_id C:\xampp\htdocs\smis\application\modules\pages\views\reports\st_class_evalution.php 49
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:38:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:07 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:39:36 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:15 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:19 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:20 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:26 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:27 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:53 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:55 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:41:57 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:42:11 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:17 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:18 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:18 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:18 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:18 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:18 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:18 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:18 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:18 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:42:19 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:42:21 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:42:21 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:42:36 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:44 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:44:46 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:16 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:17 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:45:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:45:38 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:45:56 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:47:31 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:47:33 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:48:30 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:48:50 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:50:20 --> Module controller failed to run: pages/evaluation/test
ERROR - 2018-03-27 15:50:21 --> Module controller failed to run: pages/evaluation/test
ERROR - 2018-03-27 15:50:48 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-03-27 15:51:07 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-03-27 15:51:11 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-03-27 15:51:15 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2018-03-27 15:51:53 --> 404 Page Not Found: ../modules/pages/controllers/profile/Evaluation/get_evaluation_option1
ERROR - 2018-03-27 15:52:28 --> 404 Page Not Found: ../modules/pages/controllers/profile/Evaluation/get_evaluation_option1
ERROR - 2018-03-27 15:52:30 --> 404 Page Not Found: ../modules/pages/controllers/profile/Evaluation/get_evaluation_option1
ERROR - 2018-03-27 15:52:34 --> Severity: Notice --> Undefined variable: evaluation C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1015
ERROR - 2018-03-27 15:52:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1015
ERROR - 2018-03-27 15:52:35 --> Severity: Notice --> Undefined variable: evaluation C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1015
ERROR - 2018-03-27 15:52:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1015
ERROR - 2018-03-27 15:52:37 --> Severity: Notice --> Undefined variable: evaluation C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1015
ERROR - 2018-03-27 15:52:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1015
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:08 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_evaluation_option
ERROR - 2018-03-27 15:53:10 --> Module controller failed to run: pages/evaluation/get_st_evaluated
ERROR - 2018-03-27 15:53:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:53:22 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:54:49 --> 404 Page Not Found: /index
ERROR - 2018-03-27 15:55:46 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:56:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:57:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 15:57:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 16:00:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 16:00:17 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 16:00:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 16:01:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-27 16:16:38 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:38 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
ERROR - 2018-03-27 16:16:39 --> 404 Page Not Found: /index
