<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-05 09:26:56 --> Severity: Error --> Class 'Club_manager_model' not found C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 228
ERROR - 2018-02-05 09:31:32 --> Severity: Notice --> Undefined property: CI::$evaluation_criteria_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-02-05 09:31:32 --> Severity: Error --> Call to a member function get_evaluation_type() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Club_manager.php 50
ERROR - 2018-02-05 09:35:22 --> Severity: Error --> Call to undefined method Club_manager_model::get_evaluation_option() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Club_manager.php 147
ERROR - 2018-02-05 09:36:37 --> 404 Page Not Found: ../modules/pages/controllers/classes/Club_manager/get_clubs
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined variable: type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 12
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:38:28 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined variable: type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 12
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:39:32 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined variable: type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 12
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 31
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 32
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:03 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_evaluation_option.php 33
ERROR - 2018-02-05 09:40:34 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 31
ERROR - 2018-02-05 09:40:34 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 32
ERROR - 2018-02-05 09:40:34 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 32
ERROR - 2018-02-05 09:40:34 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:40:34 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:40:34 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 31
ERROR - 2018-02-05 09:40:34 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 32
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 32
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 31
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 32
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 32
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 31
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_name C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 32
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 32
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:40:35 --> Severity: Notice --> Undefined property: stdClass::$evaluation_option_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:41:10 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:41:10 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:41:10 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 09:41:10 --> Severity: Notice --> Undefined property: stdClass::$evaluation_type_id C:\xampp\htdocs\smis\application\modules\pages\views\classes\ajax_clubs.php 33
ERROR - 2018-02-05 10:05:40 --> Severity: Notice --> Undefined property: CI::$district_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-02-05 10:05:40 --> Severity: Error --> Call to a member function get_district() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Department_manager.php 34
ERROR - 2018-02-05 10:05:54 --> Severity: Error --> Call to undefined method Department_manager_model::get_district() C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Department_manager.php 34
ERROR - 2018-02-05 10:07:55 --> Severity: Warning --> Missing argument 1 for Department_manager_model::update(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Department_manager.php on line 66 and defined C:\xampp\htdocs\smis\application\modules\pages\models\classes\Department_manager_model.php 25
ERROR - 2018-02-05 10:07:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\smis\application\modules\pages\models\classes\Department_manager_model.php 28
ERROR - 2018-02-05 10:14:54 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-05 10:16:24 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-05 10:16:41 --> 404 Page Not Found: /index
ERROR - 2018-02-05 10:16:41 --> 404 Page Not Found: /index
ERROR - 2018-02-05 10:16:41 --> 404 Page Not Found: /index
ERROR - 2018-02-05 10:16:41 --> 404 Page Not Found: /index
ERROR - 2018-02-05 10:16:41 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:36 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:37 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:37 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:37 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:20:53 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:12 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\manage_student.php 88
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 11:35:18 --> 404 Page Not Found: /index
ERROR - 2018-02-05 12:10:50 --> 404 Page Not Found: ../modules/pages/controllers/Home/site_map
ERROR - 2018-02-05 12:12:29 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\smis\application\modules\theme_option\views\site_map.php 44
ERROR - 2018-02-05 12:14:18 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\profile\roll_no_reassign.php 90
