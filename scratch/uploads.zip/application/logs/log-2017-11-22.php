<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-11-22 13:05:24 --> Severity: Notice --> Undefined variable: programlevels C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 62
ERROR - 2017-11-22 13:05:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 62
ERROR - 2017-11-22 13:06:07 --> Severity: Notice --> Undefined variable: programlevels C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 62
ERROR - 2017-11-22 13:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 62
ERROR - 2017-11-22 13:06:57 --> Severity: Notice --> Undefined variable: programlevels C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 66
ERROR - 2017-11-22 13:06:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 66
ERROR - 2017-11-22 13:40:43 --> Severity: Notice --> Undefined property: stdClass::$course_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 174
ERROR - 2017-11-22 13:40:43 --> Severity: Notice --> Undefined property: stdClass::$exam_name C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 176
ERROR - 2017-11-22 13:40:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 180
ERROR - 2017-11-22 13:40:43 --> Severity: Notice --> Undefined property: stdClass::$exam_setting_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 189
ERROR - 2017-11-22 13:41:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 180
ERROR - 2017-11-22 13:41:18 --> Severity: Notice --> Undefined property: stdClass::$exam_setting_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 189
ERROR - 2017-11-22 13:43:01 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:43:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:43:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:45:06 --> Query error: Duplicate entry '1-56-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`) VALUES ('1', 'First Term', '1', '56', '100', '45', '20')
ERROR - 2017-11-22 13:45:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:45:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:11 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:11 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:18 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:47:42 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:55:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:55:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:57:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:57:59 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:57:59 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 291
ERROR - 2017-11-22 13:58:00 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-11-22 13:58:02 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:58:02 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:58:02 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 291
ERROR - 2017-11-22 13:59:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:59:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 13:59:04 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 291
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 138
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 138
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 1
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 106
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 114
ERROR - 2017-11-22 13:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 122
ERROR - 2017-11-22 14:07:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:07:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:07:15 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 291
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 138
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 138
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\classes\Course_manager.php 139
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 1
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 13
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 33
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 93
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 106
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 114
ERROR - 2017-11-22 14:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\classes\edit_course.php 122
ERROR - 2017-11-22 14:08:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:08:12 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:08:12 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 291
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 166
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 166
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 167
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 167
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 1
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 88
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 106
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 114
ERROR - 2017-11-22 14:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 122
ERROR - 2017-11-22 14:08:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:08:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:08:16 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 291
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 166
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 166
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 167
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 167
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 1
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 88
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 106
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 114
ERROR - 2017-11-22 14:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 122
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 167
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 167
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 168
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 168
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 1
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 13
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 33
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 88
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 106
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 114
ERROR - 2017-11-22 14:11:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 122
ERROR - 2017-11-22 14:12:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 166
ERROR - 2017-11-22 14:13:24 --> Severity: Notice --> Undefined property: stdClass::$class_days_id C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 1
ERROR - 2017-11-22 14:13:24 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 88
ERROR - 2017-11-22 14:13:24 --> Severity: Notice --> Undefined property: stdClass::$class_time C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 106
ERROR - 2017-11-22 14:13:24 --> Severity: Notice --> Undefined property: stdClass::$start_date C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 114
ERROR - 2017-11-22 14:13:24 --> Severity: Notice --> Undefined property: stdClass::$end_date C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 122
ERROR - 2017-11-22 14:14:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:14:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:14:27 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 291
ERROR - 2017-11-22 14:14:30 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 88
ERROR - 2017-11-22 14:14:30 --> Severity: Notice --> Undefined property: stdClass::$class_time C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 106
ERROR - 2017-11-22 14:14:30 --> Severity: Notice --> Undefined property: stdClass::$start_date C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 114
ERROR - 2017-11-22 14:14:30 --> Severity: Notice --> Undefined property: stdClass::$end_date C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 122
ERROR - 2017-11-22 14:16:09 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 88
ERROR - 2017-11-22 14:17:23 --> Severity: Notice --> Undefined variable: teachers C:\xampp\htdocs\smis\application\modules\pages\views\exam\edit_exam.php 88
ERROR - 2017-11-22 14:26:23 --> Severity: Error --> Call to undefined method Exam_setting_model::update() C:\xampp\htdocs\smis\application\modules\pages\controllers\exam\exam_setting.php 193
ERROR - 2017-11-22 14:27:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:27:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:27:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:27:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:30:54 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-11-22 14:31:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:31:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:31:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:31:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:31:18 --> 404 Page Not Found: ../modules/pages/controllers//index
ERROR - 2017-11-22 14:31:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:31:27 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:31:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:31:43 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:31:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:35:31 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:35:31 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:35:46 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:35:46 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:35:46 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:50:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:50:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:50:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:50:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:50:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:50:57 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 14:55:48 --> 404 Page Not Found: ../modules/pages/controllers/exam//index
ERROR - 2017-11-22 16:01:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 16:01:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 16:01:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 16:02:07 --> Query error: Duplicate entry '2-56-1' for key 'unique_record' - Invalid query: INSERT INTO `exam` (`section_id`, `terminal_name`, `numeric_value`, `subject_id`, `full_mark`, `pass_mark`, `average_at`) VALUES ('2', 'First Term', '1', '56', '100', '45', '20')
ERROR - 2017-11-22 16:02:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 16:02:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
ERROR - 2017-11-22 16:02:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\exam\exam_setting.php 179
