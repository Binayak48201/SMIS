<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-20 10:32:27 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-20 10:32:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-20 12:14:52 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\exam_summary_report.php 95
ERROR - 2018-03-20 12:15:06 --> Severity: Error --> Class 'Employee_reports_model' not found C:\xampp\htdocs\smis\application\third_party\MX\Loader.php 228
ERROR - 2018-03-20 12:15:37 --> Severity: Notice --> Undefined property: CI::$employee_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-20 12:15:37 --> Severity: Error --> Call to a member function get_departments() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 43
ERROR - 2018-03-20 12:21:14 --> Severity: Notice --> Undefined property: CI::$employee_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-20 12:21:14 --> Severity: Error --> Call to a member function get_departments() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 43
ERROR - 2018-03-20 12:21:16 --> Severity: Notice --> Undefined property: CI::$employee_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-03-20 12:21:16 --> Severity: Error --> Call to a member function get_departments() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 43
ERROR - 2018-03-20 12:50:13 --> Severity: Warning --> Missing argument 1 for User_account_model::check_account(), called in C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php on line 944 and defined C:\xampp\htdocs\smis\application\modules\theme_option\models\User_Account_model.php 115
ERROR - 2018-03-20 12:50:13 --> Severity: Notice --> Undefined variable: profile_id C:\xampp\htdocs\smis\application\modules\theme_option\models\User_Account_model.php 117
ERROR - 2018-03-20 12:58:43 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 6
ERROR - 2018-03-20 12:58:50 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 6
ERROR - 2018-03-20 12:59:12 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 6
ERROR - 2018-03-20 13:00:59 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 2
ERROR - 2018-03-20 13:00:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 2
ERROR - 2018-03-20 13:06:59 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 27
ERROR - 2018-03-20 13:06:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 27
ERROR - 2018-03-20 13:09:01 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:06 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:26 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:28 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:31 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:36 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:10:52 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:10:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:12:40 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:12:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:12:54 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:12:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\ajax_user_account.php 30
ERROR - 2018-03-20 13:14:47 --> 404 Page Not Found: ../modules/theme_option/controllers/User_account/insert_usersd
ERROR - 2018-03-20 13:16:18 --> 404 Page Not Found: ../modules/theme_option/controllers/User_account/insert_usersd
ERROR - 2018-03-20 13:19:18 --> 404 Page Not Found: ../modules/theme_option/controllers/User_account/insert_usersd
ERROR - 2018-03-20 13:42:30 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-20 13:42:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-03-20 13:54:10 --> Severity: Notice --> Undefined variable: employee C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:54:10 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:54:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:54:10 --> Severity: Notice --> Undefined variable: employee C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:54:10 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:54:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:54:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 109
ERROR - 2018-03-20 13:55:04 --> Severity: Notice --> Undefined variable: employee C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:55:04 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:55:04 --> Severity: Notice --> Undefined variable: employee C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:55:04 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 67
ERROR - 2018-03-20 13:55:55 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 84
ERROR - 2018-03-20 13:55:55 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 84
ERROR - 2018-03-20 13:56:34 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 84
ERROR - 2018-03-20 13:56:34 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 84
ERROR - 2018-03-20 13:57:15 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 13:57:15 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 13:58:48 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 55
ERROR - 2018-03-20 13:59:18 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 56
ERROR - 2018-03-20 13:59:20 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 56
ERROR - 2018-03-20 14:01:40 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 14:01:40 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 14:02:34 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 14:02:34 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 14:02:51 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 14:02:51 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 14:03:11 --> Severity: Notice --> Undefined variable: employee_type C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 14:03:11 --> Severity: Error --> Cannot access empty property C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list.php 83
ERROR - 2018-03-20 14:05:58 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_rank.php 87
ERROR - 2018-03-20 14:06:29 --> 404 Page Not Found: ../modules/pages/controllers/reports/Employee_reports/employee_list_type
ERROR - 2018-03-20 14:15:14 --> Severity: Parsing Error --> syntax error, unexpected ''2'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 210
ERROR - 2018-03-20 14:15:27 --> Severity: Parsing Error --> syntax error, unexpected ''3'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 210
ERROR - 2018-03-20 14:27:15 --> 404 Page Not Found: ../modules/pages/controllers/reports/Employee_reports/employee_list_department
ERROR - 2018-03-20 14:29:08 --> Severity: Notice --> Undefined variable: emp_types C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list_department.php 53
ERROR - 2018-03-20 14:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list_department.php 53
ERROR - 2018-03-20 14:29:08 --> Severity: Notice --> Undefined variable: emp_types C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list_department.php 65
ERROR - 2018-03-20 14:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\smis\application\modules\pages\views\reports\employee_list_department.php 65
ERROR - 2018-03-20 14:37:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 224
ERROR - 2018-03-20 14:37:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 224
ERROR - 2018-03-20 14:37:32 --> Severity: Error --> Call to undefined function preint_r() C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 225
ERROR - 2018-03-20 14:38:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 225
ERROR - 2018-03-20 14:38:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 225
ERROR - 2018-03-20 14:46:45 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 235
ERROR - 2018-03-20 14:47:05 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Employee_reports.php 235
ERROR - 2018-03-20 14:49:11 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 52
ERROR - 2018-03-20 14:51:10 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 52
ERROR - 2018-03-20 14:51:54 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 131072000 bytes) C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 57
ERROR - 2018-03-20 14:52:27 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 131072000 bytes) C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 57
ERROR - 2018-03-20 14:52:52 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 131072000 bytes) C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 57
ERROR - 2018-03-20 14:53:23 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 131072000 bytes) C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 57
ERROR - 2018-03-20 14:54:11 --> Severity: Error --> Allowed memory size of 134217728 bytes exhausted (tried to allocate 131072000 bytes) C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 56
ERROR - 2018-03-20 14:56:49 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 56
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:16 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:34 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:35 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:57:53 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:09 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:58:25 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 14:59:54 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:01:39 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\smis\application\modules\pages\views\reports\class_teachers_list.php 58
ERROR - 2018-03-20 15:12:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
