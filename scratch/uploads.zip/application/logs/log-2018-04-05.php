<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-05 09:36:56 --> Severity: Notice --> Undefined property: CI::$appraisal_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-04-05 09:36:56 --> Severity: Error --> Call to a member function get_appraisals() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1079
ERROR - 2018-04-05 09:37:04 --> Severity: Notice --> Undefined property: CI::$appraisal_manager_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-04-05 09:37:04 --> Severity: Error --> Call to a member function get_appraisals() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1079
ERROR - 2018-04-05 10:06:30 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 10:18:51 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 10:19:40 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 10:20:51 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 10:26:16 --> Severity: Notice --> Undefined property: CI::$ajax_model C:\xampp\htdocs\smis\application\third_party\MX\Controller.php 59
ERROR - 2018-04-05 10:26:16 --> Severity: Error --> Call to a member function get_class_teacher() on null C:\xampp\htdocs\smis\application\modules\pages\controllers\reports\Academic_report.php 682
ERROR - 2018-04-05 10:36:07 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 10:39:05 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 10:46:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 10:48:38 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 10:49:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 10:52:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 10:52:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 10:52:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 10:53:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 10:53:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 10:53:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 10:57:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 10:57:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 10:57:03 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 10:57:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\smis\application\modules\pages\controllers\ajax.php 1118
ERROR - 2018-04-05 11:03:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 11:03:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 11:03:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 11:08:53 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 11:09:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 11:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 11:09:34 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 11:38:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 11:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Student.php 646
ERROR - 2018-04-05 11:38:06 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 11:39:10 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 11:50:12 --> Severity: 4096 --> Object of class CI_URI could not be converted to string C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 91
ERROR - 2018-04-05 11:50:40 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\smis\application\modules\pages\controllers\profile\Evaluation.php 91
ERROR - 2018-04-05 11:52:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 11:52:11 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 11:52:17 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 11:52:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 11:58:23 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 12:03:21 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 12:04:44 --> Severity: Notice --> Undefined variable: sections C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_list.php 90
ERROR - 2018-04-05 12:09:01 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 12:12:34 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 12:14:02 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 12:20:51 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 12:25:37 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 12:25:57 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 13:32:09 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\smis\application\modules\pages\views\profile\student_detail.php 58
ERROR - 2018-04-05 15:04:09 --> Severity: Notice --> Undefined variable: exams C:\xampp\htdocs\smis\application\modules\pages\views\reports\student_evaluation_overall.php 95
ERROR - 2018-04-05 16:58:08 --> Severity: Error --> Call to undefined function celi() C:\xampp\htdocs\smis\application\modules\pages\views\board_home.php 74
