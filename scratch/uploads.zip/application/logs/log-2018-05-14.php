<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-14 10:08:58 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:08:59 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:08:59 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:08:59 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:08:59 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:08:59 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:02 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:02 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:02 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:02 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:02 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:09:02 --> 404 Page Not Found: /index
ERROR - 2018-05-14 10:21:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'smis_demos' C:\xampp\htdocs\smis\demo\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-05-14 10:21:48 --> Unable to connect to the database
