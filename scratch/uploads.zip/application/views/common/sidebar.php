<?php 
echo modules::run('menu/index');
?>