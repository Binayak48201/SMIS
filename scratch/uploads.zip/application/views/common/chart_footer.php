

<script>

  <?php
    if(isset($jscript) && $jscript!=NULL)
    {      
      echo $jscript;
    }
    ?>
</script>
