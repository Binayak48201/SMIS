<?php
$this->load->view('common/ajax_header.php');
$this->load->view($main_content);
$this->load->view('common/chart_footer.php');
?>
