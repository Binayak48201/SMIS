<!-- <div class="portlet-title tabbable-line">
  <div class="caption caption-md">
    <i class="icon-globe theme-font hide"></i>
    <span class="caption-subject font-blue-madison bold uppercase">Help</span>
  </div>
  <ul class="nav nav-pills">
    <li class="active">
      <a href="#tab_1_1" class="cstm" data-toggle="tab">Current / Passed</a>
    </li>
    <li>
      <a href="#tab_1_2" class="cstm" data-toggle="tab">Status-wise</a>
    </li>
    <li>
      <a href="#tab_1_3" class="cstm" data-toggle="tab">Program-wise</a>
    </li>
    <li>
      <a href="#tab_1_4" class="cstm" data-toggle="tab"><?=date('Y')?></a>
    </li>
  </ul>
</div> -->
<!-- <div class="portlet-body" style="overflow: auto; height: 300px;">
  <div class="tab-content">
    <div class="tab-pane active" id="tab_1_1">
     <div id="chart_div" style="width: 100%; height: 250px;"></div>
     <br/>
     <div class='text-center'>
        <span style="height: 15px;width: 15px; display: inline-block; background-color:#03A9F4 "></span> <span style="cursor: default; -webkit-user-select: none; -webkit-font-smoothing: antialiased; font-family: Roboto; font-weight: 500;">Currently Studying</span>
        <span style="height: 15px;width: 15px; display: inline-block; background-color:#4CAF50 "></span> <span style="cursor: default; -webkit-user-select: none; -webkit-font-smoothing: antialiased; font-family: Roboto; font-weight: 500;">Passed-Out</span>
      </div>
      <div class="clearfix"> </div>
    </div>
    <div class="tab-pane" id="tab_1_2">
       <div id="piechart_3d" style="width: 100%; height: 250px;"></div>
       <div class="clearfix"> </div>
    </div>
    <div class="tab-pane" id="tab_1_3"> -->
      <div id="piechart_3d_grade" style="width: 100%; height: 250px;"></div>
       <div class="clearfix"> </div>
  <!--   </div>
  <div class="tab-pane" id="tab_1_4">
    <div id="piechart_3d_current" style="width: 100%; height: 250px;"></div>
     <div class="clearfix"> </div>
  </div>
    </div>
  </div> -->