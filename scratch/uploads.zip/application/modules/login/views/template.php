<?php
$this->load->view('common/header.php');
$this->load->view('common/sidebar.php');
$this->load->view($main_content);

$this->load->view('common/footer.php');
?>
