<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Alt_Login extends CI_Controller {

	public function index()
	{
		echo "hello world";		
	}

}

/* End of file Alt_Login.php */
/* Location: ./application/controllers/Alt_Login.php */